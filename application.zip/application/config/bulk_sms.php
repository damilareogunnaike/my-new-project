
<?php

	$active_provider = "cloudsms";

	$config['cloudsms']['user_id'] = "44466586";
	$config['cloudsms']['password'] = "123samuel18?S";
	$config['cloudsms']['type'] = "0";
	$config['cloudsms']['url'] = "";

?>
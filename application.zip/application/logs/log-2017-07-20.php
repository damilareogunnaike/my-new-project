<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-20 01:14:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:10 --> No URI present. Default controller set.
DEBUG - 2017-07-20 01:14:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:10 --> Session Class Initialized
ERROR - 2017-07-20 01:14:10 --> Session: The session cookie was not signed.
DEBUG - 2017-07-20 01:14:10 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:11 --> Total execution time: 1.2964
DEBUG - 2017-07-20 01:14:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:12 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:12 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:12 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:12 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:12 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:12 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:29 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:29 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:29 --> Total execution time: 0.1107
DEBUG - 2017-07-20 01:14:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:40 --> User with name damilare just logged in
DEBUG - 2017-07-20 01:14:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:41 --> Total execution time: 0.1614
DEBUG - 2017-07-20 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:56 --> Total execution time: 0.1283
DEBUG - 2017-07-20 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:14:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:14:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:14:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:14:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:14:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:14:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:14:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:02 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:02 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:02 --> Total execution time: 0.0973
DEBUG - 2017-07-20 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:02 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:02 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:08 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:08 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:15:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:27 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-20 01:15:27 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-20 01:15:27 --> Total execution time: 0.1593
DEBUG - 2017-07-20 01:15:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:32 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:32 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:15:32 --> Total execution time: 0.1604
DEBUG - 2017-07-20 01:15:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:15:38 --> Session Class Initialized
DEBUG - 2017-07-20 01:15:38 --> Session routines successfully run
DEBUG - 2017-07-20 01:15:38 --> Total execution time: 0.3685
DEBUG - 2017-07-20 01:23:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:05 --> No URI present. Default controller set.
DEBUG - 2017-07-20 01:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:05 --> Total execution time: 0.3012
DEBUG - 2017-07-20 01:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:06 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:06 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:06 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:06 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:07 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:07 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:19 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:19 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:19 --> Total execution time: 0.1692
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:20 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:42 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:42 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:23:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:23:45 --> Session Class Initialized
DEBUG - 2017-07-20 01:23:45 --> Session routines successfully run
DEBUG - 2017-07-20 01:23:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:23:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:23:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:02 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:02 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:03 --> Total execution time: 0.1918
DEBUG - 2017-07-20 01:28:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:06 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:06 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:19 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:19 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:21 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:21 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:21 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-20 01:28:21 --> Severity: error --> Exception: Call to undefined function rest_response() C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 152
DEBUG - 2017-07-20 01:28:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:28:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:28:36 --> Session Class Initialized
DEBUG - 2017-07-20 01:28:36 --> Session routines successfully run
DEBUG - 2017-07-20 01:28:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:28:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:28:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:03 --> Total execution time: 0.3057
DEBUG - 2017-07-20 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:05 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:07 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:07 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:29:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:29:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:29:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:29:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:29:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:29:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:25 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:25 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:25 --> Total execution time: 0.3619
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:31 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:31 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:30:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:30:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:30:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:30:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:27 --> Total execution time: 0.1772
DEBUG - 2017-07-20 01:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:28 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:28 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:28 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:28 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:28 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:28 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:28 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:28 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:29 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:29 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:29 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:29 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:35 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:35 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:55 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:55 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:55 --> Total execution time: 0.1725
DEBUG - 2017-07-20 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:57 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:57 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:57 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:57 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:32:57 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:57 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:57 --> Session Class Initialized
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Session routines successfully run
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:33:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:33:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:33:02 --> Session Class Initialized
DEBUG - 2017-07-20 01:33:02 --> Session routines successfully run
DEBUG - 2017-07-20 01:33:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:33:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:33:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:33:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:33:03 --> Session Class Initialized
DEBUG - 2017-07-20 01:33:03 --> Session routines successfully run
DEBUG - 2017-07-20 01:33:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:33:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:33:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:33:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:08 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:08 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:08 --> Total execution time: 0.2090
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:14 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:14 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:16 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:16 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:25 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:25 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:25 --> Total execution time: 0.1759
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:26 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:26 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:26 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:26 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:26 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:26 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:27 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:27 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:31 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:31 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:51 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:51 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:51 --> Total execution time: 0.2929
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:54 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:54 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:54 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:54 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:56 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:56 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:34:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:34:58 --> Session Class Initialized
DEBUG - 2017-07-20 01:34:58 --> Session routines successfully run
DEBUG - 2017-07-20 01:34:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:34:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:34:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:10 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:11 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:31 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:31 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:31 --> Total execution time: 0.2940
DEBUG - 2017-07-20 01:35:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:33 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:33 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:34 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:34 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:34 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:38 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:38 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:40 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:40 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:35:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:35:41 --> Session Class Initialized
DEBUG - 2017-07-20 01:35:41 --> Session routines successfully run
DEBUG - 2017-07-20 01:35:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:35:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:35:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:16 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:16 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:16 --> Total execution time: 0.2132
DEBUG - 2017-07-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:17 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:17 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:18 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:21 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:21 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:23 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:23 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:29 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:29 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:38 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:38 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:53 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:53 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 01:59:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 01:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 01:59:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 01:59:59 --> Session Class Initialized
DEBUG - 2017-07-20 01:59:59 --> Session routines successfully run
DEBUG - 2017-07-20 01:59:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 01:59:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:06 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:06 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:43 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:43 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:43 --> Total execution time: 0.1738
DEBUG - 2017-07-20 02:00:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:00:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:00:46 --> Session Class Initialized
DEBUG - 2017-07-20 02:00:46 --> Session routines successfully run
DEBUG - 2017-07-20 02:00:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:00 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:00 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:01 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:01 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:04 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:04 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:12 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:12 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:16 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:16 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:16 --> Total execution time: 0.1460
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:17 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:17 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:17 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:17 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:17 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:17 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:17 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:18 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:18 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:18 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:18 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:32 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:32 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:36 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:36 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:38 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:38 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:48 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:48 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:01:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:01:53 --> Session Class Initialized
DEBUG - 2017-07-20 02:01:53 --> Session routines successfully run
DEBUG - 2017-07-20 02:01:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:01:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:01:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:06 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:06 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:07 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:07 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:08 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:08 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:15 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:15 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:18 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:18 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:27 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:27 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:29 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:30 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:31 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:31 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:38 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:38 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:44 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:44 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-20 02:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-20 02:02:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-20 02:02:46 --> Session Class Initialized
DEBUG - 2017-07-20 02:02:46 --> Session routines successfully run
DEBUG - 2017-07-20 02:02:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-20 02:02:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-20 02:02:46 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Positioner\Block.php 51
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Positioner\Block.php 52
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:49 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Positioner\Block.php 51
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Positioner\Block.php 52
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:51 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:52 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:53 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Page.php 494
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
ERROR - 2017-07-20 02:02:54 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:57 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 55
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 117
ERROR - 2017-07-20 02:02:58 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Renderer\Inline.php 146

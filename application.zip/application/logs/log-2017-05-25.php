<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-25 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:56:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:56:06 --> Session Class Initialized
ERROR - 2017-05-25 09:56:06 --> Session: The session cookie was not signed.
DEBUG - 2017-05-25 09:56:06 --> Session routines successfully run
DEBUG - 2017-05-25 09:56:06 --> Total execution time: 0.6535
DEBUG - 2017-05-25 09:58:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:58:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:58:26 --> Session Class Initialized
DEBUG - 2017-05-25 09:58:26 --> Session routines successfully run
DEBUG - 2017-05-25 09:58:26 --> User with name admin just logged in
DEBUG - 2017-05-25 09:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:58:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:58:27 --> Session Class Initialized
DEBUG - 2017-05-25 09:58:27 --> Session routines successfully run
DEBUG - 2017-05-25 09:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-25 09:58:27 --> Total execution time: 0.3986
DEBUG - 2017-05-25 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:58:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:58:35 --> Session Class Initialized
DEBUG - 2017-05-25 09:58:35 --> Session routines successfully run
DEBUG - 2017-05-25 09:58:35 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-25 09:58:35 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-25 09:58:35 --> Total execution time: 0.1960
DEBUG - 2017-05-25 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:58:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:58:48 --> Session Class Initialized
DEBUG - 2017-05-25 09:58:48 --> Session routines successfully run
DEBUG - 2017-05-25 09:58:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-25 09:58:48 --> Total execution time: 0.1289
DEBUG - 2017-05-25 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-25 09:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-25 09:58:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-25 09:58:52 --> Session Class Initialized
DEBUG - 2017-05-25 09:58:52 --> Session routines successfully run
DEBUG - 2017-05-25 09:58:53 --> Total execution time: 0.8643

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-14 05:17:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:24 --> Session Class Initialized
ERROR - 2017-06-14 05:17:24 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 05:17:24 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:25 --> Total execution time: 0.5678
DEBUG - 2017-06-14 05:17:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:37 --> Session Class Initialized
DEBUG - 2017-06-14 05:17:37 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:37 --> Session Class Initialized
DEBUG - 2017-06-14 05:17:37 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:17:37 --> Session Class Initialized
DEBUG - 2017-06-14 05:17:37 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:17:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:17:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:17:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:17:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:55 --> Session Class Initialized
DEBUG - 2017-06-14 05:17:55 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:55 --> User with name admin just logged in
DEBUG - 2017-06-14 05:17:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:17:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:17:56 --> Session Class Initialized
DEBUG - 2017-06-14 05:17:56 --> Session routines successfully run
DEBUG - 2017-06-14 05:17:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:17:56 --> Total execution time: 0.2723
DEBUG - 2017-06-14 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:04 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:04 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:04 --> Total execution time: 0.1534
DEBUG - 2017-06-14 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:05 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:05 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:05 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:05 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:05 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:05 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:05 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:06 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:06 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:06 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:07 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:07 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:07 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:07 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:07 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:07 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:07 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:07 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:07 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:18 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:18 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:18 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-14 05:18:18 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-14 05:18:18 --> Total execution time: 0.0982
DEBUG - 2017-06-14 05:18:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:18:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:18:41 --> Session Class Initialized
DEBUG - 2017-06-14 05:18:41 --> Session routines successfully run
DEBUG - 2017-06-14 05:18:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:18:41 --> Total execution time: 0.0886
DEBUG - 2017-06-14 05:19:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:19:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:19:12 --> Session Class Initialized
DEBUG - 2017-06-14 05:19:12 --> Session routines successfully run
DEBUG - 2017-06-14 05:19:12 --> Total execution time: 0.5077
DEBUG - 2017-06-14 05:45:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:45:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:45:14 --> Session Class Initialized
ERROR - 2017-06-14 05:45:14 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 05:45:14 --> Session routines successfully run
DEBUG - 2017-06-14 05:45:14 --> Total execution time: 0.1257
DEBUG - 2017-06-14 05:45:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:45:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:45:29 --> Session Class Initialized
DEBUG - 2017-06-14 05:45:29 --> Session routines successfully run
DEBUG - 2017-06-14 05:45:29 --> User with name admin just logged in
DEBUG - 2017-06-14 05:45:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:45:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:45:30 --> Session Class Initialized
DEBUG - 2017-06-14 05:45:30 --> Session routines successfully run
DEBUG - 2017-06-14 05:45:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:45:30 --> Total execution time: 0.2730
DEBUG - 2017-06-14 05:45:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:45:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:45:37 --> Session Class Initialized
DEBUG - 2017-06-14 05:45:37 --> Session routines successfully run
DEBUG - 2017-06-14 05:45:37 --> Total execution time: 0.0521
DEBUG - 2017-06-14 05:45:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:45:44 --> No URI present. Default controller set.
DEBUG - 2017-06-14 05:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:45:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:45:44 --> Session Class Initialized
DEBUG - 2017-06-14 05:45:44 --> Session routines successfully run
DEBUG - 2017-06-14 05:45:44 --> Total execution time: 0.0440
DEBUG - 2017-06-14 05:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:13 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:13 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:13 --> User with name admin just logged in
DEBUG - 2017-06-14 05:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:14 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:14 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:46:14 --> Total execution time: 0.0781
DEBUG - 2017-06-14 05:46:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:20 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:20 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:20 --> Total execution time: 0.0598
DEBUG - 2017-06-14 05:46:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:48 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:48 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:48 --> Total execution time: 0.0479
DEBUG - 2017-06-14 05:46:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:51 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:51 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:46:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:46:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:46:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:51 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:51 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:46:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:46:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:46:51 --> Session Class Initialized
DEBUG - 2017-06-14 05:46:51 --> Session routines successfully run
DEBUG - 2017-06-14 05:46:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:46:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:00 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:00 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:00 --> User with name admin just logged in
DEBUG - 2017-06-14 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:00 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:00 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:00 --> Total execution time: 0.1271
DEBUG - 2017-06-14 05:47:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:09 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:09 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:09 --> Total execution time: 0.1087
DEBUG - 2017-06-14 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:10 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:10 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:10 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:10 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:11 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:11 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:11 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:11 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:11 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:11 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:11 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:12 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:12 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:12 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:12 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:12 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:12 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 05:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 05:47:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 05:47:13 --> Session Class Initialized
DEBUG - 2017-06-14 05:47:13 --> Session routines successfully run
DEBUG - 2017-06-14 05:47:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 05:47:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 05:47:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 06:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:56:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:56:30 --> Session Class Initialized
ERROR - 2017-06-14 06:56:30 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 06:56:30 --> Session routines successfully run
DEBUG - 2017-06-14 06:56:30 --> Total execution time: 0.5172
DEBUG - 2017-06-14 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:56:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:56:45 --> Session Class Initialized
DEBUG - 2017-06-14 06:56:45 --> Session routines successfully run
DEBUG - 2017-06-14 06:56:45 --> User with name admin just logged in
DEBUG - 2017-06-14 06:56:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:56:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:56:46 --> Session Class Initialized
DEBUG - 2017-06-14 06:56:46 --> Session routines successfully run
DEBUG - 2017-06-14 06:56:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 06:56:46 --> Total execution time: 0.6495
DEBUG - 2017-06-14 06:56:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:56:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:56:52 --> Session Class Initialized
DEBUG - 2017-06-14 06:56:52 --> Session routines successfully run
DEBUG - 2017-06-14 06:56:52 --> Total execution time: 0.1186
DEBUG - 2017-06-14 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:57:01 --> No URI present. Default controller set.
DEBUG - 2017-06-14 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:57:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:57:01 --> Session Class Initialized
DEBUG - 2017-06-14 06:57:01 --> Session routines successfully run
DEBUG - 2017-06-14 06:57:01 --> Total execution time: 0.1254
DEBUG - 2017-06-14 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:57:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:57:06 --> Session Class Initialized
DEBUG - 2017-06-14 06:57:06 --> Session routines successfully run
DEBUG - 2017-06-14 06:57:06 --> User with name admin just logged in
DEBUG - 2017-06-14 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:57:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:57:06 --> Session Class Initialized
DEBUG - 2017-06-14 06:57:06 --> Session routines successfully run
DEBUG - 2017-06-14 06:57:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 06:57:06 --> Total execution time: 0.0708
DEBUG - 2017-06-14 06:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 06:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 06:57:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 06:57:13 --> Session Class Initialized
DEBUG - 2017-06-14 06:57:13 --> Session routines successfully run
DEBUG - 2017-06-14 06:57:13 --> Total execution time: 0.0720
DEBUG - 2017-06-14 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:11 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:11 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:11 --> Total execution time: 0.0731
DEBUG - 2017-06-14 07:00:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:23 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:23 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:23 --> User with name admin just logged in
DEBUG - 2017-06-14 07:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:24 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:24 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:25 --> Total execution time: 0.7932
DEBUG - 2017-06-14 07:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:29 --> No URI present. Default controller set.
DEBUG - 2017-06-14 07:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:29 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:29 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:29 --> Total execution time: 0.0535
DEBUG - 2017-06-14 07:00:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:34 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:34 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:34 --> User with name admin just logged in
DEBUG - 2017-06-14 07:00:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:34 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:34 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:34 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:34 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:34 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:34 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:37 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:37 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:37 --> Total execution time: 0.1092
DEBUG - 2017-06-14 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:42 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:42 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:42 --> Total execution time: 0.1834
DEBUG - 2017-06-14 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:45 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:45 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:45 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:45 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:45 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:45 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:45 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:45 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:45 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:00:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:00:47 --> Session Class Initialized
DEBUG - 2017-06-14 07:00:47 --> Session routines successfully run
DEBUG - 2017-06-14 07:00:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:01:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:01:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:01:01 --> Session Class Initialized
DEBUG - 2017-06-14 07:01:01 --> Session routines successfully run
DEBUG - 2017-06-14 07:01:01 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-14 07:01:01 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-14 07:01:01 --> Total execution time: 0.2272
DEBUG - 2017-06-14 07:01:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:01:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:01:13 --> Session Class Initialized
DEBUG - 2017-06-14 07:01:13 --> Session routines successfully run
DEBUG - 2017-06-14 07:01:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:01:13 --> Total execution time: 0.1293
DEBUG - 2017-06-14 07:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:01:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:01:17 --> Session Class Initialized
DEBUG - 2017-06-14 07:01:17 --> Session routines successfully run
DEBUG - 2017-06-14 07:01:17 --> Total execution time: 0.6028
DEBUG - 2017-06-14 07:03:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:03:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:03:34 --> Session Class Initialized
ERROR - 2017-06-14 07:03:34 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 07:03:34 --> Session routines successfully run
DEBUG - 2017-06-14 07:03:34 --> Total execution time: 0.1840
DEBUG - 2017-06-14 07:03:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:03:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:03:49 --> Session Class Initialized
DEBUG - 2017-06-14 07:03:49 --> Session routines successfully run
DEBUG - 2017-06-14 07:03:49 --> User with name admin just logged in
DEBUG - 2017-06-14 07:03:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:03:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:03:50 --> Session Class Initialized
DEBUG - 2017-06-14 07:03:50 --> Session routines successfully run
DEBUG - 2017-06-14 07:03:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:03:50 --> Total execution time: 0.3415
DEBUG - 2017-06-14 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:04:00 --> Session Class Initialized
DEBUG - 2017-06-14 07:04:01 --> Session routines successfully run
DEBUG - 2017-06-14 07:04:01 --> Total execution time: 0.0663
DEBUG - 2017-06-14 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:43 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:43 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:44 --> Total execution time: 0.3856
DEBUG - 2017-06-14 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:46 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:46 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:47 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:47 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:47 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:47 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:47 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:48 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:48 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:14:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:14:48 --> Session Class Initialized
DEBUG - 2017-06-14 07:14:48 --> Session routines successfully run
DEBUG - 2017-06-14 07:14:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:38:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:38:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:38:24 --> Session Class Initialized
ERROR - 2017-06-14 07:38:24 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 07:38:24 --> Session routines successfully run
DEBUG - 2017-06-14 07:38:25 --> Total execution time: 0.4017
DEBUG - 2017-06-14 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:38:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:38:37 --> Session Class Initialized
DEBUG - 2017-06-14 07:38:37 --> Session routines successfully run
DEBUG - 2017-06-14 07:38:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:38:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:38:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:38:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:38:38 --> Session Class Initialized
DEBUG - 2017-06-14 07:38:38 --> Session routines successfully run
DEBUG - 2017-06-14 07:38:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:38:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:38:38 --> Session Class Initialized
DEBUG - 2017-06-14 07:38:38 --> Session routines successfully run
DEBUG - 2017-06-14 07:38:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:38:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:38:59 --> Session Class Initialized
DEBUG - 2017-06-14 07:38:59 --> Session routines successfully run
DEBUG - 2017-06-14 07:38:59 --> User with name admin just logged in
DEBUG - 2017-06-14 07:39:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:01 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:01 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:01 --> Total execution time: 0.2430
DEBUG - 2017-06-14 07:39:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:07 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:07 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:07 --> Total execution time: 0.0730
DEBUG - 2017-06-14 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:08 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:08 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:08 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:08 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:08 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:08 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:08 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:08 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:09 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:09 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:09 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:09 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:09 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:09 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:09 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:16 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:16 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:16 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-14 07:39:16 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-14 07:39:16 --> Total execution time: 0.1780
DEBUG - 2017-06-14 07:39:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:25 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:25 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 07:39:25 --> Total execution time: 0.1310
DEBUG - 2017-06-14 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 07:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 07:39:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 07:39:29 --> Session Class Initialized
DEBUG - 2017-06-14 07:39:29 --> Session routines successfully run
DEBUG - 2017-06-14 07:39:30 --> Total execution time: 0.9697
DEBUG - 2017-06-14 08:38:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:04 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:04 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:04 --> Total execution time: 0.9128
DEBUG - 2017-06-14 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:08 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:08 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 08:38:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:09 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:09 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 08:38:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:09 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:09 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-14 08:38:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:15 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:15 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:15 --> User with name admin just logged in
DEBUG - 2017-06-14 08:38:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:17 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:17 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:18 --> Total execution time: 0.8469
DEBUG - 2017-06-14 08:38:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:24 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:24 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:24 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-14 08:38:24 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-14 08:38:24 --> Total execution time: 0.1061
DEBUG - 2017-06-14 08:38:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:34 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:34 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-14 08:38:34 --> Total execution time: 0.1123
DEBUG - 2017-06-14 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:38:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:38:38 --> Session Class Initialized
DEBUG - 2017-06-14 08:38:38 --> Session routines successfully run
DEBUG - 2017-06-14 08:38:39 --> Total execution time: 0.5692
DEBUG - 2017-06-14 08:58:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-14 08:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-14 08:58:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-14 08:58:53 --> Session Class Initialized
ERROR - 2017-06-14 08:58:53 --> Session: The session cookie was not signed.
DEBUG - 2017-06-14 08:58:53 --> Session routines successfully run

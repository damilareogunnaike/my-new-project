<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-30 23:10:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 23:10:35 --> No URI present. Default controller set.
DEBUG - 2017-06-30 23:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-30 23:10:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-30 23:10:35 --> Session Class Initialized
ERROR - 2017-06-30 23:10:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-30 23:10:35 --> Session routines successfully run
DEBUG - 2017-06-30 23:10:36 --> Total execution time: 1.4897
DEBUG - 2017-06-30 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 23:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-30 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-30 23:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-30 23:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-30 23:10:37 --> Session Class Initialized
DEBUG - 2017-06-30 23:10:37 --> Session Class Initialized
DEBUG - 2017-06-30 23:10:37 --> Session Class Initialized
DEBUG - 2017-06-30 23:10:37 --> Session routines successfully run
DEBUG - 2017-06-30 23:10:37 --> Session routines successfully run
DEBUG - 2017-06-30 23:10:37 --> Session routines successfully run
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-30 23:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-30 23:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-30 23:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-30 23:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-30 23:10:37 --> Myapp class already loaded. Second attempt ignored.

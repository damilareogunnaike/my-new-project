<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-15 04:57:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 04:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 04:57:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 04:57:37 --> Session Class Initialized
ERROR - 2017-06-15 04:57:37 --> Session: The session cookie was not signed.
DEBUG - 2017-06-15 04:57:37 --> Session routines successfully run
DEBUG - 2017-06-15 04:57:37 --> Total execution time: 1.1740
DEBUG - 2017-06-15 04:58:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 04:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 04:58:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 04:58:38 --> Session Class Initialized
DEBUG - 2017-06-15 04:58:38 --> Session routines successfully run
DEBUG - 2017-06-15 04:58:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 04:58:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 04:58:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 04:58:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 04:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 04:58:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 04:58:39 --> Session Class Initialized
DEBUG - 2017-06-15 04:58:39 --> Session routines successfully run
DEBUG - 2017-06-15 04:58:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 04:58:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 04:58:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 04:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 04:58:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 04:58:43 --> Session Class Initialized
DEBUG - 2017-06-15 04:58:43 --> Session routines successfully run
DEBUG - 2017-06-15 04:58:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 04:58:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:00:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:00:38 --> Session Class Initialized
ERROR - 2017-06-15 05:00:38 --> Session: The session cookie was not signed.
DEBUG - 2017-06-15 05:00:38 --> Session routines successfully run
DEBUG - 2017-06-15 05:00:39 --> Total execution time: 0.1062
DEBUG - 2017-06-15 05:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:00:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:00:41 --> Session Class Initialized
DEBUG - 2017-06-15 05:00:41 --> Session routines successfully run
DEBUG - 2017-06-15 05:00:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:00:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:00:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:00:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:00:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:00:41 --> Session Class Initialized
DEBUG - 2017-06-15 05:00:41 --> Session routines successfully run
DEBUG - 2017-06-15 05:00:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:00:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:00:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:00:45 --> Session Class Initialized
DEBUG - 2017-06-15 05:00:45 --> Session routines successfully run
DEBUG - 2017-06-15 05:00:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:00:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:00:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:00:59 --> Session Class Initialized
DEBUG - 2017-06-15 05:00:59 --> Session routines successfully run
DEBUG - 2017-06-15 05:00:59 --> User with name admin just logged in
DEBUG - 2017-06-15 05:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:00 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:00 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:01 --> Total execution time: 0.4055
DEBUG - 2017-06-15 05:01:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:19 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:19 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:19 --> Total execution time: 0.1859
DEBUG - 2017-06-15 05:01:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:21 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:21 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:21 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:21 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:22 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:22 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:24 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:24 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:25 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:25 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:26 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:26 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-15 05:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:01:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:01:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:01:30 --> Session Class Initialized
DEBUG - 2017-06-15 05:01:30 --> Session routines successfully run
DEBUG - 2017-06-15 05:01:30 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-15 05:01:30 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-15 05:01:30 --> Total execution time: 0.1357
DEBUG - 2017-06-15 05:02:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:02:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:02:12 --> Session Class Initialized
DEBUG - 2017-06-15 05:02:12 --> Session routines successfully run
DEBUG - 2017-06-15 05:02:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-15 05:02:12 --> Total execution time: 0.1907
DEBUG - 2017-06-15 05:02:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-15 05:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-15 05:02:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-15 05:02:16 --> Session Class Initialized
DEBUG - 2017-06-15 05:02:16 --> Session routines successfully run
DEBUG - 2017-06-15 05:02:17 --> Total execution time: 1.0004

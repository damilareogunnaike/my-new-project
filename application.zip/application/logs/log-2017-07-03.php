<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-03 21:32:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 21:32:56 --> No URI present. Default controller set.
DEBUG - 2017-07-03 21:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 21:32:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 21:32:57 --> Session Class Initialized
ERROR - 2017-07-03 21:32:57 --> Session: The session cookie was not signed.
DEBUG - 2017-07-03 21:32:57 --> Session routines successfully run
DEBUG - 2017-07-03 21:32:57 --> Total execution time: 1.4172
DEBUG - 2017-07-03 21:32:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 21:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 21:32:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 21:32:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 21:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 21:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 21:32:58 --> Session Class Initialized
DEBUG - 2017-07-03 21:32:58 --> Session routines successfully run
DEBUG - 2017-07-03 21:32:58 --> Session Class Initialized
DEBUG - 2017-07-03 21:32:58 --> Session Class Initialized
DEBUG - 2017-07-03 21:32:58 --> Session routines successfully run
DEBUG - 2017-07-03 21:32:58 --> Session routines successfully run
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 21:32:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 21:32:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:32:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:32:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:32:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:57:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 21:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 21:57:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 21:57:11 --> Session Class Initialized
DEBUG - 2017-07-03 21:57:11 --> Session routines successfully run
DEBUG - 2017-07-03 21:57:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 21:57:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:57:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 21:57:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:11:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:11:30 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:11:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:11:30 --> Session Class Initialized
DEBUG - 2017-07-03 22:11:30 --> Session routines successfully run
DEBUG - 2017-07-03 22:11:31 --> Total execution time: 1.1652
DEBUG - 2017-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:11:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:11:31 --> Session Class Initialized
DEBUG - 2017-07-03 22:11:31 --> Session Class Initialized
DEBUG - 2017-07-03 22:11:31 --> Session Class Initialized
DEBUG - 2017-07-03 22:11:31 --> Session routines successfully run
DEBUG - 2017-07-03 22:11:31 --> Session routines successfully run
DEBUG - 2017-07-03 22:11:31 --> Session routines successfully run
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:11:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:11:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:11:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:11:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:11:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:12:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:12:59 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:12:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:12:59 --> Session Class Initialized
DEBUG - 2017-07-03 22:12:59 --> Session routines successfully run
DEBUG - 2017-07-03 22:12:59 --> Total execution time: 0.2235
DEBUG - 2017-07-03 22:13:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:14 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:14 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:14 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:14 --> Total execution time: 0.1199
DEBUG - 2017-07-03 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:32 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:32 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:32 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:32 --> Total execution time: 0.1459
DEBUG - 2017-07-03 22:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:33 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:33 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:33 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:33 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:33 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:33 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:46 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:46 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:46 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:46 --> Total execution time: 0.1755
DEBUG - 2017-07-03 22:13:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:46 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:13:46 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:46 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:46 --> Session Class Initialized
DEBUG - 2017-07-03 22:13:46 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:46 --> Session routines successfully run
DEBUG - 2017-07-03 22:13:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:13:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:13:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:14 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:14 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:14 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:14 --> Total execution time: 0.1416
DEBUG - 2017-07-03 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:15 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:15 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:47 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:47 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:47 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:47 --> Total execution time: 0.1400
DEBUG - 2017-07-03 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:48 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:48 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:48 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:48 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:48 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:48 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:17:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:17:59 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:17:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:17:59 --> Session Class Initialized
DEBUG - 2017-07-03 22:17:59 --> Session routines successfully run
DEBUG - 2017-07-03 22:17:59 --> Total execution time: 0.2227
DEBUG - 2017-07-03 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:00 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:00 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:10 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:10 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:10 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:10 --> Total execution time: 0.1693
DEBUG - 2017-07-03 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:11 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:11 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:11 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:11 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:11 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:11 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:23 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:23 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:23 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:23 --> Total execution time: 0.1740
DEBUG - 2017-07-03 22:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:24 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:24 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:24 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:24 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:24 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:24 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:42 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:42 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:42 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:42 --> Total execution time: 0.1555
DEBUG - 2017-07-03 22:18:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:18:43 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:18:43 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:43 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:43 --> Session Class Initialized
DEBUG - 2017-07-03 22:18:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:43 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:43 --> Session routines successfully run
DEBUG - 2017-07-03 22:18:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:18:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:18:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:19:34 --> Session Class Initialized
DEBUG - 2017-07-03 22:19:34 --> Session routines successfully run
DEBUG - 2017-07-03 22:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:19:35 --> Session Class Initialized
DEBUG - 2017-07-03 22:19:35 --> Session routines successfully run
DEBUG - 2017-07-03 22:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:26 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:26 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:26 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:26 --> Total execution time: 0.1354
DEBUG - 2017-07-03 22:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:28 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:28 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:28 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:28 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:28 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:28 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:51 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:51 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:51 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:51 --> Total execution time: 0.1313
DEBUG - 2017-07-03 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:51 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:51 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:51 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:51 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:51 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:51 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:55 --> No URI present. Default controller set.
DEBUG - 2017-07-03 22:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:55 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:55 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:55 --> Total execution time: 0.1584
DEBUG - 2017-07-03 22:22:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 22:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:57 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 22:22:57 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:57 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:57 --> Session Class Initialized
DEBUG - 2017-07-03 22:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:57 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:57 --> Session routines successfully run
DEBUG - 2017-07-03 22:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 22:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 22:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 23:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 23:24:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 23:24:40 --> Session Class Initialized
DEBUG - 2017-07-03 23:24:40 --> Session routines successfully run
DEBUG - 2017-07-03 23:24:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 23:24:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-03 23:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-03 23:24:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-03 23:24:42 --> Session Class Initialized
DEBUG - 2017-07-03 23:24:42 --> Session routines successfully run
DEBUG - 2017-07-03 23:24:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-03 23:24:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-03 23:24:42 --> Myapp class already loaded. Second attempt ignored.

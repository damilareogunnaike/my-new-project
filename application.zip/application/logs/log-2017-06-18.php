<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-18 21:58:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 21:58:11 --> No URI present. Default controller set.
DEBUG - 2017-06-18 21:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 21:58:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
ERROR - 2017-06-18 21:58:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'evangelm_admin'@'localhost' (using password: YES) C:\xampp\htdocs\school_ms\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2017-06-18 21:58:11 --> Unable to connect to the database
DEBUG - 2017-06-18 21:59:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 21:59:01 --> No URI present. Default controller set.
DEBUG - 2017-06-18 21:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 21:59:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 21:59:01 --> Session Class Initialized
DEBUG - 2017-06-18 21:59:01 --> Session routines successfully run
DEBUG - 2017-06-18 21:59:01 --> Total execution time: 0.1513
DEBUG - 2017-06-18 22:10:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:10:38 --> No URI present. Default controller set.
DEBUG - 2017-06-18 22:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:10:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:10:38 --> Session Class Initialized
DEBUG - 2017-06-18 22:10:38 --> Session routines successfully run
DEBUG - 2017-06-18 22:10:38 --> Total execution time: 0.0973
DEBUG - 2017-06-18 22:11:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:03 --> No URI present. Default controller set.
DEBUG - 2017-06-18 22:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:03 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:03 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:03 --> Total execution time: 0.0957
DEBUG - 2017-06-18 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:04 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:04 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:04 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:04 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:04 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:11:04 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:11:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:09 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:09 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:09 --> User with name damilare just logged in
DEBUG - 2017-06-18 22:11:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:09 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:09 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:09 --> Total execution time: 0.1943
DEBUG - 2017-06-18 22:11:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:14 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:14 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:14 --> Total execution time: 0.1069
DEBUG - 2017-06-18 22:11:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:11:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:11:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:11:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:11:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:11:43 --> Total execution time: 0.1013
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> Total execution time: 0.1552
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:42:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Session Class Initialized
DEBUG - 2017-06-18 22:42:32 --> Session routines successfully run
DEBUG - 2017-06-18 22:42:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:43:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:43:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:43:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:43:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:43:10 --> Total execution time: 0.0980
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> Total execution time: 0.0810
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:49 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:45:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:45:50 --> Session Class Initialized
DEBUG - 2017-06-18 22:45:50 --> Session routines successfully run
DEBUG - 2017-06-18 22:45:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:45:50 --> Total execution time: 0.1019
DEBUG - 2017-06-18 22:49:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:19 --> Total execution time: 0.0996
DEBUG - 2017-06-18 22:49:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:20 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:20 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:20 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:20 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:20 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:20 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:45 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:45 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:45 --> Total execution time: 0.0994
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Session Class Initialized
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Session routines successfully run
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:18 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:18 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:18 --> Total execution time: 0.0964
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:30 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:30 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:30 --> Total execution time: 0.1025
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:30 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:30 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:50:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Session Class Initialized
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Session routines successfully run
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:50:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:09 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:09 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:09 --> Total execution time: 0.0982
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:09 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:10 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:10 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:42 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:42 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:42 --> Total execution time: 0.0986
DEBUG - 2017-06-18 22:52:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Session Class Initialized
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Session routines successfully run
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:05 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:05 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:05 --> Total execution time: 0.1097
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:36 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Total execution time: 0.1000
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Session Class Initialized
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> Session routines successfully run
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:15 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:15 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:15 --> Total execution time: 0.1154
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Session Class Initialized
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Session routines successfully run
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 22:57:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 22:57:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Total execution time: 0.0975
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:01:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:01:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:34 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:34 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:34 --> Total execution time: 0.1025
DEBUG - 2017-06-18 23:05:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:05:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:06 --> Total execution time: 0.0993
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Total execution time: 0.0991
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> Session Class Initialized
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> Session routines successfully run
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:06:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:16:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:16:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:16:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:16:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:16:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:16:41 --> Total execution time: 0.0969
DEBUG - 2017-06-18 23:17:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:24 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:24 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:24 --> Total execution time: 0.1047
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Total execution time: 0.1065
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:17:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:17:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:17:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:17:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:17:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:17:44 --> Total execution time: 0.0975
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:34 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:34 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:34 --> Total execution time: 0.1083
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:34 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:18:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:35 --> Session Class Initialized
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:35 --> Session routines successfully run
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:18:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-18 23:18:42 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-18 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:31 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:31 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:31 --> Total execution time: 0.1200
DEBUG - 2017-06-18 23:22:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:31 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:43 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:43 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:43 --> Total execution time: 0.1074
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> Session Class Initialized
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Session routines successfully run
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:22:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-18 23:22:49 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-18 23:26:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:17 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:17 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:17 --> Total execution time: 0.1023
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-18 23:26:22 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-18 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:45 --> Total execution time: 0.1004
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:26:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:26:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-18 23:26:51 --> Severity: error --> Exception: syntax error, unexpected '__construct' (T_STRING), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\school_ms\application\controllers\api\ApiBase.php 9
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:41 --> Total execution time: 0.1182
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:42 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:42 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:27:42 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:42 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:42 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:42 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:42 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:42 --> Session Class Initialized
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:42 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:42 --> Session routines successfully run
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:27:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:27:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-18 23:27:47 --> Severity: Notice --> Undefined property: Result_Pins::$load C:\xampp\htdocs\school_ms\application\controllers\api\ApiBase.php 10
ERROR - 2017-06-18 23:27:47 --> Severity: error --> Exception: Call to a member function library() on null C:\xampp\htdocs\school_ms\application\controllers\api\ApiBase.php 10
DEBUG - 2017-06-18 23:28:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:40 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:40 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Total execution time: 0.1172
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:28:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:28:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:28:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:28:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:28:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:28:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:00 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:00 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:00 --> Total execution time: 0.1210
DEBUG - 2017-06-18 23:30:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:30:07 --> Session Class Initialized
DEBUG - 2017-06-18 23:30:07 --> Session routines successfully run
DEBUG - 2017-06-18 23:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:30:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:30:07 --> Total execution time: 0.1166
DEBUG - 2017-06-18 23:31:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:05 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:05 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:05 --> Total execution time: 0.1188
DEBUG - 2017-06-18 23:31:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:31:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:31:12 --> Session Class Initialized
DEBUG - 2017-06-18 23:31:12 --> Session routines successfully run
DEBUG - 2017-06-18 23:31:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:31:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:31:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:39:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:39:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:39:45 --> Session Class Initialized
DEBUG - 2017-06-18 23:39:45 --> Session routines successfully run
DEBUG - 2017-06-18 23:39:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:39:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:39:45 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-18 23:39:45 --> Severity: error --> Exception: Class Result_pins already exists and doesn't extend CI_Model C:\xampp\htdocs\school_ms\system\core\Loader.php 349
DEBUG - 2017-06-18 23:40:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:40:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:40:43 --> Session Class Initialized
DEBUG - 2017-06-18 23:40:43 --> Session routines successfully run
DEBUG - 2017-06-18 23:40:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:40:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:40:44 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-18 23:40:44 --> Severity: error --> Exception: Call to undefined method Result_pins_model::generate_for_class() C:\xampp\htdocs\school_ms\application\controllers\api\Result_Pins.php 22
DEBUG - 2017-06-18 23:41:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:41:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:41:04 --> Session Class Initialized
DEBUG - 2017-06-18 23:41:04 --> Session routines successfully run
DEBUG - 2017-06-18 23:41:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:41:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:41:04 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-18 23:41:04 --> Severity: error --> Exception: Too few arguments to function Result_pins_model::generate_for_class(), 1 passed in C:\xampp\htdocs\school_ms\application\controllers\api\Result_Pins.php on line 22 and exactly 3 expected C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 10
DEBUG - 2017-06-18 23:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:41:51 --> Session Class Initialized
DEBUG - 2017-06-18 23:41:51 --> Session routines successfully run
DEBUG - 2017-06-18 23:41:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:42:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:42:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:42:06 --> Session Class Initialized
DEBUG - 2017-06-18 23:42:06 --> Session routines successfully run
DEBUG - 2017-06-18 23:42:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:49:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:49:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:49:08 --> Session Class Initialized
DEBUG - 2017-06-18 23:49:08 --> Session routines successfully run
DEBUG - 2017-06-18 23:49:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:49:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:49:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:57:54 --> Session Class Initialized
DEBUG - 2017-06-18 23:57:54 --> Session routines successfully run
DEBUG - 2017-06-18 23:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:57:54 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-18 23:57:54 --> Severity: error --> Exception: Call to undefined method Student_model::get_by_class_and_session() C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 15
DEBUG - 2017-06-18 23:58:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-18 23:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-18 23:58:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-18 23:58:18 --> Session Class Initialized
DEBUG - 2017-06-18 23:58:18 --> Session routines successfully run
DEBUG - 2017-06-18 23:58:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-18 23:58:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-18 23:58:18 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-18 23:58:18 --> Severity: error --> Exception: No students found for selection. C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 17

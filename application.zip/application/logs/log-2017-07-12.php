<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-12 02:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:08 --> No URI present. Default controller set.
DEBUG - 2017-07-12 02:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:09 --> Session Class Initialized
ERROR - 2017-07-12 02:21:09 --> Session: The session cookie was not signed.
DEBUG - 2017-07-12 02:21:09 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:10 --> Total execution time: 1.5367
DEBUG - 2017-07-12 02:21:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:10 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:10 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:10 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:10 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:10 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:10 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:12 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:12 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:12 --> Total execution time: 0.2049
DEBUG - 2017-07-12 02:21:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:15 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:15 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:15 --> User with name damilare just logged in
DEBUG - 2017-07-12 02:21:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:15 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:15 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:15 --> Total execution time: 0.2306
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Total execution time: 0.1107
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:21 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:21 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:32 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:32 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:21:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:21:33 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:33 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:33 --> Session Class Initialized
DEBUG - 2017-07-12 02:21:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:33 --> Session routines successfully run
DEBUG - 2017-07-12 02:21:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:21:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:21:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:19 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:19 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:19 --> Total execution time: 0.1203
DEBUG - 2017-07-12 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:29 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:29 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:31 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:31 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:52:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:52:34 --> Session Class Initialized
DEBUG - 2017-07-12 02:52:34 --> Session routines successfully run
DEBUG - 2017-07-12 02:52:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:52:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:52:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:54:35 --> Session Class Initialized
DEBUG - 2017-07-12 02:54:35 --> Session routines successfully run
DEBUG - 2017-07-12 02:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:54:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:54:37 --> Session Class Initialized
DEBUG - 2017-07-12 02:54:37 --> Session routines successfully run
DEBUG - 2017-07-12 02:54:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:54:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:54:38 --> Session Class Initialized
DEBUG - 2017-07-12 02:54:38 --> Session routines successfully run
DEBUG - 2017-07-12 02:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:54:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:54:40 --> Session Class Initialized
DEBUG - 2017-07-12 02:54:40 --> Session routines successfully run
DEBUG - 2017-07-12 02:54:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:54:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:54:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:54:41 --> Session Class Initialized
DEBUG - 2017-07-12 02:54:41 --> Session routines successfully run
DEBUG - 2017-07-12 02:54:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:54:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:54:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:55:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:55:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:55:06 --> Session Class Initialized
DEBUG - 2017-07-12 02:55:06 --> Session routines successfully run
DEBUG - 2017-07-12 02:55:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:55:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:55:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:55:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:08 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:08 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:10 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:10 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:11 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:11 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:13 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:13 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:15 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:15 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:20 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:20 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:23 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:23 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:57:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:57:27 --> Session Class Initialized
DEBUG - 2017-07-12 02:57:27 --> Session routines successfully run
DEBUG - 2017-07-12 02:57:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:58:04 --> Session Class Initialized
DEBUG - 2017-07-12 02:58:04 --> Session routines successfully run
DEBUG - 2017-07-12 02:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:58:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:58:50 --> Session Class Initialized
DEBUG - 2017-07-12 02:58:50 --> Session routines successfully run
DEBUG - 2017-07-12 02:58:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:58:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:58:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:58:52 --> Session Class Initialized
DEBUG - 2017-07-12 02:58:52 --> Session routines successfully run
DEBUG - 2017-07-12 02:58:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:58:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:58:57 --> Session Class Initialized
DEBUG - 2017-07-12 02:58:57 --> Session routines successfully run
DEBUG - 2017-07-12 02:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:58:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:58:59 --> Session Class Initialized
DEBUG - 2017-07-12 02:58:59 --> Session routines successfully run
DEBUG - 2017-07-12 02:58:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:58:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:58:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:01 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:01 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:27 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:27 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:31 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:31 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:33 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:33 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:37 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:37 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:39 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:39 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 02:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 02:59:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 02:59:59 --> Session Class Initialized
DEBUG - 2017-07-12 02:59:59 --> Session routines successfully run
DEBUG - 2017-07-12 02:59:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 02:59:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 02:59:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:00:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:00:03 --> Session Class Initialized
DEBUG - 2017-07-12 03:00:03 --> Session routines successfully run
DEBUG - 2017-07-12 03:00:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:00:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:00:08 --> Session Class Initialized
DEBUG - 2017-07-12 03:00:08 --> Session routines successfully run
DEBUG - 2017-07-12 03:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:00:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:00:27 --> Session Class Initialized
DEBUG - 2017-07-12 03:00:27 --> Session routines successfully run
DEBUG - 2017-07-12 03:00:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:00:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:00:29 --> Session Class Initialized
DEBUG - 2017-07-12 03:00:29 --> Session routines successfully run
DEBUG - 2017-07-12 03:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:00:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:00:31 --> Session Class Initialized
DEBUG - 2017-07-12 03:00:31 --> Session routines successfully run
DEBUG - 2017-07-12 03:00:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:00:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:00:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:07 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:07 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:08 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:08 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:10 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:10 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:14 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:14 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:19 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:19 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:20 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:01:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-07-12 03:01:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-07-12 03:01:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-07-12 03:01:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:49 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:49 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:58 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:58 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:58 --> Total execution time: 0.1310
DEBUG - 2017-07-12 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:01:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:01:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:19 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:19 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:22 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:22 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:22 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:22 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 99
ERROR - 2017-07-12 03:02:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-07-12 03:02:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-07-12 03:02:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-07-12 03:02:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:37 --> Total execution time: 0.1579
DEBUG - 2017-07-12 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:38 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:38 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:38 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:39 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:39 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:39 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:39 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:39 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:02:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:02:40 --> Session Class Initialized
DEBUG - 2017-07-12 03:02:40 --> Session routines successfully run
DEBUG - 2017-07-12 03:02:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:02:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:02:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:04:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:04:30 --> Session Class Initialized
DEBUG - 2017-07-12 03:04:30 --> Session routines successfully run
DEBUG - 2017-07-12 03:04:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:04:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:04:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:04:31 --> Session Class Initialized
DEBUG - 2017-07-12 03:04:31 --> Session routines successfully run
DEBUG - 2017-07-12 03:04:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:04:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:04:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:04:42 --> Session Class Initialized
DEBUG - 2017-07-12 03:04:42 --> Session routines successfully run
DEBUG - 2017-07-12 03:04:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:04:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:04:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:00 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:00 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:00 --> Total execution time: 0.1523
DEBUG - 2017-07-12 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:02 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:02 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:54 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:54 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:54 --> Total execution time: 0.1395
DEBUG - 2017-07-12 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:05:55 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:55 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:05:55 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:55 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:55 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:55 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:55 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:55 --> Session Class Initialized
DEBUG - 2017-07-12 03:05:55 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:55 --> Session routines successfully run
DEBUG - 2017-07-12 03:05:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:02 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:02 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:02 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 03:06:02 --> Severity: Notice --> Uninitialized string offset: 0 C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 98
DEBUG - 2017-07-12 03:06:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:44 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:44 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:46 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:46 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:54 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:54 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:56 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:56 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:58 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:58 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:06:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:06:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:06:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:06:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:06:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:06:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:01 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:01 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:02 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:02 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:04 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:04 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:06 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:06 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:16 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:16 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:16 --> Total execution time: 0.1136
DEBUG - 2017-07-12 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:51 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:51 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:52 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:52 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:07:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:07:53 --> Session Class Initialized
DEBUG - 2017-07-12 03:07:53 --> Session routines successfully run
DEBUG - 2017-07-12 03:07:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:07:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:07:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:08 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:08 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:08 --> Total execution time: 0.1338
DEBUG - 2017-07-12 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:08 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:09 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:09 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:14 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:14 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:27 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:27 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:28 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:28 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:32 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:32 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:08:34 --> Session Class Initialized
DEBUG - 2017-07-12 03:08:34 --> Session routines successfully run
DEBUG - 2017-07-12 03:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:09:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:09:09 --> Session Class Initialized
DEBUG - 2017-07-12 03:09:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:09:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:09:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:09:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:09:14 --> Session Class Initialized
DEBUG - 2017-07-12 03:09:14 --> Session routines successfully run
DEBUG - 2017-07-12 03:09:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:09:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:09:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:09:17 --> Session Class Initialized
DEBUG - 2017-07-12 03:09:17 --> Session routines successfully run
DEBUG - 2017-07-12 03:09:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:09:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:09:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:09:47 --> Session Class Initialized
DEBUG - 2017-07-12 03:09:47 --> Session routines successfully run
DEBUG - 2017-07-12 03:09:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:09:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:09:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:10:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:10:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:10:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:04 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:04 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:04 --> Total execution time: 0.1384
DEBUG - 2017-07-12 03:11:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:05 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:05 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:06 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:06 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:06 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:06 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:06 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:06 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:08 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:09 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:14 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:14 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:16 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:16 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:18 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:18 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:19 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:19 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:40 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:40 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:41 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:41 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:43 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:43 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:11:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:11:59 --> Session Class Initialized
DEBUG - 2017-07-12 03:11:59 --> Session routines successfully run
DEBUG - 2017-07-12 03:11:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:11:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:11:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:12:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:12:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:12:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:12:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:12:00 --> Session Class Initialized
DEBUG - 2017-07-12 03:12:00 --> Session routines successfully run
DEBUG - 2017-07-12 03:12:00 --> Session Class Initialized
DEBUG - 2017-07-12 03:12:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:12:00 --> Session routines successfully run
DEBUG - 2017-07-12 03:12:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:12:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:12:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:12:26 --> Session Class Initialized
DEBUG - 2017-07-12 03:12:26 --> Session routines successfully run
DEBUG - 2017-07-12 03:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:24 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:24 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:24 --> Total execution time: 0.1332
DEBUG - 2017-07-12 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:25 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:25 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:25 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:25 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:25 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:25 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:25 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:27 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:27 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:36 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:36 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:36 --> Total execution time: 0.1701
DEBUG - 2017-07-12 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:37 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:37 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:44:40 --> Session Class Initialized
DEBUG - 2017-07-12 03:44:40 --> Session routines successfully run
DEBUG - 2017-07-12 03:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:11 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:11 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:11 --> Total execution time: 0.1459
DEBUG - 2017-07-12 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:12 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:12 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:55:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:55:16 --> Session Class Initialized
DEBUG - 2017-07-12 03:55:16 --> Session routines successfully run
DEBUG - 2017-07-12 03:55:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:55:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:55:16 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-12 03:55:18 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
DEBUG - 2017-07-12 03:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:21 --> Total execution time: 0.1660
DEBUG - 2017-07-12 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:22 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 03:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:22 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:22 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:22 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:22 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 03:59:22 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:22 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:22 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:59:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:59:23 --> Session Class Initialized
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:59:23 --> Session routines successfully run
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:16 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:16 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:16 --> Total execution time: 0.1662
DEBUG - 2017-07-12 04:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:17 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:17 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:00:17 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:17 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:00:17 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:00:17 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:00:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:00:59 --> Session Class Initialized
DEBUG - 2017-07-12 04:00:59 --> Session routines successfully run
DEBUG - 2017-07-12 04:00:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:00:59 --> Total execution time: 0.1198
DEBUG - 2017-07-12 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:24 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:24 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:24 --> Total execution time: 0.1382
DEBUG - 2017-07-12 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:01:25 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:01:25 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:25 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:25 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:25 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:25 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:25 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:25 --> Session Class Initialized
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:25 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:25 --> Session routines successfully run
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:01:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:55 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:55 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:55 --> Total execution time: 0.1839
DEBUG - 2017-07-12 04:02:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:56 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:56 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:02:59 --> Session Class Initialized
DEBUG - 2017-07-12 04:02:59 --> Session routines successfully run
DEBUG - 2017-07-12 04:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:42 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:42 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:42 --> Total execution time: 0.1372
DEBUG - 2017-07-12 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:43 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:43 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:43 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:43 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:43 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:43 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:43 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:43 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:03:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:03:45 --> Session Class Initialized
DEBUG - 2017-07-12 04:03:45 --> Session routines successfully run
DEBUG - 2017-07-12 04:03:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:03:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:03:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:02 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:02 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:02 --> Total execution time: 0.1969
DEBUG - 2017-07-12 04:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:03 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:03 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:03 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:03 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:03 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:03 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:03 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:03 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:03 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:05 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:05 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:05 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:04:05 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, cannot access private method Result_pins::class_pin_printout_get() C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 437
DEBUG - 2017-07-12 04:04:05 --> Total execution time: 0.1848
DEBUG - 2017-07-12 04:04:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:04:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:04:07 --> Session Class Initialized
DEBUG - 2017-07-12 04:04:07 --> Session routines successfully run
DEBUG - 2017-07-12 04:04:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:04:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:04:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:37 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:37 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:38 --> Total execution time: 0.1253
DEBUG - 2017-07-12 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:39 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:39 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:39 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:39 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:06:39 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:06:39 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:06:39 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:39 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:06:39 --> Session Class Initialized
DEBUG - 2017-07-12 04:06:39 --> Session routines successfully run
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:06:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:29 --> Total execution time: 0.1436
DEBUG - 2017-07-12 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:07:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:07:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:07:35 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:07:35 --> Severity: Warning --> call_user_func_array() expects parameter 1 to be a valid callback, cannot access private method Result_pins::class_pin_printout_get() C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 437
DEBUG - 2017-07-12 04:07:35 --> Total execution time: 0.1708
DEBUG - 2017-07-12 04:08:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:08:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:08:23 --> Session Class Initialized
DEBUG - 2017-07-12 04:08:23 --> Session routines successfully run
DEBUG - 2017-07-12 04:08:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:08:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:08:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:08:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:09:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:09:01 --> Session Class Initialized
DEBUG - 2017-07-12 04:09:01 --> Session routines successfully run
DEBUG - 2017-07-12 04:09:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:09:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:09:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:09:05 --> Session Class Initialized
DEBUG - 2017-07-12 04:09:05 --> Session routines successfully run
DEBUG - 2017-07-12 04:09:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:09:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:09:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:51 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:51 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:51 --> Total execution time: 0.1768
DEBUG - 2017-07-12 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:53 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:53 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:53 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:53 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:53 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:53 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:53 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:53 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:53 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:53 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:55 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:55 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:19:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:19:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:19:57 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:19:57 --> Severity: Notice --> Undefined property: DompdfLib::$config C:\xampp\htdocs\school_ms\application\libraries\DompdfLib.php 96
ERROR - 2017-07-12 04:19:57 --> Severity: error --> Exception: Call to a member function item() on null C:\xampp\htdocs\school_ms\application\libraries\DompdfLib.php 96
DEBUG - 2017-07-12 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:20:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:20:29 --> Session Class Initialized
DEBUG - 2017-07-12 04:20:29 --> Session routines successfully run
DEBUG - 2017-07-12 04:20:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:20:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:20:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:20:30 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:20:30 --> Severity: Warning --> file_put_contents(C:/xampp/htdocs/school_ms/uploads/pdf_report/uploads/pdf_report/_.pdf.pdf): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\libraries\DompdfLib.php 79
ERROR - 2017-07-12 04:20:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-07-12 04:20:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-07-12 04:20:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-07-12 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:22:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:22:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:22:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:22:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:22:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:33 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:33 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:33 --> Total execution time: 0.1765
DEBUG - 2017-07-12 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:35 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:35 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:38 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:38 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:40 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:40 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:35:46 --> Session Class Initialized
DEBUG - 2017-07-12 04:35:46 --> Session routines successfully run
DEBUG - 2017-07-12 04:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:38:37 --> Session Class Initialized
DEBUG - 2017-07-12 04:38:37 --> Session routines successfully run
DEBUG - 2017-07-12 04:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:38:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:38:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:38:37 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:38:37 --> Severity: Notice --> Undefined property: DompdfLib::$config C:\xampp\htdocs\school_ms\application\libraries\DompdfLib.php 96
ERROR - 2017-07-12 04:38:37 --> Severity: error --> Exception: Call to a member function item() on null C:\xampp\htdocs\school_ms\application\libraries\DompdfLib.php 96
DEBUG - 2017-07-12 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:38:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:38:50 --> Session Class Initialized
DEBUG - 2017-07-12 04:38:50 --> Session routines successfully run
DEBUG - 2017-07-12 04:38:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:38:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:38:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:38:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:39:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:39:27 --> Session Class Initialized
DEBUG - 2017-07-12 04:39:27 --> Session routines successfully run
DEBUG - 2017-07-12 04:39:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:39:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:39:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:39:36 --> Session Class Initialized
DEBUG - 2017-07-12 04:39:36 --> Session routines successfully run
DEBUG - 2017-07-12 04:39:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:39:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:39:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:40:19 --> Session Class Initialized
DEBUG - 2017-07-12 04:40:19 --> Session routines successfully run
DEBUG - 2017-07-12 04:40:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:40:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:40:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:40:50 --> Session Class Initialized
DEBUG - 2017-07-12 04:40:50 --> Session routines successfully run
DEBUG - 2017-07-12 04:40:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:40:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:40:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:41:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:41:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:41:55 --> Session Class Initialized
DEBUG - 2017-07-12 04:41:55 --> Session routines successfully run
DEBUG - 2017-07-12 04:41:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:41:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:41:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:41:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:42:00 --> Session Class Initialized
DEBUG - 2017-07-12 04:42:00 --> Session routines successfully run
DEBUG - 2017-07-12 04:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:42:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:42:30 --> Session Class Initialized
DEBUG - 2017-07-12 04:42:30 --> Session routines successfully run
DEBUG - 2017-07-12 04:42:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:42:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:42:36 --> Session Class Initialized
DEBUG - 2017-07-12 04:42:36 --> Session routines successfully run
DEBUG - 2017-07-12 04:42:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:42:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:42:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:42:57 --> Session Class Initialized
DEBUG - 2017-07-12 04:42:57 --> Session routines successfully run
DEBUG - 2017-07-12 04:42:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:42:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:42:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:43:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:43:49 --> Session Class Initialized
DEBUG - 2017-07-12 04:43:49 --> Session routines successfully run
DEBUG - 2017-07-12 04:43:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:43:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:43:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:43:50 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-12 04:43:50 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
DEBUG - 2017-07-12 04:44:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:44:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:44:08 --> Session Class Initialized
DEBUG - 2017-07-12 04:44:08 --> Session routines successfully run
DEBUG - 2017-07-12 04:44:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:44:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:44:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:44:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 04:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 04:44:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 04:44:42 --> Session Class Initialized
DEBUG - 2017-07-12 04:44:42 --> Session routines successfully run
DEBUG - 2017-07-12 04:44:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 04:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 04:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:30:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:30:49 --> No URI present. Default controller set.
DEBUG - 2017-07-12 23:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:30:50 --> Session Class Initialized
ERROR - 2017-07-12 23:30:50 --> Session: The session cookie was not signed.
DEBUG - 2017-07-12 23:30:50 --> Session routines successfully run
DEBUG - 2017-07-12 23:30:51 --> Total execution time: 1.7474
DEBUG - 2017-07-12 23:30:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:30:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:30:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:30:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:30:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:30:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:30:52 --> Session Class Initialized
DEBUG - 2017-07-12 23:30:52 --> Session Class Initialized
DEBUG - 2017-07-12 23:30:52 --> Session Class Initialized
DEBUG - 2017-07-12 23:30:52 --> Session routines successfully run
DEBUG - 2017-07-12 23:30:52 --> Session routines successfully run
DEBUG - 2017-07-12 23:30:52 --> Session routines successfully run
DEBUG - 2017-07-12 23:30:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 23:30:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 23:30:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-12 23:30:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:30:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:30:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:30:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:30:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:30:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:30:57 --> Session Class Initialized
DEBUG - 2017-07-12 23:30:57 --> Session routines successfully run
DEBUG - 2017-07-12 23:30:57 --> Total execution time: 0.2185
DEBUG - 2017-07-12 23:31:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:31:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:31:04 --> Session Class Initialized
DEBUG - 2017-07-12 23:31:04 --> Session routines successfully run
DEBUG - 2017-07-12 23:31:04 --> User with name damilare just logged in
DEBUG - 2017-07-12 23:31:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-12 23:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-12 23:31:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-12 23:31:04 --> Session Class Initialized
DEBUG - 2017-07-12 23:31:04 --> Session routines successfully run
DEBUG - 2017-07-12 23:31:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-12 23:31:04 --> Total execution time: 0.1970

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-19 03:27:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:27:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:27:23 --> Session Class Initialized
ERROR - 2017-05-19 03:27:23 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 03:27:23 --> Session routines successfully run
DEBUG - 2017-05-19 03:27:24 --> Total execution time: 0.7177
DEBUG - 2017-05-19 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:27:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:27:43 --> Session Class Initialized
DEBUG - 2017-05-19 03:27:43 --> Session routines successfully run
DEBUG - 2017-05-19 03:27:43 --> Total execution time: 0.0580
DEBUG - 2017-05-19 03:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:28:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:28:08 --> Session Class Initialized
DEBUG - 2017-05-19 03:28:08 --> Session routines successfully run
DEBUG - 2017-05-19 03:28:08 --> User with name admin just logged in
DEBUG - 2017-05-19 03:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:28:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:28:09 --> Session Class Initialized
DEBUG - 2017-05-19 03:28:09 --> Session routines successfully run
DEBUG - 2017-05-19 03:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:28:09 --> Total execution time: 0.3086
DEBUG - 2017-05-19 03:28:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:28:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:28:19 --> Session Class Initialized
DEBUG - 2017-05-19 03:28:19 --> Session routines successfully run
DEBUG - 2017-05-19 03:28:19 --> Total execution time: 0.1641
DEBUG - 2017-05-19 03:38:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:38:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:38:53 --> Session Class Initialized
ERROR - 2017-05-19 03:38:53 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 03:38:53 --> Session routines successfully run
DEBUG - 2017-05-19 03:38:54 --> Total execution time: 0.1003
DEBUG - 2017-05-19 03:39:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:39:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:39:08 --> Session Class Initialized
DEBUG - 2017-05-19 03:39:08 --> Session routines successfully run
DEBUG - 2017-05-19 03:39:08 --> User with name admin just logged in
DEBUG - 2017-05-19 03:39:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:39:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:39:09 --> Session Class Initialized
DEBUG - 2017-05-19 03:39:09 --> Session routines successfully run
DEBUG - 2017-05-19 03:39:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:39:09 --> Total execution time: 0.3813
DEBUG - 2017-05-19 03:39:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:39:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:39:15 --> Session Class Initialized
DEBUG - 2017-05-19 03:39:15 --> Session routines successfully run
DEBUG - 2017-05-19 03:39:15 --> Total execution time: 0.0835
DEBUG - 2017-05-19 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:01 --> Session Class Initialized
ERROR - 2017-05-19 03:41:01 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 03:41:01 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:02 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:02 --> No URI present. Default controller set.
DEBUG - 2017-05-19 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:02 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:02 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:02 --> Total execution time: 0.0457
DEBUG - 2017-05-19 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:43 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:43 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:43 --> Total execution time: 0.0610
DEBUG - 2017-05-19 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:47 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:47 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:41:48 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:48 --> Session Class Initialized
DEBUG - 2017-05-19 03:41:48 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:48 --> Session routines successfully run
DEBUG - 2017-05-19 03:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:41:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:41:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:20 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:20 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:20 --> User with name admin just logged in
DEBUG - 2017-05-19 03:42:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:21 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:21 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:21 --> Total execution time: 0.2230
DEBUG - 2017-05-19 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:38 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:38 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:38 --> Total execution time: 0.0621
DEBUG - 2017-05-19 03:42:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:41 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:41 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:42:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:42:43 --> Session Class Initialized
DEBUG - 2017-05-19 03:42:43 --> Session routines successfully run
DEBUG - 2017-05-19 03:42:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:44:02 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:44:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:44:02 --> Session Class Initialized
ERROR - 2017-05-19 03:44:02 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 03:44:02 --> Session routines successfully run
DEBUG - 2017-05-19 03:44:02 --> Total execution time: 0.0462
DEBUG - 2017-05-19 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:44:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:44:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:44:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:44:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:44:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:44:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:44:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:44:13 --> Session Class Initialized
DEBUG - 2017-05-19 03:44:13 --> Session routines successfully run
DEBUG - 2017-05-19 03:44:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:44:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:44:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:26 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:26 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:26 --> Total execution time: 0.0634
DEBUG - 2017-05-19 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:27 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:27 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:27 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:27 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:28 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:28 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:40 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:40 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:40 --> User with name admin just logged in
DEBUG - 2017-05-19 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:41 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:41 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:41 --> Total execution time: 0.1757
DEBUG - 2017-05-19 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:50 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:50 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:50 --> Total execution time: 0.0670
DEBUG - 2017-05-19 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:50 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:50 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:50 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:50 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:51 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:51 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:51 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:51 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:51 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:51 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:51 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:52 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:52 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:52 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:52 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:45:52 --> Session Class Initialized
DEBUG - 2017-05-19 03:45:52 --> Session routines successfully run
DEBUG - 2017-05-19 03:45:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:45:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:47:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:47:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:47:16 --> Session Class Initialized
DEBUG - 2017-05-19 03:47:16 --> Session routines successfully run
DEBUG - 2017-05-19 03:47:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:47:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:47:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:47:17 --> Session Class Initialized
DEBUG - 2017-05-19 03:47:17 --> Session routines successfully run
DEBUG - 2017-05-19 03:47:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:47:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:47:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:47:24 --> Session Class Initialized
DEBUG - 2017-05-19 03:47:24 --> Session routines successfully run
DEBUG - 2017-05-19 03:47:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:47:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:49:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:49:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:49:43 --> Session Class Initialized
DEBUG - 2017-05-19 03:49:43 --> Session routines successfully run
DEBUG - 2017-05-19 03:49:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:49:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:21 --> Session Class Initialized
ERROR - 2017-05-19 03:51:21 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 03:51:21 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:21 --> Total execution time: 0.0993
DEBUG - 2017-05-19 03:51:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:27 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:27 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:27 --> Total execution time: 0.1931
DEBUG - 2017-05-19 03:51:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:28 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:28 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:28 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:28 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:29 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:29 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:29 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:29 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:29 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:29 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:29 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:36 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:36 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:36 --> User with name admin just logged in
DEBUG - 2017-05-19 03:51:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:36 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:36 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:37 --> Total execution time: 0.1602
DEBUG - 2017-05-19 03:51:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:42 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:42 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:43 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:43 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:44 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:44 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:46 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:46 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:47 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:47 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:48 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:48 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:51:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:51:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:51:49 --> Session Class Initialized
DEBUG - 2017-05-19 03:51:49 --> Session routines successfully run
DEBUG - 2017-05-19 03:51:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 03:51:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:52:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:52:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:52:38 --> Session Class Initialized
DEBUG - 2017-05-19 03:52:38 --> Session routines successfully run
DEBUG - 2017-05-19 03:52:38 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-19 03:52:38 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-19 03:52:38 --> Total execution time: 0.2467
DEBUG - 2017-05-19 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:53:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:53:44 --> Session Class Initialized
DEBUG - 2017-05-19 03:53:44 --> Session routines successfully run
DEBUG - 2017-05-19 03:53:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:53:44 --> Total execution time: 0.2246
DEBUG - 2017-05-19 03:53:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:53:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:53:55 --> Session Class Initialized
DEBUG - 2017-05-19 03:53:55 --> Session routines successfully run
DEBUG - 2017-05-19 03:53:56 --> Total execution time: 0.8803
DEBUG - 2017-05-19 03:54:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:54:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:54:09 --> Session Class Initialized
DEBUG - 2017-05-19 03:54:09 --> Session routines successfully run
DEBUG - 2017-05-19 03:54:09 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-19 03:54:09 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-19 03:54:09 --> Total execution time: 0.1357
DEBUG - 2017-05-19 03:55:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:55:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:55:31 --> Session Class Initialized
DEBUG - 2017-05-19 03:55:31 --> Session routines successfully run
DEBUG - 2017-05-19 03:55:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 03:55:32 --> Total execution time: 0.2536
DEBUG - 2017-05-19 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 03:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 03:56:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 03:56:16 --> Session Class Initialized
DEBUG - 2017-05-19 03:56:16 --> Session routines successfully run
DEBUG - 2017-05-19 03:56:16 --> Total execution time: 0.5070
DEBUG - 2017-05-19 04:01:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 04:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 04:01:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 04:01:34 --> Session Class Initialized
DEBUG - 2017-05-19 04:01:34 --> Session routines successfully run
DEBUG - 2017-05-19 04:01:34 --> Total execution time: 0.7613
DEBUG - 2017-05-19 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 04:21:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 04:21:29 --> Session Class Initialized
DEBUG - 2017-05-19 04:21:29 --> Session routines successfully run
DEBUG - 2017-05-19 04:21:30 --> Total execution time: 0.5052
DEBUG - 2017-05-19 06:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 06:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 06:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 06:58:01 --> Session Class Initialized
ERROR - 2017-05-19 06:58:01 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 06:58:01 --> Session routines successfully run
DEBUG - 2017-05-19 06:58:01 --> Total execution time: 0.5583
DEBUG - 2017-05-19 06:58:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 06:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 06:58:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 06:58:32 --> Session Class Initialized
DEBUG - 2017-05-19 06:58:32 --> Session routines successfully run
DEBUG - 2017-05-19 06:58:32 --> User with name admin just logged in
DEBUG - 2017-05-19 06:58:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 06:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 06:58:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 06:58:33 --> Session Class Initialized
DEBUG - 2017-05-19 06:58:33 --> Session routines successfully run
DEBUG - 2017-05-19 06:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 06:58:33 --> Total execution time: 0.3274
DEBUG - 2017-05-19 06:58:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 06:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 06:58:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 06:58:40 --> Session Class Initialized
DEBUG - 2017-05-19 06:58:40 --> Session routines successfully run
DEBUG - 2017-05-19 06:58:40 --> Total execution time: 0.1629
DEBUG - 2017-05-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:01 --> Session Class Initialized
ERROR - 2017-05-19 07:03:01 --> Session: The session cookie was not signed.
DEBUG - 2017-05-19 07:03:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:02 --> Total execution time: 0.1492
DEBUG - 2017-05-19 07:03:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:06 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:06 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:03:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:03:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:03:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:07 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:07 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:03:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:03:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:07 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:07 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:03:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:03:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:42 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:42 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:42 --> User with name admin just logged in
DEBUG - 2017-05-19 07:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:03:43 --> Total execution time: 0.1760
DEBUG - 2017-05-19 07:03:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:03:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:03:59 --> Session Class Initialized
DEBUG - 2017-05-19 07:03:59 --> Session routines successfully run
DEBUG - 2017-05-19 07:03:59 --> Total execution time: 0.0586
DEBUG - 2017-05-19 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:00 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:00 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:00 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:00 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:00 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:00 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:01 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:21 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:21 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:04:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:04:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:04:34 --> Session Class Initialized
DEBUG - 2017-05-19 07:04:34 --> Session routines successfully run
DEBUG - 2017-05-19 07:04:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:04:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:14:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:14:40 --> Session Class Initialized
DEBUG - 2017-05-19 07:14:40 --> Session routines successfully run
DEBUG - 2017-05-19 07:14:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:14:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:14:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:14:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:14:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:14:56 --> Session Class Initialized
DEBUG - 2017-05-19 07:14:56 --> Session routines successfully run
DEBUG - 2017-05-19 07:14:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:14:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:35 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:35 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:35 --> Total execution time: 0.1158
DEBUG - 2017-05-19 07:25:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:42 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:42 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:42 --> Total execution time: 0.1459
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:43 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:44 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:44 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:44 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:44 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:25:44 --> Session Class Initialized
DEBUG - 2017-05-19 07:25:44 --> Session routines successfully run
DEBUG - 2017-05-19 07:25:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:25:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:26:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:26:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:26:20 --> Session Class Initialized
DEBUG - 2017-05-19 07:26:20 --> Session routines successfully run
DEBUG - 2017-05-19 07:26:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:26:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:26:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:26:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:26:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:26:25 --> Session Class Initialized
DEBUG - 2017-05-19 07:26:25 --> Session routines successfully run
DEBUG - 2017-05-19 07:26:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:26:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:37:48 --> Session Class Initialized
DEBUG - 2017-05-19 07:37:48 --> Session routines successfully run
DEBUG - 2017-05-19 07:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:37:55 --> Session Class Initialized
DEBUG - 2017-05-19 07:37:55 --> Session routines successfully run
DEBUG - 2017-05-19 07:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:41:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:41:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:41:59 --> Session Class Initialized
DEBUG - 2017-05-19 07:41:59 --> Session routines successfully run
DEBUG - 2017-05-19 07:41:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:41:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:41:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:42:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:42:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:42:06 --> Session Class Initialized
DEBUG - 2017-05-19 07:42:06 --> Session routines successfully run
DEBUG - 2017-05-19 07:42:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:56:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:56:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:56:10 --> Session Class Initialized
DEBUG - 2017-05-19 07:56:10 --> Session routines successfully run
DEBUG - 2017-05-19 07:56:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:56:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:56:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:56:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:56:16 --> Session Class Initialized
DEBUG - 2017-05-19 07:56:16 --> Session routines successfully run
DEBUG - 2017-05-19 07:56:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:56:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:58:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:58:57 --> Session Class Initialized
DEBUG - 2017-05-19 07:58:57 --> Session routines successfully run
DEBUG - 2017-05-19 07:58:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 07:59:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 07:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 07:59:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 07:59:04 --> Session Class Initialized
DEBUG - 2017-05-19 07:59:04 --> Session routines successfully run
DEBUG - 2017-05-19 07:59:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 07:59:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:01:21 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:01:21 --> Session Class Initialized
DEBUG - 2017-05-19 08:01:21 --> Session routines successfully run
DEBUG - 2017-05-19 08:01:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:01:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:01:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:01:46 --> Session Class Initialized
DEBUG - 2017-05-19 08:01:46 --> Session routines successfully run
DEBUG - 2017-05-19 08:01:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:01:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:05:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:05:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:05:49 --> Session Class Initialized
DEBUG - 2017-05-19 08:05:49 --> Session routines successfully run
DEBUG - 2017-05-19 08:05:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:05:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:05:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:05:58 --> Session Class Initialized
DEBUG - 2017-05-19 08:05:58 --> Session routines successfully run
DEBUG - 2017-05-19 08:05:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:05:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:07:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:07:35 --> Session Class Initialized
DEBUG - 2017-05-19 08:07:35 --> Session routines successfully run
DEBUG - 2017-05-19 08:07:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:07:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:07:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:07:43 --> Session Class Initialized
DEBUG - 2017-05-19 08:07:43 --> Session routines successfully run
DEBUG - 2017-05-19 08:07:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:07:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:10:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:10:39 --> Session Class Initialized
DEBUG - 2017-05-19 08:10:39 --> Session routines successfully run
DEBUG - 2017-05-19 08:10:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:10:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:10:45 --> Session Class Initialized
DEBUG - 2017-05-19 08:10:45 --> Session routines successfully run
DEBUG - 2017-05-19 08:10:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:10:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:13:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:13:48 --> Session Class Initialized
DEBUG - 2017-05-19 08:13:48 --> Session routines successfully run
DEBUG - 2017-05-19 08:13:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:14:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:14:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:14:01 --> Session Class Initialized
DEBUG - 2017-05-19 08:14:01 --> Session routines successfully run
DEBUG - 2017-05-19 08:14:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:14:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:16:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:16:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:16:49 --> Session Class Initialized
DEBUG - 2017-05-19 08:16:49 --> Session routines successfully run
DEBUG - 2017-05-19 08:16:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:16:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:16:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:16:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:16:58 --> Session Class Initialized
DEBUG - 2017-05-19 08:16:58 --> Session routines successfully run
DEBUG - 2017-05-19 08:16:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:16:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:19:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:19:49 --> Session Class Initialized
DEBUG - 2017-05-19 08:19:49 --> Session routines successfully run
DEBUG - 2017-05-19 08:19:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:19:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:19:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:19:59 --> Session Class Initialized
DEBUG - 2017-05-19 08:19:59 --> Session routines successfully run
DEBUG - 2017-05-19 08:19:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:19:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:22:13 --> Session Class Initialized
DEBUG - 2017-05-19 08:22:13 --> Session routines successfully run
DEBUG - 2017-05-19 08:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:22:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:22:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:22:20 --> Session Class Initialized
DEBUG - 2017-05-19 08:22:20 --> Session routines successfully run
DEBUG - 2017-05-19 08:22:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:22:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:26:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:26:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:26:45 --> Session Class Initialized
DEBUG - 2017-05-19 08:26:45 --> Session routines successfully run
DEBUG - 2017-05-19 08:26:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:26:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:26:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:26:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:26:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:26:52 --> Session Class Initialized
DEBUG - 2017-05-19 08:26:52 --> Session routines successfully run
DEBUG - 2017-05-19 08:26:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:26:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:33:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:33:14 --> Session Class Initialized
DEBUG - 2017-05-19 08:33:14 --> Session routines successfully run
DEBUG - 2017-05-19 08:33:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:33:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:33:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:33:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:33:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:33:22 --> Session Class Initialized
DEBUG - 2017-05-19 08:33:22 --> Session routines successfully run
DEBUG - 2017-05-19 08:33:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:33:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:36:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:36:50 --> Session Class Initialized
DEBUG - 2017-05-19 08:36:50 --> Session routines successfully run
DEBUG - 2017-05-19 08:36:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:36:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:36:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:36:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:36:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:36:56 --> Session Class Initialized
DEBUG - 2017-05-19 08:36:56 --> Session routines successfully run
DEBUG - 2017-05-19 08:36:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:36:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:40:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:40:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:40:08 --> Session Class Initialized
DEBUG - 2017-05-19 08:40:08 --> Session routines successfully run
DEBUG - 2017-05-19 08:40:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:40:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:40:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:40:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:40:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:40:14 --> Session Class Initialized
DEBUG - 2017-05-19 08:40:14 --> Session routines successfully run
DEBUG - 2017-05-19 08:40:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:40:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:44:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:44:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:44:33 --> Session Class Initialized
DEBUG - 2017-05-19 08:44:33 --> Session routines successfully run
DEBUG - 2017-05-19 08:44:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:44:41 --> Session Class Initialized
DEBUG - 2017-05-19 08:44:41 --> Session routines successfully run
DEBUG - 2017-05-19 08:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:47:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:47:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:47:54 --> Session Class Initialized
DEBUG - 2017-05-19 08:47:54 --> Session routines successfully run
DEBUG - 2017-05-19 08:47:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:47:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:47:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:47:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:47:59 --> Session Class Initialized
DEBUG - 2017-05-19 08:47:59 --> Session routines successfully run
DEBUG - 2017-05-19 08:47:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:47:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:51:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:51:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:51:20 --> Session Class Initialized
DEBUG - 2017-05-19 08:51:20 --> Session routines successfully run
DEBUG - 2017-05-19 08:51:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:51:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:51:28 --> Session Class Initialized
DEBUG - 2017-05-19 08:51:28 --> Session routines successfully run
DEBUG - 2017-05-19 08:51:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:51:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:53:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:53:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:53:59 --> Session Class Initialized
DEBUG - 2017-05-19 08:53:59 --> Session routines successfully run
DEBUG - 2017-05-19 08:53:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:53:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:53:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:54:07 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:54:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:54:07 --> Session Class Initialized
DEBUG - 2017-05-19 08:54:07 --> Session routines successfully run
DEBUG - 2017-05-19 08:54:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:54:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:54:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:54:28 --> Session Class Initialized
DEBUG - 2017-05-19 08:54:28 --> Session routines successfully run
DEBUG - 2017-05-19 08:54:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:54:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:54:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:54:40 --> Session Class Initialized
DEBUG - 2017-05-19 08:54:40 --> Session routines successfully run
DEBUG - 2017-05-19 08:54:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:54:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:56:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:56:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:56:32 --> Session Class Initialized
DEBUG - 2017-05-19 08:56:32 --> Session routines successfully run
DEBUG - 2017-05-19 08:56:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:56:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:56:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:56:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:56:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:56:43 --> Session Class Initialized
DEBUG - 2017-05-19 08:56:43 --> Session routines successfully run
DEBUG - 2017-05-19 08:56:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:56:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:58:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:58:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:58:35 --> Session Class Initialized
DEBUG - 2017-05-19 08:58:35 --> Session routines successfully run
DEBUG - 2017-05-19 08:58:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:58:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:58:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 08:58:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 08:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 08:58:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 08:58:48 --> Session Class Initialized
DEBUG - 2017-05-19 08:58:48 --> Session routines successfully run
DEBUG - 2017-05-19 08:58:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 08:58:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:02:04 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:02:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:02:04 --> Session Class Initialized
DEBUG - 2017-05-19 09:02:04 --> Session routines successfully run
DEBUG - 2017-05-19 09:02:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:02:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:02:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:02:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:02:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:02:12 --> Session Class Initialized
DEBUG - 2017-05-19 09:02:12 --> Session routines successfully run
DEBUG - 2017-05-19 09:02:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:02:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:04:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:04:38 --> Session Class Initialized
DEBUG - 2017-05-19 09:04:38 --> Session routines successfully run
DEBUG - 2017-05-19 09:04:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:04:45 --> Session Class Initialized
DEBUG - 2017-05-19 09:04:45 --> Session routines successfully run
DEBUG - 2017-05-19 09:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:04:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:07:24 --> Session Class Initialized
DEBUG - 2017-05-19 09:07:24 --> Session routines successfully run
DEBUG - 2017-05-19 09:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:07:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:07:32 --> Session Class Initialized
DEBUG - 2017-05-19 09:07:32 --> Session routines successfully run
DEBUG - 2017-05-19 09:07:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:07:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:09:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:09:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:09:31 --> Session Class Initialized
DEBUG - 2017-05-19 09:09:31 --> Session routines successfully run
DEBUG - 2017-05-19 09:09:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:09:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:09:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:09:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:09:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:09:41 --> Session Class Initialized
DEBUG - 2017-05-19 09:09:41 --> Session routines successfully run
DEBUG - 2017-05-19 09:09:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:09:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:13:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:13:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:13:23 --> Session Class Initialized
DEBUG - 2017-05-19 09:13:23 --> Session routines successfully run
DEBUG - 2017-05-19 09:13:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:13:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:13:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:13:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:13:32 --> Session Class Initialized
DEBUG - 2017-05-19 09:13:32 --> Session routines successfully run
DEBUG - 2017-05-19 09:13:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:13:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:17:51 --> Session Class Initialized
DEBUG - 2017-05-19 09:17:51 --> Session routines successfully run
DEBUG - 2017-05-19 09:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:17:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:17:51 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-19 09:17:51 --> Severity: Notice --> Undefined variable: existing_subject_ids /home/evangelm/public_html/school_ms/application/models/SubjectSettings_model.php 109
ERROR - 2017-05-19 09:17:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/evangelm/public_html/school_ms/system/core/Exceptions.php:272) /home/evangelm/public_html/school_ms/application/libraries/REST_Controller.php 491
ERROR - 2017-05-19 09:17:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/evangelm/public_html/school_ms/system/core/Exceptions.php:272) /home/evangelm/public_html/school_ms/system/core/Common.php 568
ERROR - 2017-05-19 09:17:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/evangelm/public_html/school_ms/system/core/Exceptions.php:272) /home/evangelm/public_html/school_ms/application/libraries/REST_Controller.php 514
DEBUG - 2017-05-19 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:18:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:18:03 --> Session Class Initialized
DEBUG - 2017-05-19 09:18:03 --> Session routines successfully run
DEBUG - 2017-05-19 09:18:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:18:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:19:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:19:44 --> Session Class Initialized
DEBUG - 2017-05-19 09:19:44 --> Session routines successfully run
DEBUG - 2017-05-19 09:19:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:19:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-19 09:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-19 09:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-19 09:19:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-19 09:19:48 --> Session Class Initialized
DEBUG - 2017-05-19 09:19:48 --> Session routines successfully run
DEBUG - 2017-05-19 09:19:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-19 09:19:48 --> Myapp class already loaded. Second attempt ignored.

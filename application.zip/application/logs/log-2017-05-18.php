<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-18 17:21:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-18 17:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-18 17:21:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-18 17:21:54 --> Session Class Initialized
ERROR - 2017-05-18 17:21:54 --> Session: The session cookie was not signed.
DEBUG - 2017-05-18 17:21:54 --> Session routines successfully run
DEBUG - 2017-05-18 17:21:54 --> Total execution time: 0.7372

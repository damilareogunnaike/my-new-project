<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-16 16:33:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:33:36 --> No URI present. Default controller set.
DEBUG - 2017-07-16 16:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:33:38 --> Session Class Initialized
ERROR - 2017-07-16 16:33:38 --> Session: The session cookie was not signed.
DEBUG - 2017-07-16 16:33:38 --> Session routines successfully run
DEBUG - 2017-07-16 16:33:39 --> Total execution time: 2.9998
DEBUG - 2017-07-16 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:33:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:33:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:33:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:33:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:33:41 --> Session Class Initialized
DEBUG - 2017-07-16 16:33:41 --> Session routines successfully run
DEBUG - 2017-07-16 16:33:41 --> Session Class Initialized
DEBUG - 2017-07-16 16:33:41 --> Session Class Initialized
DEBUG - 2017-07-16 16:33:41 --> Session routines successfully run
DEBUG - 2017-07-16 16:33:41 --> Session routines successfully run
DEBUG - 2017-07-16 16:33:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:33:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:33:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:33:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:33:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:33:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:33:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:33:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:33:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:33:59 --> Session Class Initialized
DEBUG - 2017-07-16 16:33:59 --> Session routines successfully run
DEBUG - 2017-07-16 16:33:59 --> Total execution time: 0.3010
DEBUG - 2017-07-16 16:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:14 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:14 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:14 --> User with name damilare just logged in
DEBUG - 2017-07-16 16:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:14 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:14 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:15 --> Total execution time: 0.4137
DEBUG - 2017-07-16 16:46:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:21 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:21 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:21 --> Total execution time: 0.1368
DEBUG - 2017-07-16 16:46:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:22 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:22 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:22 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:22 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:22 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:22 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:22 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:22 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:22 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:22 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:24 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:24 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:33 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:33 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:34 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:34 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:34 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:34 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:45 --> No URI present. Default controller set.
DEBUG - 2017-07-16 16:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:45 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:45 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:45 --> Total execution time: 0.1682
DEBUG - 2017-07-16 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:46:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:46:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:46:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:50:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:50:04 --> Session Class Initialized
DEBUG - 2017-07-16 16:50:04 --> Session routines successfully run
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:50:04 --> Session Class Initialized
DEBUG - 2017-07-16 16:50:04 --> Session Class Initialized
DEBUG - 2017-07-16 16:50:04 --> Session routines successfully run
DEBUG - 2017-07-16 16:50:04 --> Session routines successfully run
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:46 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:46 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:50 --> No URI present. Default controller set.
DEBUG - 2017-07-16 16:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:50 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:51 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:51 --> Total execution time: 0.3235
DEBUG - 2017-07-16 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:52 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:52 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:52 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:52 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:52 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:52 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:55:53 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:53 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:53 --> Session Class Initialized
DEBUG - 2017-07-16 16:55:53 --> Session routines successfully run
DEBUG - 2017-07-16 16:55:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:55:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:55:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 16:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 16:56:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 16:56:08 --> Session Class Initialized
DEBUG - 2017-07-16 16:56:08 --> Session routines successfully run
DEBUG - 2017-07-16 16:56:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 16:56:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:56:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 16:56:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:10:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:10:51 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:10:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:10:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:10:51 --> Total execution time: 0.1229
DEBUG - 2017-07-16 17:10:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:10:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:10:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:10:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:10:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:10:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:10:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:10:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:10:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:10:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:10:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:10:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:10:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:10:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:08 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:08 --> Total execution time: 0.1766
DEBUG - 2017-07-16 17:14:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:14 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:14 --> Total execution time: 0.1578
DEBUG - 2017-07-16 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:14:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:14:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:14:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:14:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:14:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:14:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:13 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:13 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:13 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:13 --> Total execution time: 0.1235
DEBUG - 2017-07-16 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:38 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:38 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:38 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:38 --> Total execution time: 0.1702
DEBUG - 2017-07-16 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:15:39 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:39 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:15:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:39 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:39 --> Session Class Initialized
DEBUG - 2017-07-16 17:15:39 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:39 --> Session routines successfully run
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:15:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:15:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:11 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:11 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:11 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:11 --> Total execution time: 0.1489
DEBUG - 2017-07-16 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:16:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:16:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:28 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:28 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:16:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:16:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:16:35 --> Session Class Initialized
DEBUG - 2017-07-16 17:16:35 --> Session routines successfully run
DEBUG - 2017-07-16 17:16:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:16:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:16:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:01 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:01 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:01 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:01 --> Total execution time: 0.1410
DEBUG - 2017-07-16 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:02 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:02 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:02 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:02 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:02 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:02 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:17:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:17:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:17:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:17:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:17:09 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:17:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:28:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:12 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:13 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:13 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:13 --> Total execution time: 0.1142
DEBUG - 2017-07-16 17:28:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:13 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:13 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:13 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:13 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:13 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:13 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:14 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:41 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:42 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:42 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:42 --> Total execution time: 0.1690
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:28:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:28:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:28:44 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:28:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:29:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:15 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:15 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:15 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:15 --> Total execution time: 0.1528
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:18 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:29:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:29:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:57 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:57 --> Total execution time: 0.2238
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:29:59 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:59 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:59 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:59 --> Session Class Initialized
DEBUG - 2017-07-16 17:29:59 --> Session routines successfully run
DEBUG - 2017-07-16 17:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:00 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:00 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:00 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:00 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:00 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:00 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:00 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:00 --> Session routines successfully run
ERROR - 2017-07-16 17:30:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:45 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:45 --> Total execution time: 0.2111
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:30:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:30:47 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:47 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:47 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:47 --> Session Class Initialized
DEBUG - 2017-07-16 17:30:47 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:47 --> Session routines successfully run
DEBUG - 2017-07-16 17:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:30:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:08 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:08 --> Total execution time: 0.2524
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:10 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:10 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:10 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:10 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:10 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:10 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:10 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:10 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:11 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:11 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:11 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:11 --> Session routines successfully run
ERROR - 2017-07-16 17:31:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:47 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:47 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:47 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:47 --> Total execution time: 0.6674
DEBUG - 2017-07-16 17:31:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:31:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:50 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:31:50 --> Session Class Initialized
DEBUG - 2017-07-16 17:31:50 --> Session routines successfully run
DEBUG - 2017-07-16 17:31:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:31:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:31:50 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:31:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:32:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:14 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:15 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:15 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:15 --> Total execution time: 0.1322
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:17 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
ERROR - 2017-07-16 17:32:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:49 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:49 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:49 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:49 --> Total execution time: 0.1517
DEBUG - 2017-07-16 17:32:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:32:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:32:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:32:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:32:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
ERROR - 2017-07-16 17:32:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:25 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:25 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:25 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:25 --> Total execution time: 0.1671
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:27 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:27 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
ERROR - 2017-07-16 17:33:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:36 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:36 --> Total execution time: 0.2116
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:37 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
ERROR - 2017-07-16 17:33:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:37 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:42 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:42 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:42 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:43 --> Total execution time: 0.3182
DEBUG - 2017-07-16 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:43 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:43 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:44 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:44 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:33:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:50 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:50 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:50 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:50 --> Total execution time: 0.1631
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:33:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:33:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:52 --> Session Class Initialized
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:52 --> Session routines successfully run
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:33:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:33:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:07 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:07 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:07 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:07 --> Total execution time: 0.3322
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:34:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:34:09 --> Session Class Initialized
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:09 --> Session routines successfully run
DEBUG - 2017-07-16 17:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:34:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:34:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:26 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:26 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:26 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:26 --> Total execution time: 0.1776
DEBUG - 2017-07-16 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:28 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:28 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:28 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:28 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:28 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:28 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:35:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:45 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:45 --> Total execution time: 0.1920
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:47 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:35:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:35:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:51 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:51 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:51 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:51 --> Total execution time: 0.1777
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:53 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:53 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:53 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:53 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:53 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:53 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:35:54 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:54 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:54 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:54 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:35:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-16 17:35:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:35:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:35:54 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:54 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:54 --> Session Class Initialized
DEBUG - 2017-07-16 17:35:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:55 --> Session routines successfully run
DEBUG - 2017-07-16 17:35:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:35:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:35:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:10 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:11 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:11 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:11 --> Total execution time: 0.3089
DEBUG - 2017-07-16 17:36:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Session Class Initialized
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Session routines successfully run
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:36:12 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:36:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:37:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:14 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:14 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:14 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:14 --> Total execution time: 0.1895
DEBUG - 2017-07-16 17:37:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:37:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:37:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:22 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:22 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:34 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:34 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:34 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:34 --> Total execution time: 0.2257
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
ERROR - 2017-07-16 17:37:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:37:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:36 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:41 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:41 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:53 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:53 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:55 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:55 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:55 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:55 --> Total execution time: 0.1309
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:37:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:37:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:37:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:38:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:05 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:05 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:29 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:29 --> Total execution time: 0.1489
DEBUG - 2017-07-16 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:31 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:38:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:55 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:55 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:55 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:55 --> Total execution time: 0.1678
DEBUG - 2017-07-16 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:56 --> Session routines successfully run
ERROR - 2017-07-16 17:38:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:38:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:38:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:38:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:06 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:06 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:06 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:06 --> Total execution time: 0.1594
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:07 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:07 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:07 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:07 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:07 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:07 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:39:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:08 --> Session Class Initialized
DEBUG - 2017-07-16 17:39:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:08 --> Session routines successfully run
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:39:08 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:39:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:41:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:41:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:41:00 --> Session Class Initialized
DEBUG - 2017-07-16 17:41:00 --> Session routines successfully run
DEBUG - 2017-07-16 17:41:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:41:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:55 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:56 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:56 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:56 --> Total execution time: 0.1911
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:57 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:43:57 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:58 --> Session Class Initialized
DEBUG - 2017-07-16 17:43:58 --> Session routines successfully run
DEBUG - 2017-07-16 17:43:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:43:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:43:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 17:43:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ')' at line 1 - Invalid query: CALL getStudentsClass(985, )
DEBUG - 2017-07-16 17:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:29 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:29 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:29 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:29 --> Total execution time: 0.1898
DEBUG - 2017-07-16 17:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:40 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:40 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:40 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:41 --> Total execution time: 0.1345
DEBUG - 2017-07-16 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:46 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:46 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:44:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:44:59 --> No URI present. Default controller set.
DEBUG - 2017-07-16 17:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:44:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:44:59 --> Session Class Initialized
DEBUG - 2017-07-16 17:44:59 --> Session routines successfully run
DEBUG - 2017-07-16 17:44:59 --> Total execution time: 0.1459
DEBUG - 2017-07-16 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 17:45:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 17:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 17:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 17:45:45 --> Session Class Initialized
DEBUG - 2017-07-16 17:45:45 --> Session routines successfully run
DEBUG - 2017-07-16 17:45:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 17:45:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:49:12 --> No URI present. Default controller set.
DEBUG - 2017-07-16 21:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:49:12 --> Session Class Initialized
ERROR - 2017-07-16 21:49:12 --> Session: The session cookie was not signed.
DEBUG - 2017-07-16 21:49:12 --> Session routines successfully run
DEBUG - 2017-07-16 21:49:12 --> Total execution time: 0.1271
DEBUG - 2017-07-16 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:49:12 --> Session Class Initialized
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:49:12 --> Session routines successfully run
DEBUG - 2017-07-16 21:49:12 --> Session Class Initialized
DEBUG - 2017-07-16 21:49:12 --> Session routines successfully run
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:49:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:49:12 --> Session Class Initialized
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:49:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:49:12 --> Session routines successfully run
DEBUG - 2017-07-16 21:49:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:49:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:49:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:54:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:54:40 --> Session Class Initialized
DEBUG - 2017-07-16 21:54:40 --> Session routines successfully run
DEBUG - 2017-07-16 21:54:40 --> Total execution time: 0.1141
DEBUG - 2017-07-16 21:54:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:54:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:54:46 --> Session Class Initialized
DEBUG - 2017-07-16 21:54:46 --> Session routines successfully run
DEBUG - 2017-07-16 21:54:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:54:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:54:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:54:53 --> Session Class Initialized
DEBUG - 2017-07-16 21:54:53 --> Session routines successfully run
DEBUG - 2017-07-16 21:54:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:54:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:54:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:55:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:55:34 --> Session Class Initialized
DEBUG - 2017-07-16 21:55:34 --> Session routines successfully run
DEBUG - 2017-07-16 21:55:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:55:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:55:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:55:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:55:36 --> Session Class Initialized
DEBUG - 2017-07-16 21:55:36 --> Session routines successfully run
DEBUG - 2017-07-16 21:55:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:55:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:55:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:55:38 --> Session Class Initialized
DEBUG - 2017-07-16 21:55:38 --> Session routines successfully run
DEBUG - 2017-07-16 21:55:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:55:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 21:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 21:55:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 21:55:39 --> Session Class Initialized
DEBUG - 2017-07-16 21:55:39 --> Session routines successfully run
DEBUG - 2017-07-16 21:55:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 21:55:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 21:55:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:18 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:18 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:18 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:18 --> Total execution time: 0.1997
DEBUG - 2017-07-16 22:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:19 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:19 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:19 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:19 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:19 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:19 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:30 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:30 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:30 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:30 --> Total execution time: 0.1244
DEBUG - 2017-07-16 22:34:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:33 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:34 --> Total execution time: 0.1530
DEBUG - 2017-07-16 22:34:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:35 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:36 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:36 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:36 --> Total execution time: 0.1147
DEBUG - 2017-07-16 22:34:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:45 --> User with name damilare just logged in
DEBUG - 2017-07-16 22:34:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:46 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:46 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:46 --> Total execution time: 0.2834
DEBUG - 2017-07-16 22:34:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:49 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:49 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:49 --> Total execution time: 0.1396
DEBUG - 2017-07-16 22:34:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:50 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:50 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:50 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:50 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:50 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:50 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:50 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:50 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:51 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:51 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:59 --> Session Class Initialized
DEBUG - 2017-07-16 22:34:59 --> Session routines successfully run
DEBUG - 2017-07-16 22:34:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:34:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:34:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:10 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:10 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:13 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:13 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:23 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:23 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:35:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:35:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:35:32 --> Session Class Initialized
DEBUG - 2017-07-16 22:35:32 --> Session routines successfully run
DEBUG - 2017-07-16 22:35:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:35:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:36:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:36:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:36:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:36:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:36:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:36:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:36:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:36:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:36:28 --> Session Class Initialized
DEBUG - 2017-07-16 22:36:28 --> Session routines successfully run
DEBUG - 2017-07-16 22:36:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:36:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:36:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:36:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:36:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:36:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:36:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:36:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:36:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:36:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:36:46 --> Session Class Initialized
DEBUG - 2017-07-16 22:36:46 --> Session routines successfully run
DEBUG - 2017-07-16 22:36:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:36:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:14 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:14 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:14 --> Total execution time: 0.1964
DEBUG - 2017-07-16 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:17 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:17 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:17 --> Total execution time: 0.2347
DEBUG - 2017-07-16 22:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:17 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:17 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:17 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:17 --> Total execution time: 0.2145
DEBUG - 2017-07-16 22:41:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:24 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:24 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:24 --> Total execution time: 0.1575
DEBUG - 2017-07-16 22:41:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:24 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:24 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:24 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:24 --> Total execution time: 0.1961
DEBUG - 2017-07-16 22:41:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:27 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:27 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:27 --> Total execution time: 0.1523
DEBUG - 2017-07-16 22:41:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:27 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:28 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:28 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:28 --> Total execution time: 0.1796
DEBUG - 2017-07-16 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:31 --> Total execution time: 0.1762
DEBUG - 2017-07-16 22:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:31 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:31 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:31 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:31 --> Total execution time: 0.2055
DEBUG - 2017-07-16 22:41:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:39 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:39 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:45 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 22:41:45 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-16 22:41:45 --> Total execution time: 0.2120
DEBUG - 2017-07-16 22:41:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:48 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:48 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:48 --> Total execution time: 0.1899
DEBUG - 2017-07-16 22:41:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:41:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:41:54 --> Session Class Initialized
DEBUG - 2017-07-16 22:41:54 --> Session routines successfully run
DEBUG - 2017-07-16 22:41:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:41:54 --> Total execution time: 0.2187
DEBUG - 2017-07-16 22:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:01 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:01 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:01 --> Total execution time: 0.1992
DEBUG - 2017-07-16 22:42:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:05 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:05 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:05 --> Total execution time: 0.2252
ERROR - 2017-07-16 22:42:09 --> Severity: Error --> Maximum execution time of 30 seconds exceeded C:\xampp\htdocs\school_ms\system\database\drivers\mysqli\mysqli_driver.php 305
DEBUG - 2017-07-16 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:11 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:11 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:11 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:11 --> Total execution time: 0.1746
DEBUG - 2017-07-16 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:11 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:11 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:12 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:12 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:12 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:12 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:20 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:20 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:20 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:20 --> Total execution time: 0.1342
DEBUG - 2017-07-16 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:21 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:21 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:21 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:21 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:21 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:21 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:42:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:30 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:30 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:30 --> Total execution time: 0.1684
DEBUG - 2017-07-16 22:42:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:34 --> Total execution time: 0.1638
DEBUG - 2017-07-16 22:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:37 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:37 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:37 --> Total execution time: 0.1551
DEBUG - 2017-07-16 22:42:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:41 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:41 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:41 --> Total execution time: 0.1665
DEBUG - 2017-07-16 22:42:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:44 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:44 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:44 --> Total execution time: 0.1642
DEBUG - 2017-07-16 22:42:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:53 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:53 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:42:53 --> Total execution time: 0.1630
DEBUG - 2017-07-16 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:59 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:42:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:42:59 --> Session Class Initialized
DEBUG - 2017-07-16 22:42:59 --> Session routines successfully run
DEBUG - 2017-07-16 22:42:59 --> Total execution time: 0.1615
DEBUG - 2017-07-16 22:42:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:00 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:00 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:40 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 22:43:40 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-16 22:43:40 --> Total execution time: 0.1377
DEBUG - 2017-07-16 22:43:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:45 --> Total execution time: 0.1585
DEBUG - 2017-07-16 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:53 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:53 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:53 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:53 --> Total execution time: 0.1674
DEBUG - 2017-07-16 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:53 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:53 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:53 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:43:53 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:54 --> Session Class Initialized
DEBUG - 2017-07-16 22:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:43:54 --> Session routines successfully run
DEBUG - 2017-07-16 22:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:10 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:10 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:10 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:10 --> Total execution time: 0.1206
DEBUG - 2017-07-16 22:44:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:10 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:10 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:10 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:10 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:10 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:10 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:34 --> Total execution time: 0.1444
DEBUG - 2017-07-16 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:39 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:40 --> Total execution time: 0.1206
DEBUG - 2017-07-16 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:44:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:44:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:44:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:44:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:45:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:45:54 --> No URI present. Default controller set.
DEBUG - 2017-07-16 22:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:45:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:45:54 --> Session Class Initialized
DEBUG - 2017-07-16 22:45:54 --> Session routines successfully run
DEBUG - 2017-07-16 22:45:54 --> Total execution time: 0.1314
DEBUG - 2017-07-16 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:45:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:45:55 --> Session Class Initialized
DEBUG - 2017-07-16 22:45:55 --> Session Class Initialized
DEBUG - 2017-07-16 22:45:55 --> Session Class Initialized
DEBUG - 2017-07-16 22:45:55 --> Session routines successfully run
DEBUG - 2017-07-16 22:45:55 --> Session routines successfully run
DEBUG - 2017-07-16 22:45:55 --> Session routines successfully run
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:45:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:45:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:45:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:45:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:45:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:46:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:46:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:46:02 --> Session Class Initialized
DEBUG - 2017-07-16 22:46:02 --> Session routines successfully run
DEBUG - 2017-07-16 22:46:02 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 22:46:02 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-16 22:46:02 --> Total execution time: 0.1377
DEBUG - 2017-07-16 22:46:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:46:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:46:49 --> Session Class Initialized
DEBUG - 2017-07-16 22:46:49 --> Session routines successfully run
DEBUG - 2017-07-16 22:46:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:46:49 --> Total execution time: 0.1920
DEBUG - 2017-07-16 22:46:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:46:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:46:53 --> Session Class Initialized
DEBUG - 2017-07-16 22:46:53 --> Session routines successfully run
DEBUG - 2017-07-16 22:46:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:46:53 --> Total execution time: 0.1575
DEBUG - 2017-07-16 22:47:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:47:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:47:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:47:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:47:26 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 22:47:26 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-16 22:47:26 --> Total execution time: 0.1443
DEBUG - 2017-07-16 22:47:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:47:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:47:29 --> Session Class Initialized
DEBUG - 2017-07-16 22:47:29 --> Session routines successfully run
DEBUG - 2017-07-16 22:47:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:47:29 --> Total execution time: 0.1680
DEBUG - 2017-07-16 22:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:47:34 --> Session Class Initialized
DEBUG - 2017-07-16 22:47:34 --> Session routines successfully run
DEBUG - 2017-07-16 22:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:47:34 --> Total execution time: 0.1505
DEBUG - 2017-07-16 22:47:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:47:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:47:38 --> Session Class Initialized
DEBUG - 2017-07-16 22:47:38 --> Session routines successfully run
DEBUG - 2017-07-16 22:47:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:47:38 --> Total execution time: 0.1831
DEBUG - 2017-07-16 22:49:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:49:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:51:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:51:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:51:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-16 22:52:55 --> 404 Page Not Found: Results/calculate_result
DEBUG - 2017-07-16 22:52:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-16 22:52:56 --> 404 Page Not Found: Results/calculate_result
DEBUG - 2017-07-16 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:25 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:25 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:25 --> Total execution time: 0.1864
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:26 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:26 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:43 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:43 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:43 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:43 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:43 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:43 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:43 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:43 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:44 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:44 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 22:53:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:53:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:53:57 --> Session Class Initialized
DEBUG - 2017-07-16 22:53:57 --> Session routines successfully run
DEBUG - 2017-07-16 22:53:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:53:57 --> Total execution time: 0.1722
DEBUG - 2017-07-16 22:54:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:54:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:54:01 --> Session Class Initialized
DEBUG - 2017-07-16 22:54:01 --> Session routines successfully run
DEBUG - 2017-07-16 22:54:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:54:01 --> Total execution time: 0.1510
DEBUG - 2017-07-16 22:55:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:55:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:55:27 --> Session Class Initialized
DEBUG - 2017-07-16 22:55:27 --> Session routines successfully run
DEBUG - 2017-07-16 22:55:27 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-16 22:55:27 --> Severity: Notice --> Undefined variable: class_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 27
DEBUG - 2017-07-16 22:55:27 --> Total execution time: 0.2353
DEBUG - 2017-07-16 22:55:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:55:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:55:30 --> Session Class Initialized
DEBUG - 2017-07-16 22:55:30 --> Session routines successfully run
DEBUG - 2017-07-16 22:55:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:55:30 --> Total execution time: 0.2073
DEBUG - 2017-07-16 22:55:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:55:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:55:37 --> Session Class Initialized
DEBUG - 2017-07-16 22:55:37 --> Session routines successfully run
DEBUG - 2017-07-16 22:55:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:55:37 --> Total execution time: 0.1909
DEBUG - 2017-07-16 22:55:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:55:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:55:49 --> Session Class Initialized
DEBUG - 2017-07-16 22:55:49 --> Session routines successfully run
DEBUG - 2017-07-16 22:55:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:55:49 --> Total execution time: 0.1830
DEBUG - 2017-07-16 22:57:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:57:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:57:40 --> Session Class Initialized
DEBUG - 2017-07-16 22:57:40 --> Session routines successfully run
DEBUG - 2017-07-16 22:57:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:57:40 --> Total execution time: 0.2185
DEBUG - 2017-07-16 22:57:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:57:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:57:45 --> Session Class Initialized
DEBUG - 2017-07-16 22:57:45 --> Session routines successfully run
DEBUG - 2017-07-16 22:57:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:57:45 --> Total execution time: 0.1799
DEBUG - 2017-07-16 22:57:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:57:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:57:51 --> Session Class Initialized
DEBUG - 2017-07-16 22:57:51 --> Session routines successfully run
DEBUG - 2017-07-16 22:57:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:57:51 --> Total execution time: 0.1663
DEBUG - 2017-07-16 22:57:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:57:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:57:56 --> Session Class Initialized
DEBUG - 2017-07-16 22:57:56 --> Session routines successfully run
DEBUG - 2017-07-16 22:57:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:57:57 --> Total execution time: 0.1962
DEBUG - 2017-07-16 22:58:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:04 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:04 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:04 --> Total execution time: 0.2171
DEBUG - 2017-07-16 22:58:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:05 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:05 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:05 --> Total execution time: 0.2188
DEBUG - 2017-07-16 22:58:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:11 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:11 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:11 --> Total execution time: 0.2205
DEBUG - 2017-07-16 22:58:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:14 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:14 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:14 --> Total execution time: 0.1524
DEBUG - 2017-07-16 22:58:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:19 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:19 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:19 --> Total execution time: 0.1751
DEBUG - 2017-07-16 22:58:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:24 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:24 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:24 --> Total execution time: 0.1645
DEBUG - 2017-07-16 22:58:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:58:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:58:44 --> Session Class Initialized
DEBUG - 2017-07-16 22:58:44 --> Session routines successfully run
DEBUG - 2017-07-16 22:58:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:58:44 --> Total execution time: 0.2196
DEBUG - 2017-07-16 22:59:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 22:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 22:59:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 22:59:08 --> Session Class Initialized
DEBUG - 2017-07-16 22:59:08 --> Session routines successfully run
DEBUG - 2017-07-16 22:59:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 22:59:09 --> Total execution time: 0.1487
DEBUG - 2017-07-16 23:00:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:10 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:10 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:10 --> Total execution time: 0.1508
DEBUG - 2017-07-16 23:00:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:23 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:23 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:23 --> Total execution time: 0.1579
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:24 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:24 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:52 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:52 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:52 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:52 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:52 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:52 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:52 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:52 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:53 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:53 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:53 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:53 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:00:53 --> Session Class Initialized
DEBUG - 2017-07-16 23:00:53 --> Session routines successfully run
DEBUG - 2017-07-16 23:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:03:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:03:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:03:11 --> Session Class Initialized
DEBUG - 2017-07-16 23:03:11 --> Session routines successfully run
DEBUG - 2017-07-16 23:03:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:03:11 --> Total execution time: 0.1990
DEBUG - 2017-07-16 23:03:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:03:11 --> No URI present. Default controller set.
DEBUG - 2017-07-16 23:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:03:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:03:11 --> Session Class Initialized
DEBUG - 2017-07-16 23:03:11 --> Session routines successfully run
DEBUG - 2017-07-16 23:03:11 --> Total execution time: 0.2185
DEBUG - 2017-07-16 23:03:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:03:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:03:18 --> Session Class Initialized
DEBUG - 2017-07-16 23:03:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:03:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:03:18 --> Total execution time: 0.1668
DEBUG - 2017-07-16 23:03:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:03:18 --> No URI present. Default controller set.
DEBUG - 2017-07-16 23:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:03:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:03:18 --> Session Class Initialized
DEBUG - 2017-07-16 23:03:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:03:18 --> Total execution time: 0.1961
DEBUG - 2017-07-16 23:03:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:03:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:03:35 --> Session Class Initialized
DEBUG - 2017-07-16 23:03:35 --> Session routines successfully run
DEBUG - 2017-07-16 23:05:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:05:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:05:50 --> Session Class Initialized
DEBUG - 2017-07-16 23:05:50 --> Session routines successfully run
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: school_info C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 28
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: school_info C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 29
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: school_info C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 31
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: school_info C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 32
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 44
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 48
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 52
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 55
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 58
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: result_display C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 89
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 136
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 137
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 138
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 139
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 140
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 144
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: class_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 145
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: class_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 146
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: class_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 147
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: class_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 148
ERROR - 2017-07-16 23:05:50 --> Severity: Notice --> Undefined variable: student_report_overview C:\xampp\htdocs\school_ms\application\views\results\sheets\default.php 152
DEBUG - 2017-07-16 23:05:50 --> Total execution time: 0.4809
DEBUG - 2017-07-16 23:05:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:05:51 --> No URI present. Default controller set.
DEBUG - 2017-07-16 23:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:05:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:05:51 --> Session Class Initialized
DEBUG - 2017-07-16 23:05:51 --> Session routines successfully run
DEBUG - 2017-07-16 23:05:51 --> Total execution time: 0.1902
DEBUG - 2017-07-16 23:06:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:06:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:06:26 --> Session Class Initialized
DEBUG - 2017-07-16 23:06:26 --> Session routines successfully run
DEBUG - 2017-07-16 23:06:26 --> Total execution time: 0.1256
DEBUG - 2017-07-16 23:06:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:06:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:06:57 --> Session Class Initialized
DEBUG - 2017-07-16 23:06:57 --> Session routines successfully run
DEBUG - 2017-07-16 23:06:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:06:58 --> Total execution time: 0.1773
DEBUG - 2017-07-16 23:07:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:02 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:02 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:02 --> Total execution time: 0.1539
DEBUG - 2017-07-16 23:07:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:17 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:18 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:18 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:18 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:18 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:19 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:19 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:19 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:19 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:19 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:19 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:07:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:23 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:23 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:23 --> Total execution time: 0.1896
DEBUG - 2017-07-16 23:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:07:36 --> Session Class Initialized
DEBUG - 2017-07-16 23:07:36 --> Session routines successfully run
DEBUG - 2017-07-16 23:07:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:07:36 --> Total execution time: 0.1837
DEBUG - 2017-07-16 23:21:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:21:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:21:36 --> Session Class Initialized
DEBUG - 2017-07-16 23:21:36 --> Session routines successfully run
DEBUG - 2017-07-16 23:21:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:21:36 --> Total execution time: 0.2154
DEBUG - 2017-07-16 23:21:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:21:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:21:43 --> Session Class Initialized
DEBUG - 2017-07-16 23:21:43 --> Session routines successfully run
DEBUG - 2017-07-16 23:21:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:21:43 --> Total execution time: 0.1887
DEBUG - 2017-07-16 23:25:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:25:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:25:00 --> Session Class Initialized
DEBUG - 2017-07-16 23:25:00 --> Session routines successfully run
DEBUG - 2017-07-16 23:25:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:25:00 --> Total execution time: 0.2116
DEBUG - 2017-07-16 23:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:28:43 --> Session Class Initialized
DEBUG - 2017-07-16 23:28:43 --> Session routines successfully run
DEBUG - 2017-07-16 23:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:28:43 --> Total execution time: 0.1909
DEBUG - 2017-07-16 23:31:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:31:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:31:00 --> Session Class Initialized
DEBUG - 2017-07-16 23:31:00 --> Session routines successfully run
DEBUG - 2017-07-16 23:31:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:31:00 --> Total execution time: 0.1922
DEBUG - 2017-07-16 23:57:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:35 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:35 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:35 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:35 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:35 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:35 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:35 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:35 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:36 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:36 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:36 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:36 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:57:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:57:36 --> Session Class Initialized
DEBUG - 2017-07-16 23:57:36 --> Session routines successfully run
DEBUG - 2017-07-16 23:57:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:57:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:03 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:03 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:03 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:03 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:03 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:03 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:03 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:03 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:04 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:04 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:04 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:04 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-16 23:58:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-16 23:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-16 23:58:04 --> Session Class Initialized
DEBUG - 2017-07-16 23:58:04 --> Session routines successfully run
DEBUG - 2017-07-16 23:58:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-16 23:58:04 --> Myapp class already loaded. Second attempt ignored.

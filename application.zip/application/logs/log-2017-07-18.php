<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-18 21:03:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:30 --> No URI present. Default controller set.
DEBUG - 2017-07-18 21:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:31 --> Session Class Initialized
ERROR - 2017-07-18 21:03:31 --> Session: The session cookie was not signed.
DEBUG - 2017-07-18 21:03:31 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:32 --> Total execution time: 1.6634
DEBUG - 2017-07-18 21:03:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:32 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:32 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:32 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:32 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:32 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:43 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:43 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:43 --> No URI present. Default controller set.
DEBUG - 2017-07-18 21:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:43 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:43 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:43 --> Total execution time: 0.1067
DEBUG - 2017-07-18 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:44 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:44 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:44 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:44 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:44 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:44 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:03:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:52 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:52 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:52 --> Total execution time: 0.1415
DEBUG - 2017-07-18 21:03:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:54 --> User with name damilare just logged in
DEBUG - 2017-07-18 21:03:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:03:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:03:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:03:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:03:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:03:54 --> Total execution time: 0.1963
DEBUG - 2017-07-18 21:04:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> Total execution time: 0.1438
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:08 --> Session Class Initialized
DEBUG - 2017-07-18 21:04:08 --> Session routines successfully run
DEBUG - 2017-07-18 21:04:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:04:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:04:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:36 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:36 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:36 --> Total execution time: 0.1212
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:00 --> Total execution time: 0.2215
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:10:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:10:10 --> Session Class Initialized
DEBUG - 2017-07-18 21:10:10 --> Session routines successfully run
DEBUG - 2017-07-18 21:10:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:10:10 --> Total execution time: 0.1701
DEBUG - 2017-07-18 21:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:11:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:11:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:11:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:11:48 --> Total execution time: 0.1110
DEBUG - 2017-07-18 21:12:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:02 --> Total execution time: 0.2234
DEBUG - 2017-07-18 21:12:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:09 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:09 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:09 --> Total execution time: 0.1164
DEBUG - 2017-07-18 21:12:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:21 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:21 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:21 --> Total execution time: 0.2186
DEBUG - 2017-07-18 21:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:23 --> Total execution time: 0.1411
DEBUG - 2017-07-18 21:12:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:29 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:29 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:29 --> Total execution time: 0.2003
DEBUG - 2017-07-18 21:12:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:34 --> Total execution time: 0.1857
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:58 --> Total execution time: 0.1119
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:12:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:12:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:59 --> Session Class Initialized
DEBUG - 2017-07-18 21:12:59 --> Session routines successfully run
DEBUG - 2017-07-18 21:12:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:12:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:50 --> Total execution time: 0.1284
DEBUG - 2017-07-18 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:51 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:51 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:13:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:13:51 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:13:51 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Session Class Initialized
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Session routines successfully run
DEBUG - 2017-07-18 21:13:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:13:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:25 --> Total execution time: 0.1975
DEBUG - 2017-07-18 21:15:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:33 --> Total execution time: 0.1371
DEBUG - 2017-07-18 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Total execution time: 0.1248
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:15:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:15:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:15:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:15:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:15:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:26 --> Total execution time: 0.1097
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:16:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:16:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:16:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:43 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:43 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:43 --> Total execution time: 0.1512
DEBUG - 2017-07-18 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:53 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:53 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:53 --> Total execution time: 0.1261
DEBUG - 2017-07-18 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:53 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:53 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:53 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:53 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:53 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:53 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:53 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:53 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:18:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:18:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:18:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:18:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:24 --> Total execution time: 0.1795
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:34 --> Total execution time: 0.1420
DEBUG - 2017-07-18 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:47 --> Total execution time: 0.2932
DEBUG - 2017-07-18 21:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:49 --> Total execution time: 0.2853
DEBUG - 2017-07-18 21:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:56 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:19:56 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:19:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:19:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:19:56 --> Session Class Initialized
DEBUG - 2017-07-18 21:19:56 --> Session routines successfully run
DEBUG - 2017-07-18 21:19:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:19:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:47 --> Total execution time: 0.2155
DEBUG - 2017-07-18 21:21:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:21:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:41 --> Total execution time: 0.1882
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:03 --> Total execution time: 0.1900
DEBUG - 2017-07-18 21:24:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:24 --> Total execution time: 0.1694
DEBUG - 2017-07-18 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:32 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:32 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:32 --> Total execution time: 0.2137
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:46 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:46 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:46 --> Total execution time: 0.1648
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:24:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:24:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:24:59 --> Session Class Initialized
DEBUG - 2017-07-18 21:24:59 --> Session routines successfully run
DEBUG - 2017-07-18 21:24:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:24:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:01 --> Total execution time: 0.1508
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:56 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:56 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:56 --> Total execution time: 0.1614
DEBUG - 2017-07-18 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:57 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:57 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Session Class Initialized
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Session routines successfully run
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:26:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:27:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:27:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:27:01 --> Session Class Initialized
DEBUG - 2017-07-18 21:27:01 --> Session routines successfully run
DEBUG - 2017-07-18 21:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:17 --> Total execution time: 0.2624
DEBUG - 2017-07-18 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:18 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:18 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:41:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:41:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:22 --> Total execution time: 0.2595
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:23 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:23 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:29 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:29 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:29 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:30 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:47 --> Total execution time: 0.2497
DEBUG - 2017-07-18 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:48 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:52 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:42:52 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:42:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:42:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:42:52 --> Session Class Initialized
DEBUG - 2017-07-18 21:42:52 --> Session routines successfully run
DEBUG - 2017-07-18 21:42:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:42:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:41 --> Total execution time: 0.2314
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:43 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:43 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:45 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:45 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:43:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:43:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:43:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:43:45 --> Session Class Initialized
DEBUG - 2017-07-18 21:43:45 --> Session routines successfully run
DEBUG - 2017-07-18 21:43:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:43:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:45 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:45 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:45 --> Total execution time: 0.1974
DEBUG - 2017-07-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:46 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:44:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:44:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:44:50 --> Session Class Initialized
DEBUG - 2017-07-18 21:44:50 --> Session routines successfully run
DEBUG - 2017-07-18 21:44:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:44:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:16 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:16 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:16 --> Total execution time: 0.2317
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:20 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:20 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:20 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:20 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:38 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:38 --> Total execution time: 0.2114
DEBUG - 2017-07-18 21:45:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:45:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:45:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:45:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:45:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:45:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:45:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:45:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:21 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:21 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:21 --> Total execution time: 0.1761
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:46:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:46:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:46:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:46:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:46:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:46:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:46:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:05 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:05 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:05 --> Total execution time: 0.1767
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:11 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:11 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:11 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:11 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:14 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:14 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:32 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:32 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:32 --> Total execution time: 0.2569
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:33 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:47:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:47:44 --> Session Class Initialized
DEBUG - 2017-07-18 21:47:44 --> Session routines successfully run
DEBUG - 2017-07-18 21:47:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:47:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:47:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:24 --> Total execution time: 0.2125
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:29 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:29 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:30 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:30 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:30 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:30 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:34 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:34 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:41 --> Total execution time: 0.2272
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:49 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:49 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:48:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:48:54 --> Session Class Initialized
DEBUG - 2017-07-18 21:48:54 --> Session routines successfully run
DEBUG - 2017-07-18 21:48:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:48:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:48:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:25 --> Total execution time: 0.2375
DEBUG - 2017-07-18 21:49:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:38 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:38 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:40 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:40 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:43 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:43 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:49:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:49:59 --> Session Class Initialized
DEBUG - 2017-07-18 21:49:59 --> Session routines successfully run
DEBUG - 2017-07-18 21:49:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:49:59 --> Total execution time: 0.2520
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:04 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:04 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:26 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:26 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:26 --> Total execution time: 0.2317
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:27 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:27 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:28 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:28 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:28 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:28 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:35 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:35 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:37 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:37 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:38 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:38 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:40 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:40 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:42 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:42 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:50:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:50:51 --> Session Class Initialized
DEBUG - 2017-07-18 21:50:51 --> Session routines successfully run
DEBUG - 2017-07-18 21:50:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:50:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:50:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:39 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:39 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:40 --> Total execution time: 0.2247
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:45 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:45 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:51:47 --> Session Class Initialized
DEBUG - 2017-07-18 21:51:47 --> Session routines successfully run
DEBUG - 2017-07-18 21:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:06 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:06 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:06 --> Total execution time: 0.1847
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:07 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:10 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:10 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:13 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:13 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:14 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:14 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:52:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:52:16 --> Session Class Initialized
DEBUG - 2017-07-18 21:52:16 --> Session routines successfully run
DEBUG - 2017-07-18 21:52:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:52:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:52:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:24 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:24 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:24 --> Total execution time: 0.1851
DEBUG - 2017-07-18 21:53:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:28 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:28 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:30 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:30 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-18 21:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-18 21:53:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-18 21:53:38 --> Session Class Initialized
DEBUG - 2017-07-18 21:53:38 --> Session routines successfully run
DEBUG - 2017-07-18 21:53:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-18 21:53:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-18 21:53:38 --> Myapp class already loaded. Second attempt ignored.

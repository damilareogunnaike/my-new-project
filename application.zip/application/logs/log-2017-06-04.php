<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-04 18:39:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-04 18:39:36 --> No URI present. Default controller set.
DEBUG - 2017-06-04 18:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-04 18:39:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-04 18:39:36 --> Session Class Initialized
ERROR - 2017-06-04 18:39:36 --> Session: The session cookie was not signed.
DEBUG - 2017-06-04 18:39:36 --> Session routines successfully run
DEBUG - 2017-06-04 18:39:36 --> Total execution time: 0.4927

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-08 01:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:04:39 --> Session Class Initialized
ERROR - 2017-07-08 01:04:39 --> Session: The session cookie was not signed.
DEBUG - 2017-07-08 01:04:39 --> Session Class Initialized
DEBUG - 2017-07-08 01:04:39 --> Session routines successfully run
ERROR - 2017-07-08 01:04:39 --> Session: The session cookie was not signed.
DEBUG - 2017-07-08 01:04:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:04:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:04:39 --> Session Class Initialized
ERROR - 2017-07-08 01:04:39 --> Session: The session cookie was not signed.
DEBUG - 2017-07-08 01:04:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:04:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:04:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:04:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:11:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:11:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:11:21 --> Session Class Initialized
ERROR - 2017-07-08 01:11:21 --> Session: The session cookie was not signed.
DEBUG - 2017-07-08 01:11:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:11:22 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:11:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:11:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:11:22 --> Total execution time: 0.1569
DEBUG - 2017-07-08 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:11:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:11:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:11:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:11:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:11:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:11:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:11:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:11:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:11:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:11:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:11:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:11:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:12 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:12 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:12 --> Total execution time: 0.1065
DEBUG - 2017-07-08 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:22 --> Total execution time: 0.0902
DEBUG - 2017-07-08 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:45 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:46 --> Total execution time: 0.1100
DEBUG - 2017-07-08 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:12:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:12:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:12:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:12:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:12:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:12:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:12:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:15:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:15:35 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:15:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:15:35 --> Session Class Initialized
DEBUG - 2017-07-08 01:15:35 --> Session routines successfully run
DEBUG - 2017-07-08 01:15:35 --> Total execution time: 0.0890
DEBUG - 2017-07-08 01:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:15:37 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:15:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:15:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:15:37 --> Total execution time: 0.1283
DEBUG - 2017-07-08 01:15:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:15:51 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:15:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:15:51 --> Session Class Initialized
DEBUG - 2017-07-08 01:15:51 --> Session routines successfully run
DEBUG - 2017-07-08 01:15:51 --> Total execution time: 0.1017
DEBUG - 2017-07-08 01:16:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:16:38 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:16:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:16:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:16:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:30 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:30 --> Total execution time: 0.1454
DEBUG - 2017-07-08 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:32 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:32 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:32 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:32 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:37 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:37 --> Total execution time: 0.1345
DEBUG - 2017-07-08 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:17:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:17:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:17:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:17:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:17:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:17:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:07 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:07 --> Total execution time: 0.2022
DEBUG - 2017-07-08 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:09 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:09 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:09 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:09 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:09 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:09 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:22 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:22 --> Total execution time: 0.1286
DEBUG - 2017-07-08 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:24 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:24 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:24 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:24 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:24 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:24 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:56 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:56 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:56 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:56 --> Total execution time: 0.1364
DEBUG - 2017-07-08 01:19:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:19:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:19:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:19:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:19:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:07 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:07 --> Total execution time: 0.1148
DEBUG - 2017-07-08 01:20:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:11 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:11 --> Total execution time: 0.1040
DEBUG - 2017-07-08 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:31 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:31 --> Total execution time: 0.1955
DEBUG - 2017-07-08 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:32 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:32 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:32 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:32 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:32 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:32 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:38 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:38 --> Total execution time: 0.0958
DEBUG - 2017-07-08 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:39 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:39 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:39 --> Total execution time: 0.1323
DEBUG - 2017-07-08 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:20:39 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:39 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:39 --> Session Class Initialized
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:39 --> Session routines successfully run
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:20:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:20:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:18 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:18 --> Total execution time: 0.1679
DEBUG - 2017-07-08 01:22:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:26 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:26 --> Total execution time: 0.1055
DEBUG - 2017-07-08 01:22:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:22:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:22:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:22:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:22:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:22:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:22:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:22:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:00 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:00 --> Total execution time: 0.1084
DEBUG - 2017-07-08 01:23:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:02 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:02 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:02 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:02 --> Total execution time: 0.0990
DEBUG - 2017-07-08 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:02 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:02 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:02 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:02 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:02 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:02 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:10 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:10 --> Total execution time: 0.1082
DEBUG - 2017-07-08 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:11 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:11 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:11 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:11 --> Total execution time: 0.1094
DEBUG - 2017-07-08 01:23:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:12 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:12 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:12 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:12 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:12 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:12 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:14 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:14 --> Total execution time: 0.1017
DEBUG - 2017-07-08 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:16 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:17 --> Total execution time: 0.1341
DEBUG - 2017-07-08 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:20 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:21 --> Total execution time: 0.1338
DEBUG - 2017-07-08 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:23:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:23:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:23:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:23:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:23:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:19 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:19 --> Total execution time: 0.1173
DEBUG - 2017-07-08 01:24:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:20 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:20 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:20 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:20 --> Total execution time: 0.1049
DEBUG - 2017-07-08 01:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:22 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:22 --> Total execution time: 0.1484
DEBUG - 2017-07-08 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:24:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:23 --> Session Class Initialized
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:24:23 --> Session routines successfully run
DEBUG - 2017-07-08 01:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:07 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:07 --> Total execution time: 0.1184
DEBUG - 2017-07-08 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:14 --> User with name damilare just logged in
DEBUG - 2017-07-08 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:14 --> Total execution time: 0.1268
DEBUG - 2017-07-08 01:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:26 --> Total execution time: 0.1195
DEBUG - 2017-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:46 --> Total execution time: 0.1162
DEBUG - 2017-07-08 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:46 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:46 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:47 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:47 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:47 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:47 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:47 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:47 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:49 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:49 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:49 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:49 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:49 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:49 --> Total execution time: 0.0995
DEBUG - 2017-07-08 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:52 --> User with name damilare just logged in
DEBUG - 2017-07-08 01:25:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:52 --> Total execution time: 0.1166
DEBUG - 2017-07-08 01:25:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:25:56 --> Session Class Initialized
DEBUG - 2017-07-08 01:25:56 --> Session routines successfully run
DEBUG - 2017-07-08 01:25:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:25:56 --> Total execution time: 0.1761
DEBUG - 2017-07-08 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:00 --> Total execution time: 0.1123
DEBUG - 2017-07-08 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:26:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:26:53 --> Session Class Initialized
DEBUG - 2017-07-08 01:26:53 --> Session routines successfully run
DEBUG - 2017-07-08 01:26:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:26:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:26:53 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:55 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 01:26:56 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
DEBUG - 2017-07-08 01:27:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:27:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:27:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:27:01 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 01:27:01 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
DEBUG - 2017-07-08 01:27:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:27:03 --> Session Class Initialized
DEBUG - 2017-07-08 01:27:03 --> Session routines successfully run
DEBUG - 2017-07-08 01:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:27:03 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 01:27:03 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
DEBUG - 2017-07-08 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:27:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:27:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:27:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:27:15 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:27:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:27:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:27:15 --> Total execution time: 0.0965
DEBUG - 2017-07-08 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:00 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:00 --> Total execution time: 0.1255
DEBUG - 2017-07-08 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:52 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:52 --> Total execution time: 0.1249
DEBUG - 2017-07-08 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:28:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:28:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:28:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:28:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:00 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:00 --> Total execution time: 0.1713
DEBUG - 2017-07-08 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:01 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:01 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:04 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:04 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:04 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:04 --> Total execution time: 0.1484
DEBUG - 2017-07-08 01:29:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:08 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:08 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:17 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:17 --> Total execution time: 0.1506
DEBUG - 2017-07-08 01:29:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:36 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:36 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:36 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:36 --> Total execution time: 0.1590
DEBUG - 2017-07-08 01:29:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:54 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:54 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:54 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:54 --> Total execution time: 0.1412
DEBUG - 2017-07-08 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:55 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:55 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:29:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:55 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:55 --> Session Class Initialized
DEBUG - 2017-07-08 01:29:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:55 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:55 --> Session routines successfully run
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:29:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:29:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:07 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:07 --> Total execution time: 0.2055
DEBUG - 2017-07-08 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:07 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:07 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:10 --> Total execution time: 0.1344
DEBUG - 2017-07-08 01:30:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:13 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:13 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:13 --> User with name damilare just logged in
DEBUG - 2017-07-08 01:30:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:14 --> Total execution time: 0.1502
DEBUG - 2017-07-08 01:30:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:17 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:17 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:17 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:17 --> Total execution time: 0.1265
DEBUG - 2017-07-08 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:30:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:30:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:30:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:30:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:30:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:32:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:32:25 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:32:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:32:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:32:26 --> Total execution time: 0.1705
DEBUG - 2017-07-08 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:32:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:32:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:32:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:32:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:32:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:32:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:32:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:32:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:32:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:32:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:32:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:32:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:33:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:33:43 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:33:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:33:44 --> Session Class Initialized
DEBUG - 2017-07-08 01:33:44 --> Session routines successfully run
DEBUG - 2017-07-08 01:33:44 --> Total execution time: 0.1568
DEBUG - 2017-07-08 01:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:33:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:33:44 --> Session Class Initialized
DEBUG - 2017-07-08 01:33:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:33:44 --> Session Class Initialized
DEBUG - 2017-07-08 01:33:44 --> Session routines successfully run
DEBUG - 2017-07-08 01:33:44 --> Session routines successfully run
DEBUG - 2017-07-08 01:33:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:33:45 --> Session Class Initialized
DEBUG - 2017-07-08 01:33:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:33:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:33:45 --> Session routines successfully run
DEBUG - 2017-07-08 01:33:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:33:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:33:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:33:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:34:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:34:03 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:34:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:34:03 --> Session Class Initialized
DEBUG - 2017-07-08 01:34:03 --> Session routines successfully run
DEBUG - 2017-07-08 01:34:03 --> Total execution time: 0.1500
DEBUG - 2017-07-08 01:34:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:34:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:34:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:34:04 --> Session Class Initialized
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:34:04 --> Session routines successfully run
DEBUG - 2017-07-08 01:34:04 --> Session Class Initialized
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:34:04 --> Session routines successfully run
DEBUG - 2017-07-08 01:34:04 --> Session Class Initialized
DEBUG - 2017-07-08 01:34:04 --> Session routines successfully run
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:34:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:34:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:34:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:34:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:34:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:09 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:09 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:09 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:09 --> Total execution time: 0.1744
DEBUG - 2017-07-08 01:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:29 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:29 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:29 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:29 --> Total execution time: 0.2344
DEBUG - 2017-07-08 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:56 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:56 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:56 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:56 --> Total execution time: 0.1599
DEBUG - 2017-07-08 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:35:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:35:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:57 --> Session Class Initialized
DEBUG - 2017-07-08 01:35:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:57 --> Session routines successfully run
DEBUG - 2017-07-08 01:35:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:35:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:35:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:05 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:05 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:05 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:05 --> Total execution time: 0.2199
DEBUG - 2017-07-08 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:05 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:05 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:06 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:06 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:06 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:06 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:15 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:15 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:15 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:15 --> Total execution time: 0.2338
DEBUG - 2017-07-08 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:16 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:16 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:16 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:16 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:16 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:16 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:36:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:36:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:36:42 --> Session Class Initialized
DEBUG - 2017-07-08 01:36:42 --> Session routines successfully run
DEBUG - 2017-07-08 01:36:42 --> Total execution time: 0.1528
DEBUG - 2017-07-08 01:39:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:41 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:41 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:41 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:41 --> Total execution time: 0.1762
DEBUG - 2017-07-08 01:39:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:42 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:42 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:42 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:42 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:42 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:42 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:52 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:52 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:52 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:52 --> Total execution time: 0.1726
DEBUG - 2017-07-08 01:39:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:39:53 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:53 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:53 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:53 --> Session Class Initialized
DEBUG - 2017-07-08 01:39:53 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:53 --> Session routines successfully run
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:39:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:39:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:40:04 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:40:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:40:04 --> Session Class Initialized
DEBUG - 2017-07-08 01:40:04 --> Session routines successfully run
DEBUG - 2017-07-08 01:40:04 --> Total execution time: 0.1788
DEBUG - 2017-07-08 01:40:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:40:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:40:05 --> Session Class Initialized
DEBUG - 2017-07-08 01:40:05 --> Session routines successfully run
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:40:05 --> Session Class Initialized
DEBUG - 2017-07-08 01:40:05 --> Session Class Initialized
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:40:05 --> Session routines successfully run
DEBUG - 2017-07-08 01:40:05 --> Session routines successfully run
DEBUG - 2017-07-08 01:40:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:40:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:40:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:40:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:20 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:20 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:20 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:20 --> Total execution time: 0.2069
DEBUG - 2017-07-08 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:30 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:30 --> Total execution time: 0.3415
DEBUG - 2017-07-08 01:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:41:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:41:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:41:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:41:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:17 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:18 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:18 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:18 --> Total execution time: 0.1817
DEBUG - 2017-07-08 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:19 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:19 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:37 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:37 --> Total execution time: 0.1798
DEBUG - 2017-07-08 01:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:48 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:48 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:48 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:48 --> Total execution time: 0.1829
DEBUG - 2017-07-08 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:49 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:42:49 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:49 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:49 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:42:49 --> Session Class Initialized
DEBUG - 2017-07-08 01:42:49 --> Session routines successfully run
DEBUG - 2017-07-08 01:42:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:42:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:43:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:43:09 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:43:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:43:09 --> Session Class Initialized
DEBUG - 2017-07-08 01:43:09 --> Session routines successfully run
DEBUG - 2017-07-08 01:43:09 --> Total execution time: 0.1735
DEBUG - 2017-07-08 01:43:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:43:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:43:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:43:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:43:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:43:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:43:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:43:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:43:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:43:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:43:10 --> Session Class Initialized
DEBUG - 2017-07-08 01:43:10 --> Session routines successfully run
DEBUG - 2017-07-08 01:43:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:43:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:26 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:26 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:26 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:26 --> Total execution time: 0.1668
DEBUG - 2017-07-08 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:29 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:29 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:29 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:29 --> Total execution time: 0.2017
DEBUG - 2017-07-08 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:30 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:30 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:50 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:50 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:50 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:50 --> Total execution time: 0.2221
DEBUG - 2017-07-08 01:44:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:51 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:51 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:51 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:51 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:51 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:51 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:44:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:44:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:44:59 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:44:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:44:59 --> Session Class Initialized
DEBUG - 2017-07-08 01:44:59 --> Session routines successfully run
DEBUG - 2017-07-08 01:44:59 --> Total execution time: 0.2047
DEBUG - 2017-07-08 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:21 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:21 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:21 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:21 --> Total execution time: 0.2186
DEBUG - 2017-07-08 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:45:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:45:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:22 --> Session Class Initialized
DEBUG - 2017-07-08 01:45:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:22 --> Session routines successfully run
DEBUG - 2017-07-08 01:45:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:45:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:45:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:46:13 --> No URI present. Default controller set.
DEBUG - 2017-07-08 01:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:46:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:46:13 --> Session Class Initialized
DEBUG - 2017-07-08 01:46:13 --> Session routines successfully run
DEBUG - 2017-07-08 01:46:13 --> Total execution time: 0.1552
DEBUG - 2017-07-08 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:46:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:46:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:46:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:46:14 --> Session Class Initialized
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:46:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:46:14 --> Session routines successfully run
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:46:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:27 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:27 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:27 --> Total execution time: 0.1311
DEBUG - 2017-07-08 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:31 --> User with name damilare just logged in
DEBUG - 2017-07-08 01:54:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:31 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:31 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:31 --> Total execution time: 0.1264
DEBUG - 2017-07-08 01:54:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:37 --> Total execution time: 0.1359
DEBUG - 2017-07-08 01:54:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:54:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:54:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:37 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:37 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:37 --> Total execution time: 0.2245
DEBUG - 2017-07-08 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 01:56:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:38 --> Session Class Initialized
DEBUG - 2017-07-08 01:56:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:38 --> Session routines successfully run
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:56:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 01:56:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:13:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:14:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 02:15:03 --> Session Class Initialized
DEBUG - 2017-07-08 02:15:03 --> Session routines successfully run
DEBUG - 2017-07-08 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 02:15:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 02:15:07 --> Session Class Initialized
DEBUG - 2017-07-08 02:15:07 --> Session routines successfully run
DEBUG - 2017-07-08 02:15:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 02:15:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:15:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:15:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:21:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:21:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-08 02:21:05 --> 404 Page Not Found: C:/xampp
DEBUG - 2017-07-08 02:21:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:35:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 02:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 02:35:38 --> Session Class Initialized
DEBUG - 2017-07-08 02:35:38 --> Session routines successfully run
DEBUG - 2017-07-08 02:35:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 02:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:35:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:37:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-08 02:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-08 02:37:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-08 02:37:09 --> Session Class Initialized
DEBUG - 2017-07-08 02:37:09 --> Session routines successfully run
DEBUG - 2017-07-08 02:37:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-08 02:37:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:37:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-08 02:37:09 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 02:37:10 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameReflower\Block.php 781
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 217
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\LineBox.php 221
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 175
ERROR - 2017-07-08 02:37:11 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\FrameDecorator\Block.php 239
ERROR - 2017-07-08 02:37:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\school_ms\application\libraries\dompdf\src\Frame.php 566

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-22 23:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:06:01 --> No URI present. Default controller set.
DEBUG - 2017-06-22 23:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:06:01 --> Session Class Initialized
ERROR - 2017-06-22 23:06:01 --> Session: The session cookie was not signed.
DEBUG - 2017-06-22 23:06:01 --> Session routines successfully run
DEBUG - 2017-06-22 23:06:02 --> Total execution time: 1.3804
DEBUG - 2017-06-22 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:06:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:06:03 --> Session Class Initialized
DEBUG - 2017-06-22 23:06:03 --> Session routines successfully run
DEBUG - 2017-06-22 23:06:03 --> Session Class Initialized
DEBUG - 2017-06-22 23:06:03 --> Session Class Initialized
DEBUG - 2017-06-22 23:06:03 --> Session routines successfully run
DEBUG - 2017-06-22 23:06:03 --> Session routines successfully run
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:06:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:06:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:06:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:06:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:06:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:32 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:32 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:32 --> User with name damilare just logged in
DEBUG - 2017-06-22 23:15:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:33 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:33 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:33 --> Total execution time: 0.2682
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:37 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:37 --> Total execution time: 0.1073
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:37 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:37 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:37 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:38 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:38 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:38 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:38 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:38 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:15:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:15:49 --> Session Class Initialized
DEBUG - 2017-06-22 23:15:50 --> Session routines successfully run
DEBUG - 2017-06-22 23:15:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:15:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:15:50 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Severity: Notice --> Undefined index: serial_no C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 30
ERROR - 2017-06-22 23:15:50 --> Query error: Unknown column 'serial_no' in 'field list' - Invalid query: INSERT INTO `result_pins` (`class_id`, `pin`, `serial_no`, `session_id`, `student_id`, `term_id`) VALUES ('13','',NULL,'4','1067','1'), ('13','',NULL,'4','1111','1'), ('13','',NULL,'4','1064','1'), ('13','',NULL,'4','1069','1'), ('13','',NULL,'4','1296','1'), ('13','',NULL,'4','1070','1'), ('13','',NULL,'4','1074','1'), ('13','',NULL,'4','1075','1'), ('13','',NULL,'4','1088','1'), ('13','',NULL,'4','1078','1'), ('13','',NULL,'4','1076','1'), ('13','',NULL,'4','1086','1'), ('13','',NULL,'4','1084','1'), ('13','',NULL,'4','1081','1'), ('13','',NULL,'4','1093','1'), ('13','',NULL,'4','1087','1'), ('13','',NULL,'4','1096','1'), ('13','',NULL,'4','1103','1'), ('13','',NULL,'4','1106','1'), ('13','',NULL,'4','1107','1'), ('13','',NULL,'4','1113','1'), ('13','',NULL,'4','1122','1'), ('13','',NULL,'4','1127','1'), ('13','',NULL,'4','1114','1'), ('13','',NULL,'4','1073','1'), ('13','',NULL,'4','1125','1'), ('13','',NULL,'4','1117','1'), ('13','',NULL,'4','1150','1'), ('13','',NULL,'4','1118','1'), ('13','',NULL,'4','1135','1'), ('13','',NULL,'4','1151','1'), ('13','',NULL,'4','1140','1'), ('13','',NULL,'4','1154','1'), ('13','',NULL,'4','1157','1'), ('13','',NULL,'4','1160','1'), ('13','',NULL,'4','1146','1'), ('13','',NULL,'4','1138','1'), ('13','',NULL,'4','1143','1'), ('13','',NULL,'4','1163','1'), ('13','',NULL,'4','1162','1'), ('13','',NULL,'4','1209','1')
ERROR - 2017-06-22 23:15:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\system\core\Common.php 573
DEBUG - 2017-06-22 23:16:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:16:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:16:11 --> Session Class Initialized
DEBUG - 2017-06-22 23:16:11 --> Session routines successfully run
DEBUG - 2017-06-22 23:16:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:16:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:16:11 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-22 23:16:11 --> Query error: Duplicate entry '4-1-13-' for key 'Index 2' - Invalid query: INSERT INTO `result_pins` (`class_id`, `pin`, `serial`, `session_id`, `student_id`, `term_id`) VALUES ('13','','','4','1067','1'), ('13','','','4','1111','1'), ('13','','','4','1064','1'), ('13','','','4','1069','1'), ('13','','','4','1296','1'), ('13','','','4','1070','1'), ('13','','','4','1074','1'), ('13','','','4','1075','1'), ('13','','','4','1088','1'), ('13','','','4','1078','1'), ('13','','','4','1076','1'), ('13','','','4','1086','1'), ('13','','','4','1084','1'), ('13','','','4','1081','1'), ('13','','','4','1093','1'), ('13','','','4','1087','1'), ('13','','','4','1096','1'), ('13','','','4','1103','1'), ('13','','','4','1106','1'), ('13','','','4','1107','1'), ('13','','','4','1113','1'), ('13','','','4','1122','1'), ('13','','','4','1127','1'), ('13','','','4','1114','1'), ('13','','','4','1073','1'), ('13','','','4','1125','1'), ('13','','','4','1117','1'), ('13','','','4','1150','1'), ('13','','','4','1118','1'), ('13','','','4','1135','1'), ('13','','','4','1151','1'), ('13','','','4','1140','1'), ('13','','','4','1154','1'), ('13','','','4','1157','1'), ('13','','','4','1160','1'), ('13','','','4','1146','1'), ('13','','','4','1138','1'), ('13','','','4','1143','1'), ('13','','','4','1163','1'), ('13','','','4','1162','1'), ('13','','','4','1209','1')
DEBUG - 2017-06-22 23:18:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:18:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:18:16 --> Session Class Initialized
DEBUG - 2017-06-22 23:18:16 --> Session routines successfully run
DEBUG - 2017-06-22 23:18:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:18:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:18:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:20:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:20:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:20:27 --> Session Class Initialized
DEBUG - 2017-06-22 23:20:27 --> Session routines successfully run
DEBUG - 2017-06-22 23:20:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:20:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:20:27 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-22 23:20:27 --> Query error: Duplicate entry '' for key 'unique_pin' - Invalid query: INSERT INTO `result_pins` (`class_id`, `pin`, `serial`, `session_id`, `student_id`, `term_id`) VALUES ('13','','','4','1067','1'), ('13','','','4','1111','1'), ('13','','','4','1064','1'), ('13','','','4','1069','1'), ('13','','','4','1296','1'), ('13','','','4','1070','1'), ('13','','','4','1074','1'), ('13','','','4','1075','1'), ('13','','','4','1088','1'), ('13','','','4','1078','1'), ('13','','','4','1076','1'), ('13','','','4','1086','1'), ('13','','','4','1084','1'), ('13','','','4','1081','1'), ('13','','','4','1093','1'), ('13','','','4','1087','1'), ('13','','','4','1096','1'), ('13','','','4','1103','1'), ('13','','','4','1106','1'), ('13','','','4','1107','1'), ('13','','','4','1113','1'), ('13','','','4','1122','1'), ('13','','','4','1127','1'), ('13','','','4','1114','1'), ('13','','','4','1073','1'), ('13','','','4','1125','1'), ('13','','','4','1117','1'), ('13','','','4','1150','1'), ('13','','','4','1118','1'), ('13','','','4','1135','1'), ('13','','','4','1151','1'), ('13','','','4','1140','1'), ('13','','','4','1154','1'), ('13','','','4','1157','1'), ('13','','','4','1160','1'), ('13','','','4','1146','1'), ('13','','','4','1138','1'), ('13','','','4','1143','1'), ('13','','','4','1163','1'), ('13','','','4','1162','1'), ('13','','','4','1209','1')
DEBUG - 2017-06-22 23:23:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:23:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:23:00 --> Session Class Initialized
DEBUG - 2017-06-22 23:23:00 --> Session routines successfully run
DEBUG - 2017-06-22 23:23:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:23:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:23:00 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-22 23:23:01 --> Severity: error --> Exception: Call to undefined function com_create_guid() C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 43
DEBUG - 2017-06-22 23:23:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:23:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:23:37 --> Session Class Initialized
DEBUG - 2017-06-22 23:23:37 --> Session routines successfully run
DEBUG - 2017-06-22 23:23:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:23:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:23:37 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Notice --> Undefined variable: p C:\xampp\htdocs\school_ms\application\models\results\Result_pins_model.php 45
ERROR - 2017-06-22 23:23:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-06-22 23:23:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-06-22 23:23:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\system\core\Exceptions.php:272) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-06-22 23:23:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:23:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:23:55 --> Session Class Initialized
DEBUG - 2017-06-22 23:23:55 --> Session routines successfully run
DEBUG - 2017-06-22 23:23:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:23:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:23:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:24:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:25:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:25:00 --> Session Class Initialized
DEBUG - 2017-06-22 23:25:00 --> Session routines successfully run
DEBUG - 2017-06-22 23:25:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:25:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:25:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:45 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:45 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:45 --> Total execution time: 0.1534
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:26:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:26:52 --> Session Class Initialized
DEBUG - 2017-06-22 23:26:52 --> Session routines successfully run
DEBUG - 2017-06-22 23:26:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:26:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:26:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:30 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:30 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:30 --> Total execution time: 0.1375
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:39 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:39 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:46 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:46 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:27:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:27:55 --> Session Class Initialized
DEBUG - 2017-06-22 23:27:55 --> Session routines successfully run
DEBUG - 2017-06-22 23:27:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:27:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:27:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:32 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:32 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:33 --> Total execution time: 0.1654
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:33 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:34 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:34 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:42 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:42 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:28:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:28:45 --> Session Class Initialized
DEBUG - 2017-06-22 23:28:45 --> Session routines successfully run
DEBUG - 2017-06-22 23:28:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:28:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:28:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:30:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:30:17 --> Session Class Initialized
DEBUG - 2017-06-22 23:30:17 --> Session routines successfully run
DEBUG - 2017-06-22 23:30:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:30:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:30:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:30:24 --> Session Class Initialized
DEBUG - 2017-06-22 23:30:24 --> Session routines successfully run
DEBUG - 2017-06-22 23:30:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:30:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-22 23:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-22 23:30:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-22 23:30:53 --> Session Class Initialized
DEBUG - 2017-06-22 23:30:53 --> Session routines successfully run
DEBUG - 2017-06-22 23:30:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-22 23:30:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-22 23:30:53 --> Myapp class already loaded. Second attempt ignored.

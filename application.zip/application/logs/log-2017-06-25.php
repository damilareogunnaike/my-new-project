<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-25 17:17:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-25 17:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-25 17:17:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-25 17:17:10 --> Session Class Initialized
ERROR - 2017-06-25 17:17:10 --> Session: The session cookie was not signed.
DEBUG - 2017-06-25 17:17:10 --> Session routines successfully run
DEBUG - 2017-06-25 17:17:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-25 17:17:10 --> No URI present. Default controller set.
DEBUG - 2017-06-25 17:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-25 17:17:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-25 17:17:10 --> Session Class Initialized
DEBUG - 2017-06-25 17:17:10 --> Session routines successfully run
DEBUG - 2017-06-25 17:17:10 --> Total execution time: 0.1339
DEBUG - 2017-06-25 17:17:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-25 17:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-25 17:17:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-25 17:17:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-25 17:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-25 17:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-25 17:17:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-25 17:17:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-25 17:17:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-25 17:17:12 --> Session Class Initialized
DEBUG - 2017-06-25 17:17:12 --> Session routines successfully run
DEBUG - 2017-06-25 17:17:12 --> Session Class Initialized
DEBUG - 2017-06-25 17:17:12 --> Session Class Initialized
DEBUG - 2017-06-25 17:17:12 --> Session routines successfully run
DEBUG - 2017-06-25 17:17:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-25 17:17:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-25 17:17:12 --> Session routines successfully run
DEBUG - 2017-06-25 17:17:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-25 17:17:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-25 17:17:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-25 17:17:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-25 17:17:12 --> Myapp class already loaded. Second attempt ignored.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-09 22:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:34:59 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:34:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:35:00 --> Session Class Initialized
ERROR - 2017-07-09 22:35:00 --> Session: The session cookie was not signed.
DEBUG - 2017-07-09 22:35:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:35:00 --> Total execution time: 1.3952
DEBUG - 2017-07-09 22:35:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:35:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:35:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:35:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:35:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:35:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:35:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:35:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:35:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:35:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:35:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:35:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:35:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:35:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:42:33 --> Session Class Initialized
DEBUG - 2017-07-09 22:42:33 --> Session routines successfully run
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:42:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:42:33 --> Session Class Initialized
DEBUG - 2017-07-09 22:42:33 --> Session routines successfully run
DEBUG - 2017-07-09 22:42:33 --> Session Class Initialized
DEBUG - 2017-07-09 22:42:33 --> Session Class Initialized
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:42:33 --> Session routines successfully run
DEBUG - 2017-07-09 22:42:33 --> Session routines successfully run
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:42:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:07 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:07 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Total execution time: 0.1615
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:23 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:23 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:23 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:23 --> Total execution time: 0.1886
DEBUG - 2017-07-09 22:45:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:25 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:25 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:25 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:25 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:25 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:25 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:45:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:45:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:54 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:54 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:54 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:54 --> Total execution time: 0.1166
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Session routines successfully run
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:46:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:46:59 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:46:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:46:59 --> Session Class Initialized
DEBUG - 2017-07-09 22:46:59 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:00 --> Total execution time: 0.1318
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Session Class Initialized
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Session routines successfully run
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:38 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:38 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:38 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:38 --> Total execution time: 0.1270
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:39 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:39 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:39 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:39 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:39 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:39 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:39 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:39 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:39 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:40 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:40 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:44 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:44 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:44 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:44 --> Total execution time: 0.1309
DEBUG - 2017-07-09 22:48:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Session Class Initialized
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Session routines successfully run
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:48:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:51 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:51 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:51 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:51 --> Total execution time: 0.1254
DEBUG - 2017-07-09 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:53 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:53 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:53 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:53 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:53 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:53 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:49:54 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:54 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:54 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:54 --> Session Class Initialized
DEBUG - 2017-07-09 22:49:54 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:54 --> Session routines successfully run
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:08 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:08 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:08 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:08 --> Total execution time: 0.1352
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:28 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:28 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:28 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:28 --> Total execution time: 0.1175
DEBUG - 2017-07-09 22:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:50:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:50:58 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:50:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:50:58 --> Session Class Initialized
DEBUG - 2017-07-09 22:50:58 --> Session routines successfully run
DEBUG - 2017-07-09 22:50:58 --> Total execution time: 0.1130
DEBUG - 2017-07-09 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:51:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:01 --> Session Class Initialized
DEBUG - 2017-07-09 22:51:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:01 --> Session routines successfully run
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:15 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:15 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:15 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:15 --> Total execution time: 0.1158
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:50 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:50 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:50 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:50 --> Total execution time: 0.1606
DEBUG - 2017-07-09 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:51 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:51 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:52 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:52 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:52:52 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:52 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:52 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Session Class Initialized
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> Session routines successfully run
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:52:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:16 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:16 --> Total execution time: 0.1166
DEBUG - 2017-07-09 22:53:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:18 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:34 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:34 --> Total execution time: 0.1240
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:34 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:34 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:34 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:34 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:35 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:35 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:35 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:35 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:53:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:53:59 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:53:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:53:59 --> Session Class Initialized
DEBUG - 2017-07-09 22:53:59 --> Session routines successfully run
DEBUG - 2017-07-09 22:53:59 --> Total execution time: 0.1445
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:15 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:15 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:15 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Total execution time: 0.1835
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Session Class Initialized
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Session routines successfully run
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:54:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:06 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:06 --> Total execution time: 0.1911
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:06 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:06 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:06 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:06 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:07 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:07 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:07 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:07 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:07 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:07 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:20 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:20 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:20 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:20 --> Total execution time: 0.1378
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:25 --> No URI present. Default controller set.
DEBUG - 2017-07-09 22:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:25 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:25 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:25 --> Total execution time: 0.1160
DEBUG - 2017-07-09 22:58:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:26 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:26 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 22:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 22:58:27 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:27 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:27 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:27 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:27 --> Session Class Initialized
DEBUG - 2017-07-09 22:58:27 --> Session routines successfully run
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 22:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:40 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:40 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:40 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:40 --> Total execution time: 0.1619
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:57 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:58 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:58 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:58 --> Total execution time: 0.1354
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:59 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:02:59 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:02:59 --> Session routines successfully run
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:02:59 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:00 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:17 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:17 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:17 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:17 --> Total execution time: 0.1530
DEBUG - 2017-07-09 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:19 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:19 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:19 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:19 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:19 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:19 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:20 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:20 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:20 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:20 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:20 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:35 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:35 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:35 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:35 --> Total execution time: 0.1287
DEBUG - 2017-07-09 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:36 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:36 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:36 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:36 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:36 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:36 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:03:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:03:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:03:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:36 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:36 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:36 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:36 --> Total execution time: 0.1248
DEBUG - 2017-07-09 23:04:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:50 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:50 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:50 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:50 --> Total execution time: 0.1395
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Session Class Initialized
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Session routines successfully run
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:07 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:08 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:08 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:08 --> Total execution time: 0.1425
DEBUG - 2017-07-09 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:08 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:08 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:08 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:08 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:08 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:08 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:09 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:09 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:09 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:09 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:09 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:09 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:31 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:31 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:31 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:31 --> Total execution time: 0.1286
DEBUG - 2017-07-09 23:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Session Class Initialized
DEBUG - 2017-07-09 23:05:33 --> Session routines successfully run
DEBUG - 2017-07-09 23:05:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:05:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:22 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:22 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:22 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:22 --> Total execution time: 0.1394
DEBUG - 2017-07-09 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:24 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:24 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:24 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:24 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:24 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:24 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:25 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:25 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:25 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:25 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:25 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:44 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:44 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:44 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:44 --> Total execution time: 0.1433
DEBUG - 2017-07-09 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:45 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:45 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:45 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:45 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:45 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:45 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:07:46 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:46 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:07:46 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:46 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:46 --> Session Class Initialized
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:46 --> Session routines successfully run
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:07:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:01 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:02 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:02 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:02 --> Total execution time: 0.1447
DEBUG - 2017-07-09 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:03 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:03 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:03 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:03 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:03 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:03 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:18:04 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:18:04 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:04 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:04 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:04 --> Session Class Initialized
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:04 --> Session routines successfully run
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:26 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:26 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:26 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:26 --> Total execution time: 0.1552
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:27 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:36 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:36 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:36 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:36 --> Total execution time: 0.1435
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:37 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:37 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:38 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:38 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:47 --> No URI present. Default controller set.
DEBUG - 2017-07-09 23:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:47 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:47 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:47 --> Total execution time: 0.1450
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:48 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:48 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:48 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:48 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-09 23:19:48 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:49 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:49 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:49 --> Session Class Initialized
DEBUG - 2017-07-09 23:19:49 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:49 --> Session routines successfully run
DEBUG - 2017-07-09 23:19:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-09 23:19:49 --> Myapp class already loaded. Second attempt ignored.

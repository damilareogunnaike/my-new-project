<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-29 07:18:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:10 --> Session Class Initialized
ERROR - 2017-05-29 07:18:10 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 07:18:10 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:10 --> Total execution time: 0.8745
DEBUG - 2017-05-29 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:18 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:18 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:18 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:18 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:18 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:18 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:29 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:29 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:29 --> User with name admin just logged in
DEBUG - 2017-05-29 07:18:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:30 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:30 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:30 --> Total execution time: 0.4075
DEBUG - 2017-05-29 07:18:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:36 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:36 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:36 --> Total execution time: 0.2535
DEBUG - 2017-05-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:37 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:37 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:37 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:37 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:37 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:37 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:37 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:37 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:37 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:37 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:38 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:38 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:38 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:38 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:38 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:39 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:39 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:18:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:18:39 --> Session Class Initialized
DEBUG - 2017-05-29 07:18:39 --> Session routines successfully run
DEBUG - 2017-05-29 07:18:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:18:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:18:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:19:11 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:19:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:19:11 --> Session Class Initialized
DEBUG - 2017-05-29 07:19:11 --> Session routines successfully run
DEBUG - 2017-05-29 07:19:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:19:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:19:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 07:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 07:19:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 07:19:19 --> Session Class Initialized
DEBUG - 2017-05-29 07:19:19 --> Session routines successfully run
DEBUG - 2017-05-29 07:19:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 07:19:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:44:28 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:44:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:44:28 --> Session Class Initialized
ERROR - 2017-05-29 09:44:28 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 09:44:28 --> Session routines successfully run
DEBUG - 2017-05-29 09:44:29 --> Total execution time: 1.0777
DEBUG - 2017-05-29 09:44:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:44:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:44:44 --> Session Class Initialized
DEBUG - 2017-05-29 09:44:44 --> Session routines successfully run
DEBUG - 2017-05-29 09:44:44 --> User with name admin just logged in
DEBUG - 2017-05-29 09:44:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:44:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:44:45 --> Session Class Initialized
DEBUG - 2017-05-29 09:44:45 --> Session routines successfully run
DEBUG - 2017-05-29 09:44:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:44:45 --> Total execution time: 0.3121
DEBUG - 2017-05-29 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:44:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:44:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:44:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:44:52 --> Total execution time: 0.1555
DEBUG - 2017-05-29 09:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:45:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:45:08 --> Session Class Initialized
DEBUG - 2017-05-29 09:45:08 --> Session routines successfully run
DEBUG - 2017-05-29 09:45:08 --> Total execution time: 0.0627
DEBUG - 2017-05-29 09:46:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:18 --> Session Class Initialized
ERROR - 2017-05-29 09:46:18 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 09:46:18 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:18 --> Total execution time: 0.0411
DEBUG - 2017-05-29 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:29 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:29 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:29 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:29 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:29 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:29 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:42 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:42 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:42 --> User with name admin just logged in
DEBUG - 2017-05-29 09:46:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:43 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:43 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:43 --> Total execution time: 0.0640
DEBUG - 2017-05-29 09:46:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:49 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:49 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:49 --> Total execution time: 0.1216
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:52 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:53 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:53 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:53 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:53 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:46:54 --> Session Class Initialized
DEBUG - 2017-05-29 09:46:54 --> Session routines successfully run
DEBUG - 2017-05-29 09:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:47:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:47:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:47:01 --> Session Class Initialized
DEBUG - 2017-05-29 09:47:01 --> Session routines successfully run
DEBUG - 2017-05-29 09:47:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:47:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:47:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:47:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:47:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:47:47 --> Session Class Initialized
DEBUG - 2017-05-29 09:47:47 --> Session routines successfully run
DEBUG - 2017-05-29 09:47:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:47:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:48:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:48:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:48:14 --> Session Class Initialized
DEBUG - 2017-05-29 09:48:14 --> Session routines successfully run
DEBUG - 2017-05-29 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:48:23 --> No URI present. Default controller set.
DEBUG - 2017-05-29 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:48:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:48:23 --> Session Class Initialized
DEBUG - 2017-05-29 09:48:23 --> Session routines successfully run
DEBUG - 2017-05-29 09:48:23 --> Total execution time: 0.0706
DEBUG - 2017-05-29 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:48:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:48:29 --> Session Class Initialized
DEBUG - 2017-05-29 09:48:29 --> Session routines successfully run
DEBUG - 2017-05-29 09:48:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:48:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:48:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:48:31 --> Session Class Initialized
DEBUG - 2017-05-29 09:48:31 --> Session routines successfully run
DEBUG - 2017-05-29 09:48:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:48:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:48:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 09:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 09:48:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 09:48:38 --> Session Class Initialized
DEBUG - 2017-05-29 09:48:38 --> Session routines successfully run
DEBUG - 2017-05-29 09:48:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-29 09:48:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 09:48:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-29 15:24:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 15:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 15:24:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 15:24:32 --> Session Class Initialized
ERROR - 2017-05-29 15:24:32 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 15:24:32 --> Session routines successfully run
DEBUG - 2017-05-29 15:24:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 15:24:33 --> No URI present. Default controller set.
DEBUG - 2017-05-29 15:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 15:24:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 15:24:33 --> Session Class Initialized
ERROR - 2017-05-29 15:24:33 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 15:24:33 --> Session routines successfully run
DEBUG - 2017-05-29 15:24:33 --> Total execution time: 0.0861
DEBUG - 2017-05-29 22:55:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-29 22:55:00 --> No URI present. Default controller set.
DEBUG - 2017-05-29 22:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-29 22:55:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-29 22:55:00 --> Session Class Initialized
ERROR - 2017-05-29 22:55:00 --> Session: The session cookie was not signed.
DEBUG - 2017-05-29 22:55:00 --> Session routines successfully run
DEBUG - 2017-05-29 22:55:00 --> Total execution time: 0.5705

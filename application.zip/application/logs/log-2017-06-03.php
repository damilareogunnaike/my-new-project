<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-03 07:08:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:23 --> Session Class Initialized
ERROR - 2017-06-03 07:08:23 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 07:08:23 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:23 --> Total execution time: 0.5926
DEBUG - 2017-06-03 07:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:30 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:30 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:30 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:30 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:30 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:30 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:48 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:48 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:48 --> User with name admin just logged in
DEBUG - 2017-06-03 07:08:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:48 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:48 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:49 --> Total execution time: 0.4201
DEBUG - 2017-06-03 07:08:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:54 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:54 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:54 --> Total execution time: 0.0950
DEBUG - 2017-06-03 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:56 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:56 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:08:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:08:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:01 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:01 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:09:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:25 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:25 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:26 --> No URI present. Default controller set.
DEBUG - 2017-06-03 07:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:26 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:26 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:26 --> Total execution time: 0.0468
DEBUG - 2017-06-03 07:09:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:28 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:28 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:28 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:28 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:09:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:09:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:09:28 --> Session Class Initialized
DEBUG - 2017-06-03 07:09:28 --> Session routines successfully run
DEBUG - 2017-06-03 07:09:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:09:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:18:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:18:42 --> Session Class Initialized
ERROR - 2017-06-03 07:18:42 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 07:18:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:18:42 --> Total execution time: 0.1085
DEBUG - 2017-06-03 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:18:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:18:44 --> Session Class Initialized
ERROR - 2017-06-03 07:18:44 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 07:18:44 --> Session routines successfully run
DEBUG - 2017-06-03 07:18:44 --> Total execution time: 0.0718
DEBUG - 2017-06-03 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:01 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:01 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:02 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:02 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:02 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:02 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:36 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:36 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:36 --> User with name admin just logged in
DEBUG - 2017-06-03 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:37 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:37 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:37 --> Total execution time: 0.3031
DEBUG - 2017-06-03 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:41 --> Total execution time: 0.0773
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:43 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:43 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:43 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:43 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:19:43 --> Session Class Initialized
DEBUG - 2017-06-03 07:19:43 --> Session routines successfully run
DEBUG - 2017-06-03 07:19:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:43:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:43:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:43:50 --> Session Class Initialized
ERROR - 2017-06-03 07:43:50 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 07:43:50 --> Session routines successfully run
DEBUG - 2017-06-03 07:43:50 --> Total execution time: 0.1207
DEBUG - 2017-06-03 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:43:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:43:57 --> Session Class Initialized
DEBUG - 2017-06-03 07:43:57 --> Session routines successfully run
DEBUG - 2017-06-03 07:43:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:43:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:43:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:43:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:43:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:43:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:43:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:43:58 --> Session Class Initialized
DEBUG - 2017-06-03 07:43:58 --> Session routines successfully run
DEBUG - 2017-06-03 07:43:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:43:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:17 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:17 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:17 --> User with name admin just logged in
DEBUG - 2017-06-03 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:18 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:18 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:18 --> Total execution time: 0.1957
DEBUG - 2017-06-03 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:26 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:26 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:26 --> Total execution time: 0.0559
DEBUG - 2017-06-03 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:41 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:41 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:42 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:43 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:43 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:44:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:44:46 --> Session Class Initialized
DEBUG - 2017-06-03 07:44:46 --> Session routines successfully run
DEBUG - 2017-06-03 07:44:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-03 07:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:44:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-03 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 07:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 07:53:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 07:53:03 --> Session Class Initialized
ERROR - 2017-06-03 07:53:03 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 07:53:03 --> Session routines successfully run
DEBUG - 2017-06-03 07:53:03 --> Total execution time: 0.1444
DEBUG - 2017-06-03 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 14:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 14:20:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 14:20:51 --> Session Class Initialized
ERROR - 2017-06-03 14:20:51 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 14:20:51 --> Session routines successfully run
DEBUG - 2017-06-03 14:20:51 --> Total execution time: 0.7794
DEBUG - 2017-06-03 14:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 14:21:08 --> No URI present. Default controller set.
DEBUG - 2017-06-03 14:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 14:21:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 14:21:08 --> Session Class Initialized
ERROR - 2017-06-03 14:21:08 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 14:21:08 --> Session routines successfully run
DEBUG - 2017-06-03 14:21:08 --> Total execution time: 0.0723
DEBUG - 2017-06-03 16:44:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-03 16:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-03 16:44:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-03 16:44:48 --> Session Class Initialized
ERROR - 2017-06-03 16:44:48 --> Session: The session cookie was not signed.
DEBUG - 2017-06-03 16:44:48 --> Session routines successfully run
DEBUG - 2017-06-03 16:44:48 --> Total execution time: 1.6714

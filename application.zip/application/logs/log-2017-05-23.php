<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-23 03:23:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-23 03:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-23 03:23:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-23 03:23:47 --> Session Class Initialized
ERROR - 2017-05-23 03:23:47 --> Session: The session cookie was not signed.
DEBUG - 2017-05-23 03:23:47 --> Session routines successfully run
DEBUG - 2017-05-23 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2017-05-23 03:23:50 --> No URI present. Default controller set.
DEBUG - 2017-05-23 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-23 03:23:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-23 03:23:50 --> Session Class Initialized
DEBUG - 2017-05-23 03:23:50 --> Session routines successfully run
DEBUG - 2017-05-23 03:23:51 --> Total execution time: 0.0978
DEBUG - 2017-05-23 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-23 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-23 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-23 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-23 03:23:58 --> Session Class Initialized
DEBUG - 2017-05-23 03:23:58 --> Session routines successfully run
DEBUG - 2017-05-23 03:23:58 --> Session Class Initialized
DEBUG - 2017-05-23 03:23:58 --> Session routines successfully run
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-23 03:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-23 03:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-23 03:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-23 03:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-23 03:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-23 03:23:58 --> Session Class Initialized
DEBUG - 2017-05-23 03:23:58 --> Session routines successfully run
DEBUG - 2017-05-23 03:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-23 03:23:58 --> Myapp class already loaded. Second attempt ignored.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-10 09:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-10 09:08:47 --> No URI present. Default controller set.
DEBUG - 2017-06-10 09:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-10 09:08:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-10 09:08:47 --> Session Class Initialized
ERROR - 2017-06-10 09:08:47 --> Session: The session cookie was not signed.
DEBUG - 2017-06-10 09:08:47 --> Session routines successfully run
DEBUG - 2017-06-10 09:08:47 --> Total execution time: 1.2308
DEBUG - 2017-06-10 11:50:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-10 11:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-10 11:50:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-10 11:50:24 --> Session Class Initialized
ERROR - 2017-06-10 11:50:24 --> Session: The session cookie was not signed.
DEBUG - 2017-06-10 11:50:24 --> Session routines successfully run
DEBUG - 2017-06-10 11:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-10 11:50:25 --> No URI present. Default controller set.
DEBUG - 2017-06-10 11:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-10 11:50:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-10 11:50:25 --> Session Class Initialized
DEBUG - 2017-06-10 11:50:25 --> Session routines successfully run
DEBUG - 2017-06-10 11:50:25 --> Total execution time: 0.2051
DEBUG - 2017-06-10 17:03:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-10 17:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-10 17:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-10 17:03:48 --> Session Class Initialized
ERROR - 2017-06-10 17:03:48 --> Session: The session cookie was not signed.
DEBUG - 2017-06-10 17:03:48 --> Session routines successfully run
DEBUG - 2017-06-10 17:03:48 --> Total execution time: 1.3536

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-17 00:45:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:45:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:45:47 --> Session Class Initialized
DEBUG - 2017-07-17 00:45:47 --> Session routines successfully run
DEBUG - 2017-07-17 00:45:47 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 00:45:47 --> Query error: Column 'class_id' in where clause is ambiguous - Invalid query: SELECT CONCAT(b.surname, ' ', `b`.`middle_name`, ' ', b.first_name) AS student_name, `a`.`student_id`, GROUP_CONCAT(a.total_score) as total_scores, GROUP_CONCAT(a.avg_score) as averages, GROUP_CONCAT(a.max_obtainable) as max_obtainables, GROUP_CONCAT(a.percentage) as percentages, GROUP_CONCAT(a.term_id) as terms, SUM(a.total_score) as total_score, AVG(a.avg_score) AS avg_score, AVG(a.percentage) as percentage, SUM(a.max_obtainable) AS max_obtainable
FROM `student_class_result_overview` `a`
JOIN `student_biodata` `b` ON `a`.`student_id` = `b`.`id`
WHERE `session_id` = '4'
AND `class_id` = '10'
GROUP BY `student_id`
DEBUG - 2017-07-17 00:46:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:46:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:46:08 --> Session Class Initialized
DEBUG - 2017-07-17 00:46:08 --> Session routines successfully run
DEBUG - 2017-07-17 00:46:08 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 00:46:08 --> Severity: Warning --> explode() expects at least 2 parameters, 1 given C:\xampp\htdocs\school_ms\application\models\Reports_model.php 262
ERROR - 2017-07-17 00:46:08 --> Severity: Warning --> explode() expects at least 2 parameters, 1 given C:\xampp\htdocs\school_ms\application\models\Reports_model.php 263
ERROR - 2017-07-17 00:46:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\school_ms\application\models\Reports_model.php 266
ERROR - 2017-07-17 00:46:08 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\school_ms\application\models\Reports_model.php 273
DEBUG - 2017-07-17 00:46:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:46:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:46:41 --> Session Class Initialized
DEBUG - 2017-07-17 00:46:41 --> Session routines successfully run
DEBUG - 2017-07-17 00:46:41 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 00:46:41 --> Severity: error --> Exception: Cannot use object of type CI_DB_mysqli_result as array C:\xampp\htdocs\school_ms\application\models\Reports_model.php 271
DEBUG - 2017-07-17 00:47:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:47:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:47:05 --> Session Class Initialized
DEBUG - 2017-07-17 00:47:05 --> Session routines successfully run
DEBUG - 2017-07-17 00:47:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:47:05 --> Total execution time: 0.1654
DEBUG - 2017-07-17 00:47:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:47:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:47:17 --> Session Class Initialized
DEBUG - 2017-07-17 00:47:17 --> Session routines successfully run
DEBUG - 2017-07-17 00:47:17 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 00:47:17 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\school_ms\application\models\Reports_model.php 288
DEBUG - 2017-07-17 00:47:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:47:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:47:29 --> Session Class Initialized
DEBUG - 2017-07-17 00:47:29 --> Session routines successfully run
DEBUG - 2017-07-17 00:47:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:49:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:49:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:49:06 --> Session Class Initialized
DEBUG - 2017-07-17 00:49:06 --> Session routines successfully run
DEBUG - 2017-07-17 00:49:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:49:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:49:55 --> Session Class Initialized
DEBUG - 2017-07-17 00:49:55 --> Session routines successfully run
DEBUG - 2017-07-17 00:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:50:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:50:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:50:23 --> Session Class Initialized
DEBUG - 2017-07-17 00:50:23 --> Session routines successfully run
DEBUG - 2017-07-17 00:50:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:50:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:50:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:50:42 --> Session Class Initialized
DEBUG - 2017-07-17 00:50:42 --> Session routines successfully run
DEBUG - 2017-07-17 00:50:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:50:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:50:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:50:49 --> Session Class Initialized
DEBUG - 2017-07-17 00:50:49 --> Session routines successfully run
DEBUG - 2017-07-17 00:50:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:51:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:51:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:51:33 --> Session Class Initialized
DEBUG - 2017-07-17 00:51:33 --> Session routines successfully run
DEBUG - 2017-07-17 00:51:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:56:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:56:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:56:18 --> Session Class Initialized
DEBUG - 2017-07-17 00:56:18 --> Session routines successfully run
DEBUG - 2017-07-17 00:56:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:57 --> No URI present. Default controller set.
DEBUG - 2017-07-17 00:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:57 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:57 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:57 --> Total execution time: 0.1830
DEBUG - 2017-07-17 00:57:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 00:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 00:57:58 --> Session Class Initialized
DEBUG - 2017-07-17 00:57:58 --> Session routines successfully run
DEBUG - 2017-07-17 00:57:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 00:57:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:07 --> No URI present. Default controller set.
DEBUG - 2017-07-17 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:07 --> Total execution time: 0.1168
DEBUG - 2017-07-17 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:01:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:01:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:01:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:04:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:04:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:04:27 --> Session Class Initialized
DEBUG - 2017-07-17 01:04:27 --> Session routines successfully run
DEBUG - 2017-07-17 01:04:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:06:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:06:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:06:40 --> Session Class Initialized
DEBUG - 2017-07-17 01:06:40 --> Session routines successfully run
DEBUG - 2017-07-17 01:06:40 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:06:40 --> Severity: Warning --> Illegal offset type in isset or empty C:\xampp\htdocs\school_ms\application\models\Reports_model.php 282
ERROR - 2017-07-17 01:06:40 --> Severity: Warning --> Illegal offset type in isset or empty C:\xampp\htdocs\school_ms\application\models\Reports_model.php 282
ERROR - 2017-07-17 01:06:40 --> Severity: Warning --> Illegal offset type in isset or empty C:\xampp\htdocs\school_ms\application\models\Reports_model.php 282
ERROR - 2017-07-17 01:06:40 --> Severity: Warning --> Illegal offset type in isset or empty C:\xampp\htdocs\school_ms\application\models\Reports_model.php 282
DEBUG - 2017-07-17 01:07:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:07:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:07:02 --> Session Class Initialized
DEBUG - 2017-07-17 01:07:02 --> Session routines successfully run
DEBUG - 2017-07-17 01:07:02 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:07:02 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\school_ms\application\models\School_setup_model.php 338
ERROR - 2017-07-17 01:07:03 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
ERROR - 2017-07-17 01:07:03 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\school_ms\application\models\School_setup_model.php 338
ERROR - 2017-07-17 01:07:03 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
DEBUG - 2017-07-17 01:07:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:07:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:07:55 --> Session Class Initialized
DEBUG - 2017-07-17 01:07:55 --> Session routines successfully run
DEBUG - 2017-07-17 01:07:55 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:07:55 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
ERROR - 2017-07-17 01:07:55 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
DEBUG - 2017-07-17 01:08:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:08:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:08:11 --> Session Class Initialized
DEBUG - 2017-07-17 01:08:11 --> Session routines successfully run
DEBUG - 2017-07-17 01:08:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:08:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:08:30 --> Session Class Initialized
DEBUG - 2017-07-17 01:08:30 --> Session routines successfully run
DEBUG - 2017-07-17 01:08:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:08:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:08:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:08:54 --> Session Class Initialized
DEBUG - 2017-07-17 01:08:54 --> Session routines successfully run
DEBUG - 2017-07-17 01:08:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:09:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:09:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:09:11 --> Session Class Initialized
DEBUG - 2017-07-17 01:09:11 --> Session routines successfully run
DEBUG - 2017-07-17 01:09:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:09:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:09:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:09:36 --> Session Class Initialized
DEBUG - 2017-07-17 01:09:37 --> Session routines successfully run
DEBUG - 2017-07-17 01:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:09:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:09:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:09:52 --> Session Class Initialized
DEBUG - 2017-07-17 01:09:52 --> Session routines successfully run
DEBUG - 2017-07-17 01:09:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:10:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:10:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:10:20 --> Session Class Initialized
DEBUG - 2017-07-17 01:10:20 --> Session routines successfully run
DEBUG - 2017-07-17 01:10:20 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:10:20 --> Severity: Notice --> Undefined index: school_term_id C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
ERROR - 2017-07-17 01:10:20 --> Severity: Notice --> Undefined index: school_term_id C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
ERROR - 2017-07-17 01:10:20 --> Severity: Notice --> Undefined index: school_term_id C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
ERROR - 2017-07-17 01:10:20 --> Severity: Notice --> Undefined index: school_term_id C:\xampp\htdocs\school_ms\application\models\Reports_model.php 283
DEBUG - 2017-07-17 01:10:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:10:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:10:37 --> Session Class Initialized
DEBUG - 2017-07-17 01:10:37 --> Session routines successfully run
DEBUG - 2017-07-17 01:10:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:11:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:11:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:11:20 --> Session Class Initialized
DEBUG - 2017-07-17 01:11:20 --> Session routines successfully run
DEBUG - 2017-07-17 01:11:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:12:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:12:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:12:31 --> Session Class Initialized
DEBUG - 2017-07-17 01:12:31 --> Session routines successfully run
DEBUG - 2017-07-17 01:12:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:13:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:13:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:13:25 --> Session Class Initialized
DEBUG - 2017-07-17 01:13:25 --> Session routines successfully run
DEBUG - 2017-07-17 01:13:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:14:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:14:02 --> Session Class Initialized
DEBUG - 2017-07-17 01:14:02 --> Session routines successfully run
DEBUG - 2017-07-17 01:14:02 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: student_name C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: total_score C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 94
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 95
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 96
ERROR - 2017-07-17 01:14:02 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
DEBUG - 2017-07-17 01:14:02 --> Total execution time: 0.2591
DEBUG - 2017-07-17 01:21:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:21:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:21:42 --> Session Class Initialized
DEBUG - 2017-07-17 01:21:42 --> Session routines successfully run
DEBUG - 2017-07-17 01:21:42 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average_score C:\xampp\htdocs\school_ms\application\models\Reports_model.php 278
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: student_name C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: total_score C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 94
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 95
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 96
ERROR - 2017-07-17 01:21:43 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
DEBUG - 2017-07-17 01:21:43 --> Total execution time: 0.7191
DEBUG - 2017-07-17 01:21:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:21:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:21:59 --> Session Class Initialized
DEBUG - 2017-07-17 01:21:59 --> Session routines successfully run
DEBUG - 2017-07-17 01:21:59 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: student_name C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 93
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: total_score C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 94
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 95
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: position C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 96
ERROR - 2017-07-17 01:21:59 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
DEBUG - 2017-07-17 01:21:59 --> Total execution time: 0.2838
DEBUG - 2017-07-17 01:27:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:27:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:27:23 --> Session Class Initialized
DEBUG - 2017-07-17 01:27:23 --> Session routines successfully run
DEBUG - 2017-07-17 01:27:23 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:27:23 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:23 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:24 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 98
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:27:25 --> Severity: Notice --> Undefined index: student_id C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 103
DEBUG - 2017-07-17 01:27:25 --> Total execution time: 1.5923
DEBUG - 2017-07-17 01:28:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:28:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:28:06 --> Session Class Initialized
DEBUG - 2017-07-17 01:28:06 --> Session routines successfully run
DEBUG - 2017-07-17 01:28:06 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
ERROR - 2017-07-17 01:28:06 --> Severity: Notice --> Undefined index: average C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 100
DEBUG - 2017-07-17 01:28:06 --> Total execution time: 0.5622
DEBUG - 2017-07-17 01:28:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:28:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:28:13 --> Session Class Initialized
DEBUG - 2017-07-17 01:28:13 --> Session routines successfully run
DEBUG - 2017-07-17 01:28:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:28:14 --> Total execution time: 0.1799
DEBUG - 2017-07-17 01:29:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:29:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:29:10 --> Session Class Initialized
DEBUG - 2017-07-17 01:29:10 --> Session routines successfully run
DEBUG - 2017-07-17 01:29:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:29:10 --> Total execution time: 0.1996
DEBUG - 2017-07-17 01:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:30:09 --> Session Class Initialized
DEBUG - 2017-07-17 01:30:09 --> Session routines successfully run
DEBUG - 2017-07-17 01:30:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:30:10 --> Total execution time: 0.1741
DEBUG - 2017-07-17 01:33:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:33:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:33:16 --> Session Class Initialized
DEBUG - 2017-07-17 01:33:16 --> Session routines successfully run
DEBUG - 2017-07-17 01:33:16 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:33:16 --> Severity: Notice --> Undefined index: terms C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 89
ERROR - 2017-07-17 01:33:16 --> Severity: Notice --> Undefined index: term_keys C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 90
ERROR - 2017-07-17 01:33:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\school_ms\application\views\admin\student_report.php 91
DEBUG - 2017-07-17 01:33:16 --> Total execution time: 0.2699
DEBUG - 2017-07-17 01:33:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:33:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:33:57 --> Session Class Initialized
DEBUG - 2017-07-17 01:33:57 --> Session routines successfully run
DEBUG - 2017-07-17 01:33:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:33:58 --> Total execution time: 1.9094
DEBUG - 2017-07-17 01:34:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:34:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:34:03 --> Session Class Initialized
DEBUG - 2017-07-17 01:34:03 --> Session routines successfully run
DEBUG - 2017-07-17 01:34:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:34:03 --> Total execution time: 0.2020
DEBUG - 2017-07-17 01:34:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:34:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:34:05 --> Session Class Initialized
DEBUG - 2017-07-17 01:34:05 --> Session routines successfully run
DEBUG - 2017-07-17 01:34:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:34:05 --> Total execution time: 0.1989
DEBUG - 2017-07-17 01:34:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:34:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:34:54 --> Session Class Initialized
DEBUG - 2017-07-17 01:34:54 --> Session routines successfully run
DEBUG - 2017-07-17 01:34:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:34:54 --> Total execution time: 0.1891
DEBUG - 2017-07-17 01:35:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:35:23 --> Session Class Initialized
DEBUG - 2017-07-17 01:35:23 --> Session routines successfully run
DEBUG - 2017-07-17 01:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:35:23 --> Total execution time: 0.2153
DEBUG - 2017-07-17 01:43:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:43:54 --> Session Class Initialized
DEBUG - 2017-07-17 01:43:54 --> Session routines successfully run
DEBUG - 2017-07-17 01:43:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:43:55 --> Total execution time: 0.1626
DEBUG - 2017-07-17 01:44:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:01 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:01 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:01 --> Total execution time: 0.1859
DEBUG - 2017-07-17 01:44:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:11 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:11 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:11 --> Total execution time: 0.3086
DEBUG - 2017-07-17 01:44:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:34 --> No URI present. Default controller set.
DEBUG - 2017-07-17 01:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:34 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:34 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:34 --> Total execution time: 0.3829
DEBUG - 2017-07-17 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:35 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:35 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:35 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:35 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:35 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:35 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:36 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:36 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:36 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:44:36 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:36 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Session Class Initialized
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:36 --> Session routines successfully run
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:44:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:44:59 --> No URI present. Default controller set.
DEBUG - 2017-07-17 01:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:00 --> Total execution time: 0.1472
DEBUG - 2017-07-17 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:00 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:00 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:01 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:01 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:01 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:01 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:01 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:01 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:45:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:45:17 --> Session Class Initialized
DEBUG - 2017-07-17 01:45:17 --> Session routines successfully run
DEBUG - 2017-07-17 01:45:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:45:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:57 --> No URI present. Default controller set.
DEBUG - 2017-07-17 01:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:58 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:58 --> Total execution time: 0.2070
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:58 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:58 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:58 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:59 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:59 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:59 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:59 --> Session Class Initialized
DEBUG - 2017-07-17 01:46:59 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:59 --> Session routines successfully run
DEBUG - 2017-07-17 01:46:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:06 --> No URI present. Default controller set.
DEBUG - 2017-07-17 01:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:06 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:06 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:06 --> Total execution time: 0.1664
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:07 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:07 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:08 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:08 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 01:47:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:14 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:14 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:14 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:47:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND class_id = 10 AND t.subject_id = a.subject_id) AS class_max_score, (SELECT M' at line 1 - Invalid query: SELECT IFNULL(b.ca1, 0) AS ca1, IFNULL(b.ca2, 0) AS ca2, IFNULL(b.exam, 0) AS exam, IFNULL(c.total_score, 0) AS total_score, IFNULL(c.position, 0) AS position, `a`.`subject_name`, (SELECT MAX(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_max_score, (SELECT MIN(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_min_score, (SELECT AVG(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_avg_score
FROM `subjects` `a`
LEFT JOIN `results` `b` ON `a`.`subject_id` = `b`.`subject_id` AND `b`.`session_id` = 4 AND `b`.`term_id` = `all` AND `b`.`class_id` = 10 AND `b`.`student_id` = 985
LEFT JOIN `subject_result_overview` `c` ON `b`.`student_id` = `c`.`student_id` AND `b`.`subject_id` = `c`.`subject_id` AND `c`.`session_id` = 4 AND `c`.`term_id` = `all` AND `c`.`class_id` = 10
WHERE `a`.`subject_id` IN('28', '22', '24', '42', '38', '35', '45', '37', '21', '39', '31', '25', '20', '47', '32', '34')
DEBUG - 2017-07-17 01:47:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 01:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 01:47:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 01:47:53 --> Session Class Initialized
DEBUG - 2017-07-17 01:47:54 --> Session routines successfully run
DEBUG - 2017-07-17 01:47:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-17 01:47:54 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-17 01:47:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'AND class_id = 10 AND t.subject_id = a.subject_id) AS class_max_score, (SELECT M' at line 1 - Invalid query: SELECT IFNULL(b.ca1, 0) AS ca1, IFNULL(b.ca2, 0) AS ca2, IFNULL(b.exam, 0) AS exam, IFNULL(c.total_score, 0) AS total_score, IFNULL(c.position, 0) AS position, `a`.`subject_name`, (SELECT MAX(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_max_score, (SELECT MIN(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_min_score, (SELECT AVG(total_score) FROM subject_result_overview t WHERE session_id = 4 AND term_id = all AND class_id = 10 AND t.subject_id = a.subject_id) AS class_avg_score
FROM `subjects` `a`
LEFT JOIN `results` `b` ON `a`.`subject_id` = `b`.`subject_id` AND `b`.`session_id` = 4 AND `b`.`term_id` = `all` AND `b`.`class_id` = 10 AND `b`.`student_id` = 985
LEFT JOIN `subject_result_overview` `c` ON `b`.`student_id` = `c`.`student_id` AND `b`.`subject_id` = `c`.`subject_id` AND `c`.`session_id` = 4 AND `c`.`term_id` = `all` AND `c`.`class_id` = 10
WHERE `a`.`subject_id` IN('28', '22', '24', '42', '38', '35', '45', '37', '21', '39', '31', '25', '20', '47', '32', '34')
DEBUG - 2017-07-17 02:02:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-17 02:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-17 02:02:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-17 02:02:18 --> Session Class Initialized
DEBUG - 2017-07-17 02:02:18 --> Session routines successfully run
DEBUG - 2017-07-17 02:02:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-17 02:02:18 --> Total execution time: 0.2486

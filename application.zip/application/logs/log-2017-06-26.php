<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-26 09:13:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-26 09:13:37 --> No URI present. Default controller set.
DEBUG - 2017-06-26 09:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-26 09:13:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-26 09:13:37 --> Session Class Initialized
ERROR - 2017-06-26 09:13:37 --> Session: The session cookie was not signed.
DEBUG - 2017-06-26 09:13:37 --> Session routines successfully run
DEBUG - 2017-06-26 09:13:37 --> Total execution time: 1.0740
DEBUG - 2017-06-26 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-26 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-26 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-26 09:13:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-26 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-26 09:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-26 09:13:39 --> Session Class Initialized
DEBUG - 2017-06-26 09:13:39 --> Session Class Initialized
DEBUG - 2017-06-26 09:13:39 --> Session routines successfully run
DEBUG - 2017-06-26 09:13:39 --> Session routines successfully run
DEBUG - 2017-06-26 09:13:39 --> Session Class Initialized
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-26 09:13:39 --> Session routines successfully run
DEBUG - 2017-06-26 09:13:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-26 09:13:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-26 09:13:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-26 09:13:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-26 09:13:39 --> Myapp class already loaded. Second attempt ignored.

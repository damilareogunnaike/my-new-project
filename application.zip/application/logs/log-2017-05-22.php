<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-22 04:53:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:53:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:53:44 --> Session Class Initialized
ERROR - 2017-05-22 04:53:44 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 04:53:44 --> Session routines successfully run
DEBUG - 2017-05-22 04:53:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:53:45 --> No URI present. Default controller set.
DEBUG - 2017-05-22 04:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:53:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:53:45 --> Session Class Initialized
ERROR - 2017-05-22 04:53:45 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 04:53:45 --> Session routines successfully run
DEBUG - 2017-05-22 04:53:46 --> Total execution time: 0.0923
DEBUG - 2017-05-22 04:54:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:54:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:54:53 --> Session Class Initialized
ERROR - 2017-05-22 04:54:53 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 04:54:53 --> Session routines successfully run
DEBUG - 2017-05-22 04:54:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:54:55 --> No URI present. Default controller set.
DEBUG - 2017-05-22 04:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:54:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:54:55 --> Session Class Initialized
DEBUG - 2017-05-22 04:54:55 --> Session routines successfully run
DEBUG - 2017-05-22 04:54:55 --> Total execution time: 0.0400
DEBUG - 2017-05-22 04:55:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:55:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:55:29 --> Session Class Initialized
DEBUG - 2017-05-22 04:55:29 --> Session routines successfully run
DEBUG - 2017-05-22 04:55:29 --> Session Class Initialized
DEBUG - 2017-05-22 04:55:29 --> Session routines successfully run
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 04:55:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 04:55:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 04:55:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 04:55:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 04:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 04:55:29 --> Session Class Initialized
DEBUG - 2017-05-22 04:55:29 --> Session routines successfully run
DEBUG - 2017-05-22 04:55:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 04:55:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:17:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:17:56 --> Session Class Initialized
ERROR - 2017-05-22 07:17:56 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 07:17:56 --> Session routines successfully run
DEBUG - 2017-05-22 07:17:56 --> Total execution time: 0.8087
DEBUG - 2017-05-22 07:18:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:18:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:18:13 --> Session Class Initialized
ERROR - 2017-05-22 07:18:13 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 07:18:13 --> Session routines successfully run
DEBUG - 2017-05-22 07:18:13 --> User with name admin just logged in
DEBUG - 2017-05-22 07:18:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:18:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:18:17 --> Session Class Initialized
DEBUG - 2017-05-22 07:18:17 --> Session routines successfully run
DEBUG - 2017-05-22 07:18:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:18:17 --> Total execution time: 0.7647
DEBUG - 2017-05-22 07:18:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:18:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:18:36 --> Session Class Initialized
DEBUG - 2017-05-22 07:18:36 --> Session routines successfully run
DEBUG - 2017-05-22 07:18:36 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-22 07:18:36 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-22 07:18:36 --> Total execution time: 0.1756
DEBUG - 2017-05-22 07:18:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:18:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:18:52 --> Session Class Initialized
DEBUG - 2017-05-22 07:18:52 --> Session routines successfully run
DEBUG - 2017-05-22 07:18:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:18:53 --> Total execution time: 0.3784
DEBUG - 2017-05-22 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:19:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:19:31 --> Session Class Initialized
DEBUG - 2017-05-22 07:19:31 --> Session routines successfully run
DEBUG - 2017-05-22 07:19:34 --> Total execution time: 2.1001
DEBUG - 2017-05-22 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:28:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:28:51 --> Session Class Initialized
DEBUG - 2017-05-22 07:28:51 --> Session routines successfully run
DEBUG - 2017-05-22 07:28:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:28:52 --> Total execution time: 0.4909
DEBUG - 2017-05-22 07:29:24 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:29:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:29:24 --> Session Class Initialized
DEBUG - 2017-05-22 07:29:24 --> Session routines successfully run
DEBUG - 2017-05-22 07:29:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:29:25 --> Total execution time: 0.1891
DEBUG - 2017-05-22 07:29:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:29:25 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:29:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:29:25 --> Session Class Initialized
DEBUG - 2017-05-22 07:29:25 --> Session routines successfully run
DEBUG - 2017-05-22 07:29:25 --> Total execution time: 0.0592
DEBUG - 2017-05-22 07:30:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:30:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:30:01 --> Session Class Initialized
DEBUG - 2017-05-22 07:30:01 --> Session routines successfully run
DEBUG - 2017-05-22 07:30:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:30:02 --> You did not select a file to upload.
DEBUG - 2017-05-22 07:30:02 --> Total execution time: 0.5187
DEBUG - 2017-05-22 07:30:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:30:03 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:30:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:30:03 --> Session Class Initialized
DEBUG - 2017-05-22 07:30:03 --> Session routines successfully run
DEBUG - 2017-05-22 07:30:03 --> Total execution time: 0.0524
DEBUG - 2017-05-22 07:30:12 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:30:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:30:12 --> Session Class Initialized
DEBUG - 2017-05-22 07:30:12 --> Session routines successfully run
DEBUG - 2017-05-22 07:30:12 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-22 07:30:12 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-22 07:30:12 --> Total execution time: 0.0691
DEBUG - 2017-05-22 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:30:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:30:20 --> Session Class Initialized
DEBUG - 2017-05-22 07:30:20 --> Session routines successfully run
DEBUG - 2017-05-22 07:30:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:30:20 --> Total execution time: 0.1158
DEBUG - 2017-05-22 07:31:18 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:31:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:31:18 --> Session Class Initialized
DEBUG - 2017-05-22 07:31:18 --> Session routines successfully run
DEBUG - 2017-05-22 07:31:18 --> Total execution time: 0.7448
DEBUG - 2017-05-22 07:34:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:34:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:34:09 --> Session Class Initialized
DEBUG - 2017-05-22 07:34:09 --> Session routines successfully run
DEBUG - 2017-05-22 07:34:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:34:09 --> Total execution time: 0.3588
DEBUG - 2017-05-22 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:34:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:34:46 --> Session Class Initialized
DEBUG - 2017-05-22 07:34:46 --> Session routines successfully run
DEBUG - 2017-05-22 07:34:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:34:46 --> Total execution time: 0.3171
DEBUG - 2017-05-22 07:34:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:34:53 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:34:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:34:53 --> Session Class Initialized
DEBUG - 2017-05-22 07:34:53 --> Session routines successfully run
DEBUG - 2017-05-22 07:34:53 --> Total execution time: 0.0839
DEBUG - 2017-05-22 07:35:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:35:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:35:14 --> Session Class Initialized
DEBUG - 2017-05-22 07:35:14 --> Session routines successfully run
DEBUG - 2017-05-22 07:35:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:35:14 --> You did not select a file to upload.
DEBUG - 2017-05-22 07:35:14 --> Total execution time: 0.0645
DEBUG - 2017-05-22 07:35:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:35:15 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:35:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:35:15 --> Session Class Initialized
DEBUG - 2017-05-22 07:35:15 --> Session routines successfully run
DEBUG - 2017-05-22 07:35:15 --> Total execution time: 0.0739
DEBUG - 2017-05-22 07:35:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:35:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:35:22 --> Session Class Initialized
DEBUG - 2017-05-22 07:35:22 --> Session routines successfully run
DEBUG - 2017-05-22 07:35:22 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-22 07:35:22 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-22 07:35:22 --> Total execution time: 0.0765
DEBUG - 2017-05-22 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:35:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:35:30 --> Session Class Initialized
DEBUG - 2017-05-22 07:35:30 --> Session routines successfully run
DEBUG - 2017-05-22 07:35:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:35:30 --> Total execution time: 0.0875
DEBUG - 2017-05-22 07:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:35:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:35:46 --> Session Class Initialized
DEBUG - 2017-05-22 07:35:46 --> Session routines successfully run
DEBUG - 2017-05-22 07:35:47 --> Total execution time: 0.6924
DEBUG - 2017-05-22 07:40:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:40:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:40:46 --> Session Class Initialized
DEBUG - 2017-05-22 07:40:46 --> Session routines successfully run
DEBUG - 2017-05-22 07:40:46 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-22 07:40:46 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-22 07:40:47 --> Total execution time: 0.1460
DEBUG - 2017-05-22 07:41:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:41:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:41:00 --> Session Class Initialized
DEBUG - 2017-05-22 07:41:00 --> Session routines successfully run
DEBUG - 2017-05-22 07:41:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:41:01 --> Total execution time: 0.6968
DEBUG - 2017-05-22 07:41:15 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:41:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:41:15 --> Session Class Initialized
DEBUG - 2017-05-22 07:41:15 --> Session routines successfully run
DEBUG - 2017-05-22 07:41:16 --> Total execution time: 0.5727
DEBUG - 2017-05-22 07:43:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:43:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:43:45 --> Session Class Initialized
DEBUG - 2017-05-22 07:43:45 --> Session routines successfully run
DEBUG - 2017-05-22 07:43:45 --> Total execution time: 0.3085
DEBUG - 2017-05-22 07:43:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:43:55 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:43:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:43:55 --> Session Class Initialized
DEBUG - 2017-05-22 07:43:55 --> Session routines successfully run
DEBUG - 2017-05-22 07:43:55 --> Total execution time: 0.0662
DEBUG - 2017-05-22 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:10 --> Session Class Initialized
ERROR - 2017-05-22 07:45:10 --> Session: The session cookie was not signed.
DEBUG - 2017-05-22 07:45:10 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:10 --> Total execution time: 0.0483
DEBUG - 2017-05-22 07:45:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:13 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:13 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:14 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:14 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:14 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:14 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:29 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:29 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:29 --> User with name admin just logged in
DEBUG - 2017-05-22 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:30 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:30 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:30 --> Total execution time: 0.1794
DEBUG - 2017-05-22 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:36 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:36 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:37 --> Total execution time: 0.1066
DEBUG - 2017-05-22 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:39 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:39 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:39 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:39 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:39 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:39 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:40 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:40 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:40 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:40 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:40 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:40 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:40 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:40 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:42 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:42 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:45:42 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:42 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:42 --> Session Class Initialized
DEBUG - 2017-05-22 07:45:42 --> Session routines successfully run
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:45:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:06 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:06 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:06 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:06 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:08 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:08 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:08 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:10 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:10 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:10 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:19 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:19 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:43 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:43 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:54 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:54 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:54 --> Total execution time: 0.0808
DEBUG - 2017-05-22 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:55 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:55 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:55 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:55 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:55 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:55 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:55 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:56 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:56 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:56 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:56 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:46:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:46:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:46:59 --> Session Class Initialized
DEBUG - 2017-05-22 07:46:59 --> Session routines successfully run
DEBUG - 2017-05-22 07:46:59 --> User with name admin just logged in
DEBUG - 2017-05-22 07:47:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:01 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:01 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:01 --> Total execution time: 0.2085
DEBUG - 2017-05-22 07:47:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:06 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:06 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:06 --> Total execution time: 0.1002
DEBUG - 2017-05-22 07:47:14 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:14 --> No URI present. Default controller set.
DEBUG - 2017-05-22 07:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:14 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:14 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:14 --> Total execution time: 0.0514
DEBUG - 2017-05-22 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:22 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:22 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:22 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:22 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:23 --> Total execution time: 0.5372
DEBUG - 2017-05-22 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:23 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:23 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:23 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:23 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:25 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:25 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:26 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:26 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:26 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:27 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:27 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:29 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:29 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-22 07:47:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-22 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-22 07:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-22 07:47:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-22 07:47:30 --> Session Class Initialized
DEBUG - 2017-05-22 07:47:30 --> Session routines successfully run
DEBUG - 2017-05-22 07:47:30 --> Total execution time: 0.0698

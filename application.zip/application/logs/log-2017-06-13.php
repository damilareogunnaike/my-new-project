<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-13 03:37:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 03:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 03:37:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 03:37:16 --> Session Class Initialized
ERROR - 2017-06-13 03:37:16 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 03:37:16 --> Session routines successfully run
DEBUG - 2017-06-13 03:37:16 --> Total execution time: 0.5843
DEBUG - 2017-06-13 03:38:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 03:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 03:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 03:38:16 --> Session Class Initialized
DEBUG - 2017-06-13 03:38:16 --> Session routines successfully run
DEBUG - 2017-06-13 03:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 03:38:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 03:38:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 03:38:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 03:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 03:38:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 03:38:17 --> Session Class Initialized
DEBUG - 2017-06-13 03:38:17 --> Session routines successfully run
DEBUG - 2017-06-13 03:38:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 03:38:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 03:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 03:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 03:38:18 --> Session Class Initialized
DEBUG - 2017-06-13 03:38:18 --> Session routines successfully run
DEBUG - 2017-06-13 03:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 03:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:16 --> Session Class Initialized
ERROR - 2017-06-13 04:04:16 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:04:16 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:16 --> Total execution time: 0.1103
DEBUG - 2017-06-13 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:29 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:29 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:29 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:29 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:29 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:29 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:42 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:42 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:42 --> User with name admin just logged in
DEBUG - 2017-06-13 04:04:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:43 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:43 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:43 --> Total execution time: 0.4647
DEBUG - 2017-06-13 04:04:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:50 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:50 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:50 --> Total execution time: 0.1809
DEBUG - 2017-06-13 04:04:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:53 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:53 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:53 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:53 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:53 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:53 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:56 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:56 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:56 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:56 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:56 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:56 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:57 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:57 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:04:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:04:58 --> Session Class Initialized
DEBUG - 2017-06-13 04:04:58 --> Session routines successfully run
DEBUG - 2017-06-13 04:04:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:04:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:04:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:05:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:05:11 --> Session Class Initialized
DEBUG - 2017-06-13 04:05:11 --> Session routines successfully run
DEBUG - 2017-06-13 04:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:05:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:05:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:05:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:05:16 --> Session Class Initialized
DEBUG - 2017-06-13 04:05:16 --> Session routines successfully run
DEBUG - 2017-06-13 04:05:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:05:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:15 --> Session Class Initialized
ERROR - 2017-06-13 04:11:15 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:11:15 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:15 --> Total execution time: 0.0973
DEBUG - 2017-06-13 04:11:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:30 --> Session Class Initialized
DEBUG - 2017-06-13 04:11:30 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:30 --> User with name admin just logged in
DEBUG - 2017-06-13 04:11:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:31 --> Session Class Initialized
DEBUG - 2017-06-13 04:11:31 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:11:31 --> Total execution time: 0.1630
DEBUG - 2017-06-13 04:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:37 --> Session Class Initialized
DEBUG - 2017-06-13 04:11:37 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:37 --> Total execution time: 0.0581
DEBUG - 2017-06-13 04:11:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:49 --> No URI present. Default controller set.
DEBUG - 2017-06-13 04:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:49 --> Session Class Initialized
DEBUG - 2017-06-13 04:11:49 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:49 --> Total execution time: 0.0463
DEBUG - 2017-06-13 04:11:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:11:54 --> No URI present. Default controller set.
DEBUG - 2017-06-13 04:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:11:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:11:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:11:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:11:54 --> Total execution time: 0.0510
DEBUG - 2017-06-13 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:13:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:13:31 --> Session Class Initialized
ERROR - 2017-06-13 04:13:31 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:13:31 --> Session routines successfully run
DEBUG - 2017-06-13 04:13:31 --> Total execution time: 0.0881
DEBUG - 2017-06-13 04:14:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:14:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:14:06 --> Session Class Initialized
DEBUG - 2017-06-13 04:14:06 --> Session routines successfully run
DEBUG - 2017-06-13 04:14:06 --> User with name admin just logged in
DEBUG - 2017-06-13 04:14:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:14:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:14:08 --> Session Class Initialized
DEBUG - 2017-06-13 04:14:08 --> Session routines successfully run
DEBUG - 2017-06-13 04:14:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:14:08 --> Total execution time: 0.3680
DEBUG - 2017-06-13 04:14:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:14:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:14:14 --> Session Class Initialized
DEBUG - 2017-06-13 04:14:14 --> Session routines successfully run
DEBUG - 2017-06-13 04:14:14 --> Total execution time: 0.0999
DEBUG - 2017-06-13 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:22:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:22:55 --> Session Class Initialized
ERROR - 2017-06-13 04:22:55 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:22:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:22:55 --> Total execution time: 0.1039
DEBUG - 2017-06-13 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:23:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:23:13 --> Session Class Initialized
DEBUG - 2017-06-13 04:23:13 --> Session routines successfully run
DEBUG - 2017-06-13 04:23:14 --> User with name admin just logged in
DEBUG - 2017-06-13 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:23:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:23:14 --> Session Class Initialized
DEBUG - 2017-06-13 04:23:14 --> Session routines successfully run
DEBUG - 2017-06-13 04:23:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:23:15 --> Total execution time: 0.2929
DEBUG - 2017-06-13 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:23:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:23:26 --> Session Class Initialized
DEBUG - 2017-06-13 04:23:26 --> Session routines successfully run
DEBUG - 2017-06-13 04:23:26 --> Total execution time: 0.1066
DEBUG - 2017-06-13 04:27:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:38 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:38 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:38 --> Total execution time: 0.0951
DEBUG - 2017-06-13 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:40 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:40 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:40 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:40 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:27:40 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:40 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:27:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:27:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:50 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:50 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:50 --> User with name admin just logged in
DEBUG - 2017-06-13 04:27:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:27:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:27:57 --> Session Class Initialized
DEBUG - 2017-06-13 04:27:57 --> Session routines successfully run
DEBUG - 2017-06-13 04:27:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:27:57 --> Total execution time: 0.2015
DEBUG - 2017-06-13 04:28:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:05 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:05 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:05 --> Total execution time: 0.0993
DEBUG - 2017-06-13 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:07 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:07 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:07 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:07 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:07 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:07 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:07 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:07 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:07 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:08 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:08 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:08 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:08 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:23 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:23 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:28:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:28:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:28:51 --> Session Class Initialized
DEBUG - 2017-06-13 04:28:51 --> Session routines successfully run
DEBUG - 2017-06-13 04:28:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:28:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:24 --> Session Class Initialized
ERROR - 2017-06-13 04:37:24 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:37:24 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:24 --> Total execution time: 0.0792
DEBUG - 2017-06-13 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:32 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:32 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:32 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:32 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:32 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:32 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:45 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:45 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:45 --> User with name admin just logged in
DEBUG - 2017-06-13 04:37:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:47 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:47 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:47 --> Total execution time: 0.1773
DEBUG - 2017-06-13 04:37:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:47 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:47 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:53 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:53 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:53 --> Total execution time: 0.1144
DEBUG - 2017-06-13 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:37:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:37:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:38:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:38:16 --> Session Class Initialized
DEBUG - 2017-06-13 04:38:16 --> Session routines successfully run
DEBUG - 2017-06-13 04:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:38:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:38:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:38:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:38:19 --> Session Class Initialized
DEBUG - 2017-06-13 04:38:19 --> Session routines successfully run
DEBUG - 2017-06-13 04:38:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:38:19 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 04:38:20 --> Query error: Duplicate entry '4-4-996-25-21' for key 'stud_record_constr' - Invalid query: INSERT INTO `results` (`ca1`, `ca2`, `class_id`, `exam`, `session_id`, `student_id`, `subject_id`, `term_id`) VALUES (0,0,'25',48,'4','996','21','4'), (0,0,'25',46,'4','263','21','4'), (0,0,'25',41,'4','1000','21','4'), (0,0,'25',45,'4','242','21','4'), (0,0,'25',50,'4','245','21','4'), (0,0,'25',48,'4','240','21','4'), (0,0,'25',28,'4','259','21','4'), (0,0,'25',57,'4','264','21','4'), (0,0,'25',61,'4','997','21','4'), (0,0,'25',63,'4','260','21','4'), (0,0,'25',60,'4','262','21','4'), (0,0,'25',0,'4','941','21','4'), (0,0,'25',56,'4','256','21','4'), (0,0,'25',55,'4','998','21','4'), (0,0,'25',90,'4','255','21','4'), (0,0,'25',60,'4','265','21','4'), (0,0,'25',43,'4','243','21','4'), (0,0,'25',50,'4','247','21','4'), (0,0,'25',74,'4','266','21','4'), (0,0,'25',42,'4','983','21','4'), (0,0,'25',50,'4','269','21','4'), (0,0,'25',61,'4','267','21','4'), (0,0,'25',50,'4','258','21','4'), (0,0,'25',55,'4','248','21','4'), (0,0,'25',50,'4','237','21','4'), (0,0,'25',52,'4','249','21','4'), (0,0,'25',48,'4','250','21','4'), (0,0,'25',63,'4','423','21','4'), (0,0,'25',60,'4','244','21','4'), (0,0,'25',59,'4','456','21','4'), (0,0,'25',47,'4','261','21','4'), (0,0,'25',49,'4','271','21','4'), (0,0,'25',60,'4','369','21','4'), (0,0,'25',62,'4','270','21','4'), (0,0,'25',52,'4','947','21','4'), (0,0,'25',46,'4','241','21','4'), (0,0,'25',54,'4','1290','21','4')
ERROR - 2017-06-13 04:38:20 --> Query error: Duplicate entry '4-4-996-25-21' for key 'stud_record_constr' - Invalid query: INSERT INTO `results` (`ca1`, `ca2`, `class_id`, `exam`, `session_id`, `student_id`, `subject_id`, `term_id`) VALUES (0,0,'25',48,'4','996','21','4'), (0,0,'25',46,'4','263','21','4'), (0,0,'25',41,'4','1000','21','4'), (0,0,'25',45,'4','242','21','4'), (0,0,'25',50,'4','245','21','4'), (0,0,'25',48,'4','240','21','4'), (0,0,'25',28,'4','259','21','4'), (0,0,'25',57,'4','264','21','4'), (0,0,'25',61,'4','997','21','4'), (0,0,'25',63,'4','260','21','4'), (0,0,'25',60,'4','262','21','4'), (0,0,'25',0,'4','941','21','4'), (0,0,'25',56,'4','256','21','4'), (0,0,'25',55,'4','998','21','4'), (0,0,'25',90,'4','255','21','4'), (0,0,'25',60,'4','265','21','4'), (0,0,'25',43,'4','243','21','4'), (0,0,'25',50,'4','247','21','4'), (0,0,'25',74,'4','266','21','4'), (0,0,'25',42,'4','983','21','4'), (0,0,'25',50,'4','269','21','4'), (0,0,'25',61,'4','267','21','4'), (0,0,'25',50,'4','258','21','4'), (0,0,'25',55,'4','248','21','4'), (0,0,'25',50,'4','237','21','4'), (0,0,'25',52,'4','249','21','4'), (0,0,'25',48,'4','250','21','4'), (0,0,'25',63,'4','423','21','4'), (0,0,'25',60,'4','244','21','4'), (0,0,'25',59,'4','456','21','4'), (0,0,'25',47,'4','261','21','4'), (0,0,'25',49,'4','271','21','4'), (0,0,'25',60,'4','369','21','4'), (0,0,'25',62,'4','270','21','4'), (0,0,'25',52,'4','947','21','4'), (0,0,'25',46,'4','241','21','4'), (0,0,'25',54,'4','1290','21','4')
DEBUG - 2017-06-13 04:38:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:38:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:38:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:38:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:38:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:38:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:38:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:38:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:38:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:38:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:38:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:38:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:39:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:39:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:39:49 --> Session Class Initialized
DEBUG - 2017-06-13 04:39:49 --> Session routines successfully run
DEBUG - 2017-06-13 04:39:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:39:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:39:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:39:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:39:59 --> Session Class Initialized
DEBUG - 2017-06-13 04:39:59 --> Session routines successfully run
DEBUG - 2017-06-13 04:39:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:39:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:40:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:40:53 --> Session Class Initialized
DEBUG - 2017-06-13 04:40:53 --> Session routines successfully run
DEBUG - 2017-06-13 04:40:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:40:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:40:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:42:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:42:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:42:19 --> Session Class Initialized
DEBUG - 2017-06-13 04:42:19 --> Session routines successfully run
DEBUG - 2017-06-13 04:42:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:42:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:20 --> Session Class Initialized
ERROR - 2017-06-13 04:46:20 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 04:46:20 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:20 --> Total execution time: 0.1198
DEBUG - 2017-06-13 04:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:44 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:44 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:44 --> User with name admin just logged in
DEBUG - 2017-06-13 04:46:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:45 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:45 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:45 --> Total execution time: 0.1439
DEBUG - 2017-06-13 04:46:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:52 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:52 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:52 --> Total execution time: 0.1395
DEBUG - 2017-06-13 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:46:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:46:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:46:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:46:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:09 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:09 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:10 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:10 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:11 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:11 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:12 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:12 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:15 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:15 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:16 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:16 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:17 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:17 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:47:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:37 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:37 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:37 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 04:47:37 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 04:47:37 --> Total execution time: 0.1369
DEBUG - 2017-06-13 04:47:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:46 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:46 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:47:46 --> Total execution time: 0.0619
DEBUG - 2017-06-13 04:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:47:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:47:51 --> Session Class Initialized
DEBUG - 2017-06-13 04:47:51 --> Session routines successfully run
DEBUG - 2017-06-13 04:47:51 --> Total execution time: 0.3529
DEBUG - 2017-06-13 04:48:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:48:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:48:19 --> Session Class Initialized
DEBUG - 2017-06-13 04:48:19 --> Session routines successfully run
DEBUG - 2017-06-13 04:48:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:48:19 --> Total execution time: 0.1069
DEBUG - 2017-06-13 04:48:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:48:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:48:50 --> Session Class Initialized
DEBUG - 2017-06-13 04:48:50 --> Session routines successfully run
DEBUG - 2017-06-13 04:48:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:48:50 --> Total execution time: 0.1319
DEBUG - 2017-06-13 04:49:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:49:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:49:34 --> Session Class Initialized
DEBUG - 2017-06-13 04:49:34 --> Session routines successfully run
DEBUG - 2017-06-13 04:49:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:49:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:26 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:26 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:27 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:27 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:27 --> Total execution time: 0.2390
DEBUG - 2017-06-13 04:50:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:33 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:33 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:33 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:33 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:33 --> Total execution time: 0.0562
DEBUG - 2017-06-13 04:50:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:36 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:36 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:36 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:36 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:47 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:47 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:48 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:48 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:49 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:49 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:50 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:50 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:51 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:51 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:52 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:52 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:50:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:50:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:50:54 --> Session Class Initialized
DEBUG - 2017-06-13 04:50:54 --> Session routines successfully run
DEBUG - 2017-06-13 04:50:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:50:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:51:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:51:04 --> Session Class Initialized
DEBUG - 2017-06-13 04:51:04 --> Session routines successfully run
DEBUG - 2017-06-13 04:51:04 --> Total execution time: 0.0753
DEBUG - 2017-06-13 04:51:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:51:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:51:20 --> Session Class Initialized
DEBUG - 2017-06-13 04:51:20 --> Session routines successfully run
DEBUG - 2017-06-13 04:51:20 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 04:51:20 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 04:51:20 --> Total execution time: 0.0678
DEBUG - 2017-06-13 04:51:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:51:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:51:30 --> Session Class Initialized
DEBUG - 2017-06-13 04:51:30 --> Session routines successfully run
DEBUG - 2017-06-13 04:51:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:51:30 --> Total execution time: 0.0767
DEBUG - 2017-06-13 04:51:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:51:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:51:35 --> Session Class Initialized
DEBUG - 2017-06-13 04:51:35 --> Session routines successfully run
DEBUG - 2017-06-13 04:51:35 --> Total execution time: 0.1677
DEBUG - 2017-06-13 04:53:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:53:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:53:47 --> Session Class Initialized
DEBUG - 2017-06-13 04:53:47 --> Session routines successfully run
DEBUG - 2017-06-13 04:53:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:53:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:54:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:54:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:54:38 --> Session Class Initialized
DEBUG - 2017-06-13 04:54:38 --> Session routines successfully run
DEBUG - 2017-06-13 04:54:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:54:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:54:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:54:46 --> Session Class Initialized
DEBUG - 2017-06-13 04:54:46 --> Session routines successfully run
DEBUG - 2017-06-13 04:54:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:54:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:54:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:54:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:54:46 --> Session Class Initialized
DEBUG - 2017-06-13 04:54:46 --> Session routines successfully run
DEBUG - 2017-06-13 04:54:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:54:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:55:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:55:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:55:47 --> Session Class Initialized
DEBUG - 2017-06-13 04:55:47 --> Session routines successfully run
DEBUG - 2017-06-13 04:55:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:55:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:55:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:55:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:55:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:55:55 --> Session Class Initialized
DEBUG - 2017-06-13 04:55:55 --> Session routines successfully run
DEBUG - 2017-06-13 04:55:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:55:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:57:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:57:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:57:34 --> Session Class Initialized
DEBUG - 2017-06-13 04:57:34 --> Session routines successfully run
DEBUG - 2017-06-13 04:57:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:57:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:58:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:58:22 --> Session Class Initialized
DEBUG - 2017-06-13 04:58:22 --> Session routines successfully run
DEBUG - 2017-06-13 04:58:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:58:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:58:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:58:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:58:25 --> Session Class Initialized
DEBUG - 2017-06-13 04:58:25 --> Session routines successfully run
DEBUG - 2017-06-13 04:58:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:58:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:58:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:58:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:58:30 --> Session Class Initialized
DEBUG - 2017-06-13 04:58:30 --> Session routines successfully run
DEBUG - 2017-06-13 04:58:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:58:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:59:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:59:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:59:11 --> Session Class Initialized
DEBUG - 2017-06-13 04:59:11 --> Session routines successfully run
DEBUG - 2017-06-13 04:59:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:59:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:59:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 04:59:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 04:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 04:59:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 04:59:19 --> Session Class Initialized
DEBUG - 2017-06-13 04:59:19 --> Session routines successfully run
DEBUG - 2017-06-13 04:59:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 04:59:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:01:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:01:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:01:25 --> Session Class Initialized
DEBUG - 2017-06-13 05:01:25 --> Session routines successfully run
DEBUG - 2017-06-13 05:01:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:01:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:01:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:01:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:01:26 --> Session Class Initialized
DEBUG - 2017-06-13 05:01:26 --> Session routines successfully run
DEBUG - 2017-06-13 05:01:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:01:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:02:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:02:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:02:30 --> Session Class Initialized
DEBUG - 2017-06-13 05:02:30 --> Session routines successfully run
DEBUG - 2017-06-13 05:02:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:02:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:02:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:02:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:02:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:02:40 --> Session Class Initialized
DEBUG - 2017-06-13 05:02:40 --> Session routines successfully run
DEBUG - 2017-06-13 05:02:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:02:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:03:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:03:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:03:52 --> Session Class Initialized
DEBUG - 2017-06-13 05:03:52 --> Session routines successfully run
DEBUG - 2017-06-13 05:03:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:03:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:04:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:04:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:04:02 --> Session Class Initialized
DEBUG - 2017-06-13 05:04:02 --> Session routines successfully run
DEBUG - 2017-06-13 05:04:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:04:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:04:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:04:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:04:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:04:09 --> Session Class Initialized
DEBUG - 2017-06-13 05:04:09 --> Session routines successfully run
DEBUG - 2017-06-13 05:04:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:04:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:06:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:06:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:06:53 --> Session Class Initialized
DEBUG - 2017-06-13 05:06:53 --> Session routines successfully run
DEBUG - 2017-06-13 05:06:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:06:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:07:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:07:35 --> Session Class Initialized
DEBUG - 2017-06-13 05:07:35 --> Session routines successfully run
DEBUG - 2017-06-13 05:07:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:07:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:07:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:07:44 --> Session Class Initialized
DEBUG - 2017-06-13 05:07:44 --> Session routines successfully run
DEBUG - 2017-06-13 05:07:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:07:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:07:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:07:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:07:51 --> Session Class Initialized
DEBUG - 2017-06-13 05:07:51 --> Session routines successfully run
DEBUG - 2017-06-13 05:07:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:08:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:08:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:08:32 --> Session Class Initialized
DEBUG - 2017-06-13 05:08:32 --> Session routines successfully run
DEBUG - 2017-06-13 05:08:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:08:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:08:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:08:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:08:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:08:41 --> Session Class Initialized
DEBUG - 2017-06-13 05:08:41 --> Session routines successfully run
DEBUG - 2017-06-13 05:08:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:08:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:10:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:10:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:10:08 --> Session Class Initialized
DEBUG - 2017-06-13 05:10:08 --> Session routines successfully run
DEBUG - 2017-06-13 05:10:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:10:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:10:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:10:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:10:55 --> Session Class Initialized
DEBUG - 2017-06-13 05:10:55 --> Session routines successfully run
DEBUG - 2017-06-13 05:10:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:10:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:10:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:10:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:10:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:10:59 --> Session Class Initialized
DEBUG - 2017-06-13 05:10:59 --> Session routines successfully run
DEBUG - 2017-06-13 05:10:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:10:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:12:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:12:00 --> Session Class Initialized
DEBUG - 2017-06-13 05:12:00 --> Session routines successfully run
DEBUG - 2017-06-13 05:12:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:12:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:15:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:15:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:15:27 --> Session Class Initialized
DEBUG - 2017-06-13 05:15:27 --> Session routines successfully run
DEBUG - 2017-06-13 05:15:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:15:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:16:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:16:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:16:26 --> Session Class Initialized
DEBUG - 2017-06-13 05:16:26 --> Session routines successfully run
DEBUG - 2017-06-13 05:16:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:16:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:16:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:16:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:16:41 --> Session Class Initialized
DEBUG - 2017-06-13 05:16:41 --> Session routines successfully run
DEBUG - 2017-06-13 05:16:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:16:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:20:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:20:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:20:04 --> Session Class Initialized
DEBUG - 2017-06-13 05:20:04 --> Session routines successfully run
DEBUG - 2017-06-13 05:20:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:20:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:20:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:20:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:20:54 --> Session Class Initialized
DEBUG - 2017-06-13 05:20:54 --> Session routines successfully run
DEBUG - 2017-06-13 05:20:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:20:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:20:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:21:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:21:12 --> Session Class Initialized
DEBUG - 2017-06-13 05:21:12 --> Session routines successfully run
DEBUG - 2017-06-13 05:21:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:21:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:21:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:21:19 --> Session Class Initialized
DEBUG - 2017-06-13 05:21:19 --> Session routines successfully run
DEBUG - 2017-06-13 05:21:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:21:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:21:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:21:39 --> Session Class Initialized
DEBUG - 2017-06-13 05:21:39 --> Session routines successfully run
DEBUG - 2017-06-13 05:21:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:21:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:21:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:21:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:21:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:21:46 --> Session Class Initialized
DEBUG - 2017-06-13 05:21:46 --> Session routines successfully run
DEBUG - 2017-06-13 05:21:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:21:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:22:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:22:15 --> Session Class Initialized
DEBUG - 2017-06-13 05:22:15 --> Session routines successfully run
DEBUG - 2017-06-13 05:22:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:22:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:23:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:23:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:23:36 --> Session Class Initialized
DEBUG - 2017-06-13 05:23:36 --> Session routines successfully run
DEBUG - 2017-06-13 05:23:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:23:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:24:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:24:41 --> Session Class Initialized
DEBUG - 2017-06-13 05:24:41 --> Session routines successfully run
DEBUG - 2017-06-13 05:24:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:25:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:25:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:25:01 --> Session Class Initialized
DEBUG - 2017-06-13 05:25:01 --> Session routines successfully run
DEBUG - 2017-06-13 05:25:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:25:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:30:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:30:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:30:29 --> Session Class Initialized
DEBUG - 2017-06-13 05:30:29 --> Session routines successfully run
DEBUG - 2017-06-13 05:30:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:30:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:30:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:30:36 --> Session Class Initialized
DEBUG - 2017-06-13 05:30:36 --> Session routines successfully run
DEBUG - 2017-06-13 05:30:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:30:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:30:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:30:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:30:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:30:54 --> Session Class Initialized
DEBUG - 2017-06-13 05:30:54 --> Session routines successfully run
DEBUG - 2017-06-13 05:30:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:30:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:31:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:31:52 --> Session Class Initialized
DEBUG - 2017-06-13 05:31:52 --> Session routines successfully run
DEBUG - 2017-06-13 05:31:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:31:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:31:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:32:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:32:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:32:04 --> Session Class Initialized
DEBUG - 2017-06-13 05:32:04 --> Session routines successfully run
DEBUG - 2017-06-13 05:32:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:32:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:32:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:32:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:32:51 --> Session Class Initialized
DEBUG - 2017-06-13 05:32:51 --> Session routines successfully run
DEBUG - 2017-06-13 05:32:51 --> Total execution time: 0.3350
DEBUG - 2017-06-13 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:19 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 05:33:19 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 05:33:19 --> Total execution time: 0.1146
DEBUG - 2017-06-13 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:21 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:21 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:21 --> Total execution time: 0.0782
DEBUG - 2017-06-13 05:33:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:23 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:23 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:33:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:33:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:33:41 --> Session Class Initialized
DEBUG - 2017-06-13 05:33:41 --> Session routines successfully run
DEBUG - 2017-06-13 05:33:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:33:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:36:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:36:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:36:20 --> Session Class Initialized
DEBUG - 2017-06-13 05:36:20 --> Session routines successfully run
DEBUG - 2017-06-13 05:36:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:36:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:37:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:37:01 --> Session Class Initialized
DEBUG - 2017-06-13 05:37:01 --> Session routines successfully run
DEBUG - 2017-06-13 05:37:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:37:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:37:30 --> Session Class Initialized
DEBUG - 2017-06-13 05:37:30 --> Session routines successfully run
DEBUG - 2017-06-13 05:37:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:37:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:37:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:37:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:37:37 --> Session Class Initialized
DEBUG - 2017-06-13 05:37:37 --> Session routines successfully run
DEBUG - 2017-06-13 05:37:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:37:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:11 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:11 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:15 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:15 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:16 --> Total execution time: 0.1156
DEBUG - 2017-06-13 05:38:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:16 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:16 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:17 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:17 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:32 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:32 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:33 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:33 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:34 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:34 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:35 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:35 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:37 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:37 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:39 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:39 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:38:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:38:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:38:40 --> Session Class Initialized
DEBUG - 2017-06-13 05:38:40 --> Session routines successfully run
DEBUG - 2017-06-13 05:38:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:38:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:42:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:42:35 --> Session Class Initialized
DEBUG - 2017-06-13 05:42:35 --> Session routines successfully run
DEBUG - 2017-06-13 05:42:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:42:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:43:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:43:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:43:36 --> Session Class Initialized
DEBUG - 2017-06-13 05:43:36 --> Session routines successfully run
DEBUG - 2017-06-13 05:43:36 --> Total execution time: 0.6675
DEBUG - 2017-06-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:43:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:43:42 --> Session Class Initialized
DEBUG - 2017-06-13 05:43:42 --> Session routines successfully run
DEBUG - 2017-06-13 05:43:42 --> Total execution time: 0.1562
DEBUG - 2017-06-13 05:43:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:43:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:43:45 --> Session Class Initialized
DEBUG - 2017-06-13 05:43:45 --> Session routines successfully run
DEBUG - 2017-06-13 05:43:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:43:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:45:27 --> Session Class Initialized
DEBUG - 2017-06-13 05:45:27 --> Session routines successfully run
DEBUG - 2017-06-13 05:45:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:45:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:45:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:45:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:45:34 --> Session Class Initialized
DEBUG - 2017-06-13 05:45:34 --> Session routines successfully run
DEBUG - 2017-06-13 05:45:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:45:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:04 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:04 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:04 --> Total execution time: 0.4075
DEBUG - 2017-06-13 05:46:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:16 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:16 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:17 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:17 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:18 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:18 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:19 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:19 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:21 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:21 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:22 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:22 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:46:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:46:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:46:24 --> Session Class Initialized
DEBUG - 2017-06-13 05:46:24 --> Session routines successfully run
DEBUG - 2017-06-13 05:46:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:46:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:47:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:47:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:47:19 --> Session Class Initialized
DEBUG - 2017-06-13 05:47:19 --> Session routines successfully run
DEBUG - 2017-06-13 05:47:20 --> Total execution time: 0.1194
DEBUG - 2017-06-13 05:47:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:47:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:47:32 --> Session Class Initialized
DEBUG - 2017-06-13 05:47:32 --> Session routines successfully run
DEBUG - 2017-06-13 05:47:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:47:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:48:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:48:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:48:31 --> Session Class Initialized
DEBUG - 2017-06-13 05:48:31 --> Session routines successfully run
DEBUG - 2017-06-13 05:48:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:48:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:48:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:48:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:48:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:48:42 --> Session Class Initialized
DEBUG - 2017-06-13 05:48:42 --> Session routines successfully run
DEBUG - 2017-06-13 05:48:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:48:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:49:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:49:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:49:36 --> Session Class Initialized
DEBUG - 2017-06-13 05:49:36 --> Session routines successfully run
DEBUG - 2017-06-13 05:49:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:49:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:49:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:49:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:49:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:49:48 --> Session Class Initialized
DEBUG - 2017-06-13 05:49:48 --> Session routines successfully run
DEBUG - 2017-06-13 05:49:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:49:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:50:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:50:53 --> Session Class Initialized
DEBUG - 2017-06-13 05:50:53 --> Session routines successfully run
DEBUG - 2017-06-13 05:50:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:50:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:51:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:51:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:51:52 --> Session Class Initialized
DEBUG - 2017-06-13 05:51:52 --> Session routines successfully run
DEBUG - 2017-06-13 05:51:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:51:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:51:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:51:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:51:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:51:58 --> Session Class Initialized
DEBUG - 2017-06-13 05:51:58 --> Session routines successfully run
DEBUG - 2017-06-13 05:51:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:51:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:54:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:54:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:54:02 --> Session Class Initialized
DEBUG - 2017-06-13 05:54:02 --> Session routines successfully run
DEBUG - 2017-06-13 05:54:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:54:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:56:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:56:37 --> Session Class Initialized
DEBUG - 2017-06-13 05:56:37 --> Session routines successfully run
DEBUG - 2017-06-13 05:56:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:56:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:56:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:56:44 --> Session Class Initialized
DEBUG - 2017-06-13 05:56:44 --> Session routines successfully run
DEBUG - 2017-06-13 05:56:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:56:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:58:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:58:29 --> Session Class Initialized
DEBUG - 2017-06-13 05:58:29 --> Session routines successfully run
DEBUG - 2017-06-13 05:58:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:58:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:58:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:58:29 --> Session Class Initialized
DEBUG - 2017-06-13 05:58:29 --> Session routines successfully run
DEBUG - 2017-06-13 05:58:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:58:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:58:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:58:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:58:56 --> Session Class Initialized
DEBUG - 2017-06-13 05:58:56 --> Session routines successfully run
DEBUG - 2017-06-13 05:58:56 --> Total execution time: 0.3296
DEBUG - 2017-06-13 05:59:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:59:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:59:45 --> Session Class Initialized
DEBUG - 2017-06-13 05:59:45 --> Session routines successfully run
DEBUG - 2017-06-13 05:59:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:59:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:59:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 05:59:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 05:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 05:59:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 05:59:54 --> Session Class Initialized
DEBUG - 2017-06-13 05:59:54 --> Session routines successfully run
DEBUG - 2017-06-13 05:59:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 05:59:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:01:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:01:18 --> Session Class Initialized
DEBUG - 2017-06-13 06:01:18 --> Session routines successfully run
DEBUG - 2017-06-13 06:01:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:01:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:01:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:01:24 --> Session Class Initialized
DEBUG - 2017-06-13 06:01:24 --> Session routines successfully run
DEBUG - 2017-06-13 06:01:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:01:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:04:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:04:15 --> Session Class Initialized
DEBUG - 2017-06-13 06:04:15 --> Session routines successfully run
DEBUG - 2017-06-13 06:04:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:04:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:05:11 --> Session Class Initialized
DEBUG - 2017-06-13 06:05:11 --> Session routines successfully run
DEBUG - 2017-06-13 06:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:05:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:05:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:05:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:05:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:05:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:05:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:05:17 --> Session Class Initialized
DEBUG - 2017-06-13 06:05:17 --> Session routines successfully run
DEBUG - 2017-06-13 06:05:17 --> Session Class Initialized
DEBUG - 2017-06-13 06:05:17 --> Session routines successfully run
DEBUG - 2017-06-13 06:05:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:05:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:05:17 --> Total execution time: 0.2418
DEBUG - 2017-06-13 06:06:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:06:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:06:32 --> Session Class Initialized
DEBUG - 2017-06-13 06:06:32 --> Session routines successfully run
DEBUG - 2017-06-13 06:06:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:06:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:08:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:08:04 --> Session Class Initialized
DEBUG - 2017-06-13 06:08:04 --> Session routines successfully run
DEBUG - 2017-06-13 06:08:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:08:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:08:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:08:23 --> Session Class Initialized
DEBUG - 2017-06-13 06:08:23 --> Session routines successfully run
DEBUG - 2017-06-13 06:08:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:08:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:08:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:08:33 --> Session Class Initialized
DEBUG - 2017-06-13 06:08:33 --> Session routines successfully run
DEBUG - 2017-06-13 06:08:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:08:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:08:58 --> Session Class Initialized
DEBUG - 2017-06-13 06:08:58 --> Session routines successfully run
DEBUG - 2017-06-13 06:08:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:08:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:09:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:09:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:09:06 --> Session Class Initialized
DEBUG - 2017-06-13 06:09:06 --> Session routines successfully run
DEBUG - 2017-06-13 06:09:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:09:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:13:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:13:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:13:56 --> Session Class Initialized
DEBUG - 2017-06-13 06:13:56 --> Session routines successfully run
DEBUG - 2017-06-13 06:13:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:13:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:14:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:14:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:14:43 --> Session Class Initialized
DEBUG - 2017-06-13 06:14:43 --> Session routines successfully run
DEBUG - 2017-06-13 06:14:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:14:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:14:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:14:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:14:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:14:55 --> Session Class Initialized
DEBUG - 2017-06-13 06:14:55 --> Session routines successfully run
DEBUG - 2017-06-13 06:14:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:14:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:15:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:15:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:15:46 --> Session Class Initialized
DEBUG - 2017-06-13 06:15:46 --> Session routines successfully run
DEBUG - 2017-06-13 06:15:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:15:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:16:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:16:40 --> Session Class Initialized
DEBUG - 2017-06-13 06:16:40 --> Session routines successfully run
DEBUG - 2017-06-13 06:16:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:16:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:16:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:16:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:16:50 --> Session Class Initialized
DEBUG - 2017-06-13 06:16:50 --> Session routines successfully run
DEBUG - 2017-06-13 06:16:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:16:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:21:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:21:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:21:30 --> Session Class Initialized
DEBUG - 2017-06-13 06:21:30 --> Session routines successfully run
DEBUG - 2017-06-13 06:21:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:21:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:22:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:22:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:22:08 --> Session Class Initialized
DEBUG - 2017-06-13 06:22:08 --> Session routines successfully run
DEBUG - 2017-06-13 06:22:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:22:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:22:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:22:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:22:33 --> Session Class Initialized
DEBUG - 2017-06-13 06:22:33 --> Session routines successfully run
DEBUG - 2017-06-13 06:22:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:22:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:22:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:22:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:22:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:22:41 --> Session Class Initialized
DEBUG - 2017-06-13 06:22:41 --> Session routines successfully run
DEBUG - 2017-06-13 06:22:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:22:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:23:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:23:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:23:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:23:35 --> Session Class Initialized
DEBUG - 2017-06-13 06:23:35 --> Session routines successfully run
DEBUG - 2017-06-13 06:23:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:23:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:23:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:23:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:23:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:23:44 --> Session Class Initialized
DEBUG - 2017-06-13 06:23:44 --> Session routines successfully run
DEBUG - 2017-06-13 06:23:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:23:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:26:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:26:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:26:31 --> Session Class Initialized
DEBUG - 2017-06-13 06:26:31 --> Session routines successfully run
DEBUG - 2017-06-13 06:26:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:26:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:27:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:27:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:27:47 --> Session Class Initialized
DEBUG - 2017-06-13 06:27:47 --> Session routines successfully run
DEBUG - 2017-06-13 06:27:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:27:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:27:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:27:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:27:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:27:56 --> Session Class Initialized
DEBUG - 2017-06-13 06:27:56 --> Session routines successfully run
DEBUG - 2017-06-13 06:27:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:27:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:28:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:28:32 --> Session Class Initialized
DEBUG - 2017-06-13 06:28:32 --> Session routines successfully run
DEBUG - 2017-06-13 06:28:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:28:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:29:52 --> Session Class Initialized
DEBUG - 2017-06-13 06:29:52 --> Session routines successfully run
DEBUG - 2017-06-13 06:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:29:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:29:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:30:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:30:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:30:00 --> Session Class Initialized
DEBUG - 2017-06-13 06:30:00 --> Session routines successfully run
DEBUG - 2017-06-13 06:30:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:30:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:30:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:30:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:30:54 --> Session Class Initialized
DEBUG - 2017-06-13 06:30:54 --> Session routines successfully run
DEBUG - 2017-06-13 06:30:54 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 06:30:54 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 06:30:54 --> Total execution time: 0.1378
DEBUG - 2017-06-13 06:31:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:31:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:31:08 --> Session Class Initialized
DEBUG - 2017-06-13 06:31:08 --> Session routines successfully run
DEBUG - 2017-06-13 06:31:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:31:08 --> Total execution time: 0.0938
DEBUG - 2017-06-13 06:31:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:31:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:31:38 --> Session Class Initialized
DEBUG - 2017-06-13 06:31:38 --> Session routines successfully run
DEBUG - 2017-06-13 06:31:38 --> Total execution time: 0.4134
DEBUG - 2017-06-13 06:31:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:31:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:31:59 --> Session Class Initialized
DEBUG - 2017-06-13 06:31:59 --> Session routines successfully run
DEBUG - 2017-06-13 06:31:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:31:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:32:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:32:17 --> Session Class Initialized
DEBUG - 2017-06-13 06:32:17 --> Session routines successfully run
DEBUG - 2017-06-13 06:32:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:33:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:33:30 --> Session Class Initialized
DEBUG - 2017-06-13 06:33:30 --> Session routines successfully run
DEBUG - 2017-06-13 06:33:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:33:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:33:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:33:39 --> Session Class Initialized
DEBUG - 2017-06-13 06:33:39 --> Session routines successfully run
DEBUG - 2017-06-13 06:33:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:33:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:33:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:33:40 --> Session Class Initialized
DEBUG - 2017-06-13 06:33:40 --> Session routines successfully run
DEBUG - 2017-06-13 06:33:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:33:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:33:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:33:47 --> Session Class Initialized
DEBUG - 2017-06-13 06:33:47 --> Session routines successfully run
DEBUG - 2017-06-13 06:33:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:33:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:39:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:39:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:39:57 --> Session Class Initialized
DEBUG - 2017-06-13 06:39:57 --> Session routines successfully run
DEBUG - 2017-06-13 06:39:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:40:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:40:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:40:50 --> Session Class Initialized
DEBUG - 2017-06-13 06:40:50 --> Session routines successfully run
DEBUG - 2017-06-13 06:40:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:40:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:40:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:40:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:40:57 --> Session Class Initialized
DEBUG - 2017-06-13 06:40:57 --> Session routines successfully run
DEBUG - 2017-06-13 06:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:40:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:43:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:43:16 --> Session Class Initialized
DEBUG - 2017-06-13 06:43:16 --> Session routines successfully run
DEBUG - 2017-06-13 06:43:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:44:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:44:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:44:31 --> Session Class Initialized
DEBUG - 2017-06-13 06:44:31 --> Session routines successfully run
DEBUG - 2017-06-13 06:44:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:44:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:44:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:44:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:44:39 --> Session Class Initialized
DEBUG - 2017-06-13 06:44:39 --> Session routines successfully run
DEBUG - 2017-06-13 06:44:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:44:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:45:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:45:56 --> Session Class Initialized
DEBUG - 2017-06-13 06:45:56 --> Session routines successfully run
DEBUG - 2017-06-13 06:45:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:45:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:46:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:46:59 --> Session Class Initialized
DEBUG - 2017-06-13 06:46:59 --> Session routines successfully run
DEBUG - 2017-06-13 06:46:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:46:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:47:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:47:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:47:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:47:56 --> Session Class Initialized
DEBUG - 2017-06-13 06:47:56 --> Session routines successfully run
DEBUG - 2017-06-13 06:47:56 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 06:47:56 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 06:47:56 --> Total execution time: 0.1828
DEBUG - 2017-06-13 06:48:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:48:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:48:18 --> Session Class Initialized
DEBUG - 2017-06-13 06:48:18 --> Session routines successfully run
DEBUG - 2017-06-13 06:48:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:48:18 --> Total execution time: 0.1146
DEBUG - 2017-06-13 06:48:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:48:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:48:22 --> Session Class Initialized
DEBUG - 2017-06-13 06:48:22 --> Session routines successfully run
DEBUG - 2017-06-13 06:48:22 --> Total execution time: 0.7017
DEBUG - 2017-06-13 06:49:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:49:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:49:13 --> Session Class Initialized
DEBUG - 2017-06-13 06:49:13 --> Session routines successfully run
DEBUG - 2017-06-13 06:49:13 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 06:49:13 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 06:49:13 --> Total execution time: 0.1563
DEBUG - 2017-06-13 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:49:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:49:18 --> Session Class Initialized
DEBUG - 2017-06-13 06:49:18 --> Session routines successfully run
DEBUG - 2017-06-13 06:49:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:49:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:49:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:49:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:49:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:49:49 --> Session Class Initialized
DEBUG - 2017-06-13 06:49:49 --> Session routines successfully run
DEBUG - 2017-06-13 06:49:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:49:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:51:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:51:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:51:00 --> Session Class Initialized
DEBUG - 2017-06-13 06:51:00 --> Session routines successfully run
DEBUG - 2017-06-13 06:51:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:51:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:51:12 --> Session Class Initialized
DEBUG - 2017-06-13 06:51:12 --> Session routines successfully run
DEBUG - 2017-06-13 06:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:54:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:54:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:54:45 --> Session Class Initialized
DEBUG - 2017-06-13 06:54:45 --> Session routines successfully run
DEBUG - 2017-06-13 06:54:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:54:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:55:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:55:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:55:38 --> Session Class Initialized
DEBUG - 2017-06-13 06:55:38 --> Session routines successfully run
DEBUG - 2017-06-13 06:55:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:55:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:55:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:55:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:55:46 --> Session Class Initialized
DEBUG - 2017-06-13 06:55:46 --> Session routines successfully run
DEBUG - 2017-06-13 06:55:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:55:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:56:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:56:56 --> Session Class Initialized
DEBUG - 2017-06-13 06:56:56 --> Session routines successfully run
DEBUG - 2017-06-13 06:56:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:56:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:57:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:57:04 --> Session Class Initialized
DEBUG - 2017-06-13 06:57:04 --> Session routines successfully run
DEBUG - 2017-06-13 06:57:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:57:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:57:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:57:11 --> Session Class Initialized
DEBUG - 2017-06-13 06:57:11 --> Session routines successfully run
DEBUG - 2017-06-13 06:57:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:57:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:57:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:57:39 --> Session Class Initialized
DEBUG - 2017-06-13 06:57:39 --> Session routines successfully run
DEBUG - 2017-06-13 06:57:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:57:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 06:57:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 06:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 06:57:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 06:57:50 --> Session Class Initialized
DEBUG - 2017-06-13 06:57:50 --> Session routines successfully run
DEBUG - 2017-06-13 06:57:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 06:57:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 07:01:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 07:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 07:01:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 07:01:36 --> Session Class Initialized
DEBUG - 2017-06-13 07:01:36 --> Session routines successfully run
DEBUG - 2017-06-13 07:01:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 07:01:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:39 --> Session Class Initialized
ERROR - 2017-06-13 10:34:39 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 10:34:39 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:39 --> No URI present. Default controller set.
DEBUG - 2017-06-13 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:39 --> Session Class Initialized
DEBUG - 2017-06-13 10:34:39 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:40 --> Total execution time: 0.1103
DEBUG - 2017-06-13 10:34:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:45 --> Session Class Initialized
DEBUG - 2017-06-13 10:34:45 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:34:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:34:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:48 --> Session Class Initialized
DEBUG - 2017-06-13 10:34:48 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:34:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:34:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:48 --> Session Class Initialized
DEBUG - 2017-06-13 10:34:48 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:34:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:34:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:34:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:34:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:34:59 --> Session Class Initialized
DEBUG - 2017-06-13 10:34:59 --> Session routines successfully run
DEBUG - 2017-06-13 10:34:59 --> User with name admin just logged in
DEBUG - 2017-06-13 10:35:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:35:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:35:00 --> Session Class Initialized
DEBUG - 2017-06-13 10:35:00 --> Session routines successfully run
DEBUG - 2017-06-13 10:35:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:35:00 --> Total execution time: 0.4691
DEBUG - 2017-06-13 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:35:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:35:58 --> Session Class Initialized
DEBUG - 2017-06-13 10:35:58 --> Session routines successfully run
DEBUG - 2017-06-13 10:35:58 --> Total execution time: 0.1832
DEBUG - 2017-06-13 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:00 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:00 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:00 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:00 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:01 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:01 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:02 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:02 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:02 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:02 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:19 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:19 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:36:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:36:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:36:28 --> Session Class Initialized
DEBUG - 2017-06-13 10:36:28 --> Session routines successfully run
DEBUG - 2017-06-13 10:36:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:36:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:37:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:37:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:37:17 --> Session Class Initialized
ERROR - 2017-06-13 10:37:17 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 10:37:17 --> Session routines successfully run
DEBUG - 2017-06-13 10:37:17 --> Total execution time: 0.1045
DEBUG - 2017-06-13 10:37:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:37:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:37:19 --> Session Class Initialized
DEBUG - 2017-06-13 10:37:19 --> Session routines successfully run
DEBUG - 2017-06-13 10:37:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:37:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:37:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:37:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:37:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:37:20 --> Session Class Initialized
DEBUG - 2017-06-13 10:37:20 --> Session routines successfully run
DEBUG - 2017-06-13 10:37:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:37:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:38:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:38:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:38:03 --> Session Class Initialized
DEBUG - 2017-06-13 10:38:03 --> Session routines successfully run
DEBUG - 2017-06-13 10:38:03 --> User with name admin just logged in
DEBUG - 2017-06-13 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:38:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:38:04 --> Session Class Initialized
DEBUG - 2017-06-13 10:38:04 --> Session routines successfully run
DEBUG - 2017-06-13 10:38:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:38:04 --> Total execution time: 0.1927
DEBUG - 2017-06-13 10:39:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:39:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:39:16 --> Session Class Initialized
DEBUG - 2017-06-13 10:39:16 --> Session routines successfully run
DEBUG - 2017-06-13 10:39:17 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 10:39:17 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 10:39:17 --> Total execution time: 0.5136
DEBUG - 2017-06-13 10:39:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:39:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:39:32 --> Session Class Initialized
DEBUG - 2017-06-13 10:39:32 --> Session routines successfully run
DEBUG - 2017-06-13 10:39:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:39:33 --> Total execution time: 0.1150
DEBUG - 2017-06-13 10:39:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:39:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:39:36 --> Session Class Initialized
DEBUG - 2017-06-13 10:39:36 --> Session routines successfully run
DEBUG - 2017-06-13 10:39:37 --> Total execution time: 0.6862
DEBUG - 2017-06-13 10:40:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:40:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:40:15 --> Session Class Initialized
DEBUG - 2017-06-13 10:40:15 --> Session routines successfully run
DEBUG - 2017-06-13 10:40:15 --> Total execution time: 0.2153
DEBUG - 2017-06-13 10:40:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:40:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:40:46 --> Session Class Initialized
DEBUG - 2017-06-13 10:40:46 --> Session routines successfully run
DEBUG - 2017-06-13 10:40:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:40:46 --> Total execution time: 0.0657
DEBUG - 2017-06-13 10:40:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:40:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:40:53 --> Session Class Initialized
DEBUG - 2017-06-13 10:40:53 --> Session routines successfully run
DEBUG - 2017-06-13 10:40:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:40:53 --> Total execution time: 0.1293
DEBUG - 2017-06-13 10:41:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:09 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:09 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:09 --> Total execution time: 0.1745
DEBUG - 2017-06-13 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:11 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:11 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:26 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:26 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:26 --> Total execution time: 0.0755
DEBUG - 2017-06-13 10:41:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:45 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:45 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:46 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:46 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:46 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:46 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:46 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:46 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:46 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:46 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:47 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:47 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:47 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:47 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:48 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:48 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:48 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:48 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:49 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:49 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:50 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:50 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:50 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:50 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:51 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:51 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:51 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:51 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:51 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:51 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:51 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:51 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:52 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:52 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:53 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:53 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:53 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:53 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:55 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:55 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:56 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:56 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-13 10:41:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:41:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:41:58 --> Session Class Initialized
DEBUG - 2017-06-13 10:41:58 --> Session routines successfully run
DEBUG - 2017-06-13 10:41:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 10:41:58 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 10:41:58 --> Total execution time: 0.1441
DEBUG - 2017-06-13 10:42:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:42:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:42:06 --> Session Class Initialized
DEBUG - 2017-06-13 10:42:06 --> Session routines successfully run
DEBUG - 2017-06-13 10:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:42:06 --> Total execution time: 0.0975
DEBUG - 2017-06-13 10:42:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:42:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:42:14 --> Session Class Initialized
DEBUG - 2017-06-13 10:42:14 --> Session routines successfully run
DEBUG - 2017-06-13 10:42:14 --> Total execution time: 0.3212
DEBUG - 2017-06-13 10:43:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:43:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:43:55 --> Session Class Initialized
DEBUG - 2017-06-13 10:43:55 --> Session routines successfully run
DEBUG - 2017-06-13 10:43:55 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-13 10:43:55 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-13 10:43:55 --> Total execution time: 0.1659
DEBUG - 2017-06-13 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:44:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:44:03 --> Session Class Initialized
DEBUG - 2017-06-13 10:44:03 --> Session routines successfully run
DEBUG - 2017-06-13 10:44:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:44:03 --> Total execution time: 0.0850
DEBUG - 2017-06-13 10:44:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 10:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 10:44:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 10:44:08 --> Session Class Initialized
DEBUG - 2017-06-13 10:44:08 --> Session routines successfully run
DEBUG - 2017-06-13 10:44:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-13 10:44:08 --> Total execution time: 0.1419
DEBUG - 2017-06-13 16:02:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 16:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 16:02:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 16:02:19 --> Session Class Initialized
ERROR - 2017-06-13 16:02:19 --> Session: The session cookie was not signed.
DEBUG - 2017-06-13 16:02:19 --> Session routines successfully run
DEBUG - 2017-06-13 16:02:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-13 16:02:20 --> No URI present. Default controller set.
DEBUG - 2017-06-13 16:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-13 16:02:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-13 16:02:20 --> Session Class Initialized
DEBUG - 2017-06-13 16:02:20 --> Session routines successfully run
DEBUG - 2017-06-13 16:02:20 --> Total execution time: 0.1318

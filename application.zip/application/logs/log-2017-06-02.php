<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-02 05:03:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:13 --> Session Class Initialized
ERROR - 2017-06-02 05:03:13 --> Session: The session cookie was not signed.
DEBUG - 2017-06-02 05:03:13 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:13 --> Total execution time: 0.9914
DEBUG - 2017-06-02 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:25 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:25 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:25 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:25 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:25 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:25 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:40 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:40 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:40 --> User with name admin just logged in
DEBUG - 2017-06-02 05:03:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:40 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:40 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:41 --> Total execution time: 0.2633
DEBUG - 2017-06-02 05:03:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:48 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:48 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:48 --> Total execution time: 0.1543
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:51 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:53 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:53 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-02 05:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-02 05:03:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-02 05:03:54 --> Session Class Initialized
DEBUG - 2017-06-02 05:03:54 --> Session routines successfully run
DEBUG - 2017-06-02 05:03:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-02 05:03:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-02 05:03:54 --> Myapp class already loaded. Second attempt ignored.

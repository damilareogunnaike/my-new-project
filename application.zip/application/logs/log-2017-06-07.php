<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-07 05:17:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-07 05:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-07 05:17:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-07 05:17:44 --> Session Class Initialized
ERROR - 2017-06-07 05:17:44 --> Session: The session cookie was not signed.
DEBUG - 2017-06-07 05:17:44 --> Session routines successfully run
DEBUG - 2017-06-07 05:17:44 --> Total execution time: 0.7658
DEBUG - 2017-06-07 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-07 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-07 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-07 05:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-07 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-07 05:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-07 05:17:51 --> Session Class Initialized
DEBUG - 2017-06-07 05:17:51 --> Session routines successfully run
DEBUG - 2017-06-07 05:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-07 05:17:51 --> Session Class Initialized
DEBUG - 2017-06-07 05:17:51 --> Session routines successfully run
DEBUG - 2017-06-07 05:17:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-07 05:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-07 05:17:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-07 05:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-07 05:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-07 05:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-07 05:17:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-07 05:17:51 --> Session Class Initialized
DEBUG - 2017-06-07 05:17:51 --> Session routines successfully run
DEBUG - 2017-06-07 05:17:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-07 05:17:52 --> Myapp class already loaded. Second attempt ignored.

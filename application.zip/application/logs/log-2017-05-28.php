<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-28 10:36:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-28 10:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-28 10:36:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-28 10:36:04 --> Session Class Initialized
ERROR - 2017-05-28 10:36:04 --> Session: The session cookie was not signed.
DEBUG - 2017-05-28 10:36:04 --> Session routines successfully run
DEBUG - 2017-05-28 10:36:04 --> Total execution time: 0.9110
DEBUG - 2017-05-28 21:51:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-28 21:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-28 21:51:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-28 21:51:58 --> Session Class Initialized
ERROR - 2017-05-28 21:51:58 --> Session: The session cookie was not signed.
DEBUG - 2017-05-28 21:51:58 --> Session routines successfully run
DEBUG - 2017-05-28 21:51:58 --> Total execution time: 0.4184

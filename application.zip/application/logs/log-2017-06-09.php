<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-09 04:24:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 04:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 04:24:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 04:24:46 --> Session Class Initialized
ERROR - 2017-06-09 04:24:46 --> Session: The session cookie was not signed.
DEBUG - 2017-06-09 04:24:46 --> Session routines successfully run
DEBUG - 2017-06-09 04:24:46 --> Total execution time: 0.8847
DEBUG - 2017-06-09 14:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:23:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:23:55 --> Session Class Initialized
ERROR - 2017-06-09 14:23:55 --> Session: The session cookie was not signed.
DEBUG - 2017-06-09 14:23:55 --> Session routines successfully run
DEBUG - 2017-06-09 14:23:55 --> Total execution time: 0.4731
DEBUG - 2017-06-09 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:26:06 --> Session Class Initialized
DEBUG - 2017-06-09 14:26:06 --> Session routines successfully run
DEBUG - 2017-06-09 14:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:26:06 --> Session Class Initialized
DEBUG - 2017-06-09 14:26:06 --> Session routines successfully run
DEBUG - 2017-06-09 14:26:06 --> Session Class Initialized
DEBUG - 2017-06-09 14:26:06 --> Session routines successfully run
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:24 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:24 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:24 --> User with name damilare just logged in
DEBUG - 2017-06-09 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:25 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:25 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:25 --> Total execution time: 0.4605
DEBUG - 2017-06-09 14:47:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:41 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:41 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:41 --> Total execution time: 0.1187
DEBUG - 2017-06-09 14:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:42 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:42 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:42 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:42 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:42 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:42 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:42 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:42 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:44 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:44 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:45 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:45 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:49 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:49 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:49 --> Total execution time: 0.1081
DEBUG - 2017-06-09 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:50 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:50 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:50 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:50 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:50 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:50 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:52 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:52 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:52 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:52 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:47:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:47:54 --> Session Class Initialized
DEBUG - 2017-06-09 14:47:54 --> Session routines successfully run
DEBUG - 2017-06-09 14:47:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:47:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:48:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:48:33 --> Session Class Initialized
DEBUG - 2017-06-09 14:48:33 --> Session routines successfully run
DEBUG - 2017-06-09 14:48:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:48:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:48:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:48:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:48:48 --> Session Class Initialized
DEBUG - 2017-06-09 14:48:48 --> Session routines successfully run
DEBUG - 2017-06-09 14:48:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:48:48 --> Total execution time: 0.1283
DEBUG - 2017-06-09 14:49:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:03 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:03 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:03 --> Total execution time: 0.0610
DEBUG - 2017-06-09 14:49:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:10 --> No URI present. Default controller set.
DEBUG - 2017-06-09 14:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:10 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:10 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:10 --> Total execution time: 0.0478
DEBUG - 2017-06-09 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:14 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:14 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:14 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:14 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:14 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:14 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:17 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:17 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:17 --> User with name damilare just logged in
DEBUG - 2017-06-09 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:18 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:18 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:18 --> Total execution time: 0.1617
DEBUG - 2017-06-09 14:49:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:23 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:23 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:23 --> Total execution time: 0.1767
DEBUG - 2017-06-09 14:49:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:31 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:31 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:31 --> Total execution time: 0.0783
DEBUG - 2017-06-09 14:49:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:32 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:32 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:32 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:32 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:49:32 --> Session Class Initialized
DEBUG - 2017-06-09 14:49:32 --> Session routines successfully run
DEBUG - 2017-06-09 14:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:58:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:58:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:58:52 --> Session Class Initialized
DEBUG - 2017-06-09 14:58:52 --> Session routines successfully run
DEBUG - 2017-06-09 14:58:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:58:53 --> Total execution time: 0.3061
DEBUG - 2017-06-09 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:58:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:58:53 --> Session Class Initialized
DEBUG - 2017-06-09 14:58:53 --> Session routines successfully run
DEBUG - 2017-06-09 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:58:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:58:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:58:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:58:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:58:54 --> Session Class Initialized
DEBUG - 2017-06-09 14:58:54 --> Session routines successfully run
DEBUG - 2017-06-09 14:58:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:58:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:58:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:58:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:58:54 --> Session Class Initialized
DEBUG - 2017-06-09 14:58:54 --> Session routines successfully run
DEBUG - 2017-06-09 14:58:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-09 14:58:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:59:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:59:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:59:03 --> Session Class Initialized
DEBUG - 2017-06-09 14:59:03 --> Session routines successfully run
DEBUG - 2017-06-09 14:59:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:59:03 --> Total execution time: 0.1177
DEBUG - 2017-06-09 14:59:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-09 14:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-09 14:59:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-09 14:59:15 --> Session Class Initialized
DEBUG - 2017-06-09 14:59:15 --> Session routines successfully run
DEBUG - 2017-06-09 14:59:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-09 14:59:15 --> Total execution time: 0.0813

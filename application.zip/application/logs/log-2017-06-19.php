<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-19 00:02:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:02:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:31 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:31 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:31 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-19 00:05:31 --> Severity: error --> Exception: Call to undefined method School_setup_model::get_pins() C:\xampp\htdocs\school_ms\application\controllers\Admin.php 116
DEBUG - 2017-06-19 00:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:47 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:47 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:48 --> Total execution time: 0.1056
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:48 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:48 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:48 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:48 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:48 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:49 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:49 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:49 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:49 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-19 00:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-19 00:05:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-19 00:05:56 --> Session Class Initialized
DEBUG - 2017-06-19 00:05:56 --> Session routines successfully run
DEBUG - 2017-06-19 00:05:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-19 00:05:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-19 00:05:56 --> Myapp class already loaded. Second attempt ignored.

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-11 12:17:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 12:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 12:17:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 12:17:37 --> Session Class Initialized
ERROR - 2017-06-11 12:17:37 --> Session: The session cookie was not signed.
DEBUG - 2017-06-11 12:17:37 --> Session routines successfully run
DEBUG - 2017-06-11 12:17:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 12:17:38 --> No URI present. Default controller set.
DEBUG - 2017-06-11 12:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 12:17:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 12:17:38 --> Session Class Initialized
DEBUG - 2017-06-11 12:17:38 --> Session routines successfully run
DEBUG - 2017-06-11 12:17:38 --> Total execution time: 0.0761
DEBUG - 2017-06-11 18:37:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 18:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 18:37:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 18:37:02 --> Session Class Initialized
ERROR - 2017-06-11 18:37:02 --> Session: The session cookie was not signed.
DEBUG - 2017-06-11 18:37:02 --> Session routines successfully run
DEBUG - 2017-06-11 18:37:03 --> Total execution time: 1.3570
DEBUG - 2017-06-11 18:38:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 18:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 18:38:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 18:38:07 --> Session Class Initialized
DEBUG - 2017-06-11 18:38:07 --> Session routines successfully run
DEBUG - 2017-06-11 18:38:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-11 18:38:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-11 18:38:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-11 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 18:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 18:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 18:38:08 --> Session Class Initialized
DEBUG - 2017-06-11 18:38:08 --> Session routines successfully run
DEBUG - 2017-06-11 18:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-11 18:38:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-11 18:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-11 18:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-11 18:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-11 18:38:08 --> Session Class Initialized
DEBUG - 2017-06-11 18:38:08 --> Session routines successfully run
DEBUG - 2017-06-11 18:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-11 18:38:08 --> Myapp class already loaded. Second attempt ignored.

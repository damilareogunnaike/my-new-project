<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-01 04:42:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:25 --> Session Class Initialized
ERROR - 2017-06-01 04:42:25 --> Session: The session cookie was not signed.
DEBUG - 2017-06-01 04:42:25 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:25 --> Total execution time: 1.2864
DEBUG - 2017-06-01 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:29 --> Session Class Initialized
DEBUG - 2017-06-01 04:42:29 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:42:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:42:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:29 --> Session Class Initialized
DEBUG - 2017-06-01 04:42:29 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:42:30 --> Session Class Initialized
DEBUG - 2017-06-01 04:42:30 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:42:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:44 --> Session Class Initialized
DEBUG - 2017-06-01 04:42:44 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:44 --> User with name admin just logged in
DEBUG - 2017-06-01 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:42:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:42:46 --> Session Class Initialized
DEBUG - 2017-06-01 04:42:46 --> Session routines successfully run
DEBUG - 2017-06-01 04:42:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:42:46 --> Total execution time: 0.4261
DEBUG - 2017-06-01 04:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:43:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:43:53 --> Session Class Initialized
DEBUG - 2017-06-01 04:43:53 --> Session routines successfully run
DEBUG - 2017-06-01 04:43:53 --> Total execution time: 0.0930
DEBUG - 2017-06-01 04:43:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:43:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:43:55 --> Session Class Initialized
DEBUG - 2017-06-01 04:43:55 --> Session routines successfully run
DEBUG - 2017-06-01 04:43:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:43:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:43:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:43:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:43:56 --> Session Class Initialized
DEBUG - 2017-06-01 04:43:56 --> Session routines successfully run
DEBUG - 2017-06-01 04:43:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:43:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:43:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:43:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:43:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:43:56 --> Session Class Initialized
DEBUG - 2017-06-01 04:43:56 --> Session routines successfully run
DEBUG - 2017-06-01 04:43:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:43:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:43:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:48:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:48:32 --> Session Class Initialized
DEBUG - 2017-06-01 04:48:32 --> Session routines successfully run
DEBUG - 2017-06-01 04:48:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:48:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:48:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 04:48:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 04:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 04:48:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 04:48:47 --> Session Class Initialized
DEBUG - 2017-06-01 04:48:47 --> Session routines successfully run
DEBUG - 2017-06-01 04:48:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 04:48:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:24 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:24 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:24 --> Total execution time: 0.4413
DEBUG - 2017-06-01 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:29 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:29 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 05:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:29 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:29 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 05:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:30 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:30 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 05:51:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:42 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:42 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:42 --> User with name admin just logged in
DEBUG - 2017-06-01 05:51:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:51:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:51:43 --> Session Class Initialized
DEBUG - 2017-06-01 05:51:43 --> Session routines successfully run
DEBUG - 2017-06-01 05:51:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:51:43 --> Total execution time: 0.2772
DEBUG - 2017-06-01 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:52:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:52:05 --> Session Class Initialized
DEBUG - 2017-06-01 05:52:05 --> Session routines successfully run
DEBUG - 2017-06-01 05:52:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:52:05 --> Total execution time: 0.0816
DEBUG - 2017-06-01 05:52:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:52:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:52:05 --> Session Class Initialized
DEBUG - 2017-06-01 05:52:05 --> Session routines successfully run
DEBUG - 2017-06-01 05:52:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:52:05 --> Total execution time: 0.0626
DEBUG - 2017-06-01 05:52:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:52:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:52:19 --> Session Class Initialized
DEBUG - 2017-06-01 05:52:19 --> Session routines successfully run
DEBUG - 2017-06-01 05:52:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:52:19 --> Total execution time: 0.1353
DEBUG - 2017-06-01 05:53:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:53:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:53:37 --> Session Class Initialized
DEBUG - 2017-06-01 05:53:37 --> Session routines successfully run
DEBUG - 2017-06-01 05:53:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:53:37 --> Total execution time: 0.1402
DEBUG - 2017-06-01 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 05:54:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 05:54:11 --> Session Class Initialized
DEBUG - 2017-06-01 05:54:11 --> Session routines successfully run
DEBUG - 2017-06-01 05:54:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 05:54:11 --> Total execution time: 0.0962
DEBUG - 2017-06-01 06:30:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:30:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:30:45 --> Session Class Initialized
DEBUG - 2017-06-01 06:30:45 --> Session routines successfully run
DEBUG - 2017-06-01 06:30:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:30:45 --> Total execution time: 0.1464
DEBUG - 2017-06-01 06:31:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:01 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:01 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:01 --> Total execution time: 0.3569
DEBUG - 2017-06-01 06:31:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:03 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:03 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:31:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:04 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:04 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:31:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:04 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:04 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:31:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:28 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:28 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:46 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:46 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:31:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:31:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:31:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:31:58 --> Session Class Initialized
DEBUG - 2017-06-01 06:31:58 --> Session routines successfully run
DEBUG - 2017-06-01 06:31:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-01 06:31:58 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-01 06:31:58 --> Total execution time: 0.1436
DEBUG - 2017-06-01 06:32:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:32:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:32:14 --> Session Class Initialized
DEBUG - 2017-06-01 06:32:14 --> Session routines successfully run
DEBUG - 2017-06-01 06:32:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-01 06:32:14 --> Total execution time: 0.1309
DEBUG - 2017-06-01 06:44:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:44:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:44:40 --> Session Class Initialized
DEBUG - 2017-06-01 06:44:40 --> Session routines successfully run
DEBUG - 2017-06-01 06:44:40 --> Total execution time: 0.1937
DEBUG - 2017-06-01 06:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-01 06:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-01 06:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-01 06:44:42 --> Session Class Initialized
DEBUG - 2017-06-01 06:44:42 --> Session routines successfully run
DEBUG - 2017-06-01 06:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-01 06:44:42 --> Myapp class already loaded. Second attempt ignored.

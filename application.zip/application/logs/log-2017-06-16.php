<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-16 00:56:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 00:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 00:56:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 00:56:21 --> Session Class Initialized
ERROR - 2017-06-16 00:56:21 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 00:56:21 --> Session routines successfully run
DEBUG - 2017-06-16 00:56:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 00:56:22 --> No URI present. Default controller set.
DEBUG - 2017-06-16 00:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 00:56:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 00:56:22 --> Session Class Initialized
DEBUG - 2017-06-16 00:56:22 --> Session routines successfully run
DEBUG - 2017-06-16 00:56:22 --> Total execution time: 0.1036
DEBUG - 2017-06-16 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:12 --> Session Class Initialized
ERROR - 2017-06-16 05:43:12 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 05:43:12 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:12 --> Total execution time: 0.5178
DEBUG - 2017-06-16 05:43:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:24 --> Session Class Initialized
ERROR - 2017-06-16 05:43:24 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 05:43:24 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:25 --> Session Class Initialized
ERROR - 2017-06-16 05:43:25 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 05:43:25 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:25 --> Session Class Initialized
ERROR - 2017-06-16 05:43:25 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 05:43:25 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:35 --> Session Class Initialized
ERROR - 2017-06-16 05:43:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 05:43:35 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:35 --> Total execution time: 0.0443
DEBUG - 2017-06-16 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:38 --> Session Class Initialized
DEBUG - 2017-06-16 05:43:38 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:38 --> Session Class Initialized
DEBUG - 2017-06-16 05:43:38 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:43:38 --> Session Class Initialized
DEBUG - 2017-06-16 05:43:38 --> Session routines successfully run
DEBUG - 2017-06-16 05:43:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:43:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:44:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:44:41 --> Session Class Initialized
DEBUG - 2017-06-16 05:44:41 --> Session routines successfully run
DEBUG - 2017-06-16 05:44:41 --> User with name admin just logged in
DEBUG - 2017-06-16 05:44:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:44:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:44:42 --> Session Class Initialized
DEBUG - 2017-06-16 05:44:42 --> Session routines successfully run
DEBUG - 2017-06-16 05:44:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:44:42 --> Total execution time: 0.3242
DEBUG - 2017-06-16 05:45:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:04 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:04 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:04 --> Total execution time: 0.2730
DEBUG - 2017-06-16 05:45:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:05 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:05 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:06 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:06 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:06 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:06 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:06 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:06 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:07 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:07 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:07 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:07 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:08 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:08 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:08 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:08 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:10 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:10 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:26 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:26 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:45:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:45:43 --> Session Class Initialized
DEBUG - 2017-06-16 05:45:43 --> Session routines successfully run
DEBUG - 2017-06-16 05:45:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:45:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:51:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:51:04 --> Session Class Initialized
DEBUG - 2017-06-16 05:51:04 --> Session routines successfully run
DEBUG - 2017-06-16 05:51:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:51:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:51:22 --> Session Class Initialized
DEBUG - 2017-06-16 05:51:22 --> Session routines successfully run
DEBUG - 2017-06-16 05:51:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:51:22 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 05:51:38 --> Query error: Duplicate entry '4-4-996-25-54' for key 'stud_record_constr' - Invalid query: INSERT INTO `results` (`ca1`, `ca2`, `class_id`, `exam`, `session_id`, `student_id`, `subject_id`, `term_id`) VALUES (0,0,'25',68,'4','996','54','4'), (0,0,'25',67,'4','263','54','4'), (0,0,'25',42,'4','1000','54','4'), (0,0,'25',34,'4','242','54','4'), (0,0,'25',75,'4','245','54','4'), (0,0,'25',46,'4','240','54','4'), (0,0,'25',50,'4','259','54','4'), (0,0,'25',86,'4','264','54','4'), (0,0,'25',72,'4','997','54','4'), (0,0,'25',84,'4','260','54','4'), (0,0,'25',75,'4','262','54','4'), (0,0,'25',0,'4','941','54','4'), (0,0,'25',65,'4','256','54','4'), (0,0,'25',67,'4','998','54','4'), (0,0,'25',87,'4','255','54','4'), (0,0,'25',50,'4','265','54','4'), (0,0,'25',63,'4','243','54','4'), (0,0,'25',76,'4','247','54','4'), (0,0,'25',81,'4','266','54','4'), (0,0,'25',50,'4','983','54','4'), (0,0,'25',36,'4','269','54','4'), (0,0,'25',65,'4','267','54','4'), (0,0,'25',73,'4','258','54','4'), (0,0,'25',66,'4','248','54','4'), (0,0,'25',34,'4','237','54','4'), (0,0,'25',69,'4','249','54','4'), (0,0,'25',63,'4','250','54','4'), (0,0,'25',66,'4','423','54','4'), (0,0,'25',69,'4','244','54','4'), (0,0,'25',75,'4','456','54','4'), (0,0,'25',60,'4','261','54','4'), (0,0,'25',57,'4','271','54','4'), (0,0,'25',63,'4','369','54','4'), (0,0,'25',78,'4','270','54','4'), (0,0,'25',66,'4','947','54','4'), (0,0,'25',61,'4','241','54','4'), (0,0,'25',51,'4','1290','54','4')
DEBUG - 2017-06-16 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:53:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:53:19 --> Session Class Initialized
DEBUG - 2017-06-16 05:53:19 --> Session routines successfully run
DEBUG - 2017-06-16 05:53:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:53:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:53:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:53:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:53:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:53:26 --> Session Class Initialized
DEBUG - 2017-06-16 05:53:26 --> Session routines successfully run
DEBUG - 2017-06-16 05:53:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:53:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:53:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:53:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:53:55 --> Session Class Initialized
DEBUG - 2017-06-16 05:53:55 --> Session routines successfully run
DEBUG - 2017-06-16 05:53:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:53:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:53:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:53:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:53:57 --> Session Class Initialized
DEBUG - 2017-06-16 05:53:57 --> Session routines successfully run
DEBUG - 2017-06-16 05:53:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:53:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:55:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:55:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:55:12 --> Session Class Initialized
DEBUG - 2017-06-16 05:55:12 --> Session routines successfully run
DEBUG - 2017-06-16 05:55:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:55:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 05:58:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 05:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 05:58:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 05:58:56 --> Session Class Initialized
DEBUG - 2017-06-16 05:58:56 --> Session routines successfully run
DEBUG - 2017-06-16 05:58:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 05:58:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:02:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:02:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:02:36 --> Session Class Initialized
DEBUG - 2017-06-16 06:02:36 --> Session routines successfully run
DEBUG - 2017-06-16 06:02:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:02:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:02:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:03:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:03:06 --> Session Class Initialized
DEBUG - 2017-06-16 06:03:06 --> Session routines successfully run
DEBUG - 2017-06-16 06:03:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:03:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:01 --> Session Class Initialized
ERROR - 2017-06-16 06:04:01 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 06:04:01 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:01 --> Total execution time: 0.0738
DEBUG - 2017-06-16 06:04:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:03 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:03 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:06 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:06 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:04:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:06 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:06 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:04:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:15 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:15 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:15 --> User with name admin just logged in
DEBUG - 2017-06-16 06:04:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:16 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:16 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:17 --> Total execution time: 0.4092
DEBUG - 2017-06-16 06:04:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:43 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:43 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:43 --> Total execution time: 0.0959
DEBUG - 2017-06-16 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:45 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:45 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:04:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:45 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:45 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:04:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:04:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:04:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:04:56 --> Session Class Initialized
DEBUG - 2017-06-16 06:04:56 --> Session routines successfully run
DEBUG - 2017-06-16 06:04:56 --> Total execution time: 0.0495
DEBUG - 2017-06-16 06:05:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:08 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:08 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:09 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:09 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:10 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:10 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:11 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:11 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:13 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:13 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:14 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:14 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:05:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:05:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:05:16 --> Session Class Initialized
DEBUG - 2017-06-16 06:05:16 --> Session routines successfully run
DEBUG - 2017-06-16 06:05:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:05:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:06:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:06:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:06:42 --> Session Class Initialized
DEBUG - 2017-06-16 06:06:42 --> Session routines successfully run
DEBUG - 2017-06-16 06:06:42 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 06:06:43 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-16 06:06:43 --> Total execution time: 0.0976
DEBUG - 2017-06-16 06:07:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:07:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:07:06 --> Session Class Initialized
DEBUG - 2017-06-16 06:07:06 --> Session routines successfully run
DEBUG - 2017-06-16 06:07:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:07:06 --> Total execution time: 0.1004
DEBUG - 2017-06-16 06:07:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:07:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:07:13 --> Session Class Initialized
DEBUG - 2017-06-16 06:07:13 --> Session routines successfully run
DEBUG - 2017-06-16 06:07:13 --> Total execution time: 0.4665
DEBUG - 2017-06-16 06:09:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:09:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:09:22 --> Session Class Initialized
DEBUG - 2017-06-16 06:09:22 --> Session routines successfully run
DEBUG - 2017-06-16 06:09:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:09:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:10:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:10:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:10:43 --> Session Class Initialized
DEBUG - 2017-06-16 06:10:43 --> Session routines successfully run
DEBUG - 2017-06-16 06:10:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:10:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:10:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:10:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:10:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:10:51 --> Session Class Initialized
DEBUG - 2017-06-16 06:10:51 --> Session routines successfully run
DEBUG - 2017-06-16 06:10:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:10:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:14:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:14:37 --> Session Class Initialized
DEBUG - 2017-06-16 06:14:37 --> Session routines successfully run
DEBUG - 2017-06-16 06:14:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:14:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:17:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:17:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:17:57 --> Session Class Initialized
DEBUG - 2017-06-16 06:17:57 --> Session routines successfully run
DEBUG - 2017-06-16 06:17:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:17:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:17:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:18:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:18:07 --> Session Class Initialized
DEBUG - 2017-06-16 06:18:07 --> Session routines successfully run
DEBUG - 2017-06-16 06:18:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:18:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:22:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:22:01 --> Session Class Initialized
DEBUG - 2017-06-16 06:22:01 --> Session routines successfully run
DEBUG - 2017-06-16 06:22:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:22:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:22:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:22:50 --> Session Class Initialized
DEBUG - 2017-06-16 06:22:50 --> Session routines successfully run
DEBUG - 2017-06-16 06:22:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:22:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:22:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:25:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:25:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:25:42 --> Session Class Initialized
DEBUG - 2017-06-16 06:25:42 --> Session routines successfully run
DEBUG - 2017-06-16 06:25:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:25:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:28:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:28:26 --> Session Class Initialized
DEBUG - 2017-06-16 06:28:26 --> Session routines successfully run
DEBUG - 2017-06-16 06:28:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:28:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:37 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:37 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:37 --> Total execution time: 0.2295
DEBUG - 2017-06-16 06:30:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:38 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:38 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:39 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:39 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:39 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:39 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:39 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:39 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:40 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:40 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:40 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:40 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:40 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:40 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:41 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:41 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:41 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:41 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 06:30:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 06:30:42 --> Session Class Initialized
DEBUG - 2017-06-16 06:30:42 --> Session routines successfully run
DEBUG - 2017-06-16 06:30:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 06:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 06:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:28 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:28 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:29 --> Total execution time: 0.2968
DEBUG - 2017-06-16 07:06:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:30 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:30 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:31 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:31 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:31 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:31 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:31 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:31 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:31 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:06:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:06:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:06:32 --> Session Class Initialized
DEBUG - 2017-06-16 07:06:32 --> Session routines successfully run
DEBUG - 2017-06-16 07:06:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:06:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:07:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:07:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:07:52 --> Session Class Initialized
DEBUG - 2017-06-16 07:07:52 --> Session routines successfully run
DEBUG - 2017-06-16 07:07:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:07:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:07:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:11 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:11 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:11 --> Total execution time: 0.1068
DEBUG - 2017-06-16 07:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:12 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:12 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:13 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:13 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:13 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:13 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:13 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:13 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:13 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:13 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:14 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:14 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:14 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:14 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:14 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:14 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:15 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:15 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:15 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:15 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:34 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:34 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:08:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:08:47 --> Session Class Initialized
DEBUG - 2017-06-16 07:08:47 --> Session routines successfully run
DEBUG - 2017-06-16 07:08:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:16:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:16:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:16:14 --> Session Class Initialized
DEBUG - 2017-06-16 07:16:14 --> Session routines successfully run
DEBUG - 2017-06-16 07:16:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:16:15 --> Total execution time: 0.4173
DEBUG - 2017-06-16 07:23:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:23:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:23:37 --> Session Class Initialized
DEBUG - 2017-06-16 07:23:37 --> Session routines successfully run
DEBUG - 2017-06-16 07:23:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:23:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:24:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:24:44 --> Session Class Initialized
DEBUG - 2017-06-16 07:24:44 --> Session routines successfully run
DEBUG - 2017-06-16 07:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:24:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:24:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:24:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:24:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:24:54 --> Session Class Initialized
DEBUG - 2017-06-16 07:24:54 --> Session routines successfully run
DEBUG - 2017-06-16 07:24:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:24:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:27:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:27:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:27:20 --> Session Class Initialized
DEBUG - 2017-06-16 07:27:20 --> Session routines successfully run
DEBUG - 2017-06-16 07:27:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:27:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:28:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:28:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:28:15 --> Session Class Initialized
DEBUG - 2017-06-16 07:28:15 --> Session routines successfully run
DEBUG - 2017-06-16 07:28:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:28:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:28:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:28:25 --> Session Class Initialized
DEBUG - 2017-06-16 07:28:25 --> Session routines successfully run
DEBUG - 2017-06-16 07:28:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:28:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:36:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:36:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:36:59 --> Session Class Initialized
DEBUG - 2017-06-16 07:36:59 --> Session routines successfully run
DEBUG - 2017-06-16 07:36:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:36:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:37:55 --> Session Class Initialized
DEBUG - 2017-06-16 07:37:55 --> Session routines successfully run
DEBUG - 2017-06-16 07:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:38:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:38:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:38:03 --> Session Class Initialized
DEBUG - 2017-06-16 07:38:03 --> Session routines successfully run
DEBUG - 2017-06-16 07:38:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:38:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 07:41:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 07:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 07:41:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 07:41:05 --> Session Class Initialized
DEBUG - 2017-06-16 07:41:05 --> Session routines successfully run
DEBUG - 2017-06-16 07:41:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 07:41:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:15:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:15:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:15:14 --> Session Class Initialized
DEBUG - 2017-06-16 08:15:14 --> Session routines successfully run
DEBUG - 2017-06-16 08:15:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:15:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:15:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:15:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:15:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:15:35 --> Session Class Initialized
DEBUG - 2017-06-16 08:15:35 --> Session routines successfully run
DEBUG - 2017-06-16 08:15:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:15:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:20:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:20:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:20:21 --> Session Class Initialized
DEBUG - 2017-06-16 08:20:21 --> Session routines successfully run
DEBUG - 2017-06-16 08:20:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:20:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:21:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:21:07 --> Session Class Initialized
DEBUG - 2017-06-16 08:21:07 --> Session routines successfully run
DEBUG - 2017-06-16 08:21:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:21:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:21:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:21:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:21:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:21:20 --> Session Class Initialized
DEBUG - 2017-06-16 08:21:20 --> Session routines successfully run
DEBUG - 2017-06-16 08:21:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:21:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:24:26 --> Session Class Initialized
DEBUG - 2017-06-16 08:24:26 --> Session routines successfully run
DEBUG - 2017-06-16 08:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:43:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:43:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:43:08 --> Session Class Initialized
ERROR - 2017-06-16 08:43:08 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 08:43:08 --> Session routines successfully run
DEBUG - 2017-06-16 08:43:08 --> Total execution time: 0.1732
DEBUG - 2017-06-16 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:43:40 --> Session Class Initialized
DEBUG - 2017-06-16 08:43:40 --> Session routines successfully run
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:43:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:43:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:43:40 --> Session Class Initialized
DEBUG - 2017-06-16 08:43:40 --> Session routines successfully run
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:43:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:43:40 --> Session Class Initialized
DEBUG - 2017-06-16 08:43:40 --> Session routines successfully run
DEBUG - 2017-06-16 08:43:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 08:43:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:44:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:44:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:44:20 --> Session Class Initialized
DEBUG - 2017-06-16 08:44:20 --> Session routines successfully run
DEBUG - 2017-06-16 08:44:20 --> User with name admin just logged in
DEBUG - 2017-06-16 08:44:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:44:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:44:21 --> Session Class Initialized
DEBUG - 2017-06-16 08:44:21 --> Session routines successfully run
DEBUG - 2017-06-16 08:44:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 08:44:21 --> Total execution time: 0.3988
DEBUG - 2017-06-16 08:44:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 08:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 08:44:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 08:44:29 --> Session Class Initialized
DEBUG - 2017-06-16 08:44:29 --> Session routines successfully run
DEBUG - 2017-06-16 08:44:29 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 08:44:29 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-16 08:44:29 --> Total execution time: 0.1937
DEBUG - 2017-06-16 09:06:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:06:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:06:47 --> Session Class Initialized
DEBUG - 2017-06-16 09:06:47 --> Session routines successfully run
DEBUG - 2017-06-16 09:06:48 --> Total execution time: 0.3342
DEBUG - 2017-06-16 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:07:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:07:35 --> Session Class Initialized
DEBUG - 2017-06-16 09:07:35 --> Session routines successfully run
DEBUG - 2017-06-16 09:07:35 --> Total execution time: 0.1114
DEBUG - 2017-06-16 09:07:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:07:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:07:55 --> Session Class Initialized
DEBUG - 2017-06-16 09:07:55 --> Session routines successfully run
DEBUG - 2017-06-16 09:07:55 --> Total execution time: 0.0470
DEBUG - 2017-06-16 09:29:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:29:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:29:10 --> Session Class Initialized
DEBUG - 2017-06-16 09:29:10 --> Session routines successfully run
DEBUG - 2017-06-16 09:29:10 --> Total execution time: 0.2722
DEBUG - 2017-06-16 09:29:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:29:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:29:36 --> Session Class Initialized
DEBUG - 2017-06-16 09:29:36 --> Session routines successfully run
DEBUG - 2017-06-16 09:29:36 --> Total execution time: 0.0895
DEBUG - 2017-06-16 09:29:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:29:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:29:54 --> Session Class Initialized
DEBUG - 2017-06-16 09:29:54 --> Session routines successfully run
DEBUG - 2017-06-16 09:29:54 --> Total execution time: 0.0505
DEBUG - 2017-06-16 09:30:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:30:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:30:16 --> Session Class Initialized
DEBUG - 2017-06-16 09:30:16 --> Session routines successfully run
DEBUG - 2017-06-16 09:30:16 --> Total execution time: 0.0818
DEBUG - 2017-06-16 09:30:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:30:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:30:52 --> Session Class Initialized
DEBUG - 2017-06-16 09:30:52 --> Session routines successfully run
DEBUG - 2017-06-16 09:30:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:30:53 --> Total execution time: 0.5067
DEBUG - 2017-06-16 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:35:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:35:47 --> Session Class Initialized
DEBUG - 2017-06-16 09:35:47 --> Session routines successfully run
DEBUG - 2017-06-16 09:35:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:35:47 --> Total execution time: 0.1420
DEBUG - 2017-06-16 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:38:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:38:13 --> Session Class Initialized
DEBUG - 2017-06-16 09:38:13 --> Session routines successfully run
DEBUG - 2017-06-16 09:38:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:38:13 --> Total execution time: 0.1971
DEBUG - 2017-06-16 09:39:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:39:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:39:07 --> Session Class Initialized
DEBUG - 2017-06-16 09:39:07 --> Session routines successfully run
DEBUG - 2017-06-16 09:39:07 --> Total execution time: 0.9036
DEBUG - 2017-06-16 09:57:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:57:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:57:35 --> Session Class Initialized
ERROR - 2017-06-16 09:57:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 09:57:35 --> Session routines successfully run
DEBUG - 2017-06-16 09:57:35 --> Total execution time: 0.3488
DEBUG - 2017-06-16 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:57:38 --> Session Class Initialized
DEBUG - 2017-06-16 09:57:38 --> Session routines successfully run
DEBUG - 2017-06-16 09:57:38 --> Session Class Initialized
DEBUG - 2017-06-16 09:57:38 --> Session routines successfully run
DEBUG - 2017-06-16 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:57:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:57:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:57:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:57:38 --> Session Class Initialized
DEBUG - 2017-06-16 09:57:38 --> Session routines successfully run
DEBUG - 2017-06-16 09:57:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 09:57:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:59:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:59:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:59:00 --> Session Class Initialized
DEBUG - 2017-06-16 09:59:00 --> Session routines successfully run
DEBUG - 2017-06-16 09:59:00 --> User with name admin just logged in
DEBUG - 2017-06-16 09:59:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 09:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 09:59:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 09:59:01 --> Session Class Initialized
DEBUG - 2017-06-16 09:59:01 --> Session routines successfully run
DEBUG - 2017-06-16 09:59:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 09:59:01 --> Total execution time: 0.2511
DEBUG - 2017-06-16 10:25:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 10:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 10:25:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 10:25:24 --> Session Class Initialized
DEBUG - 2017-06-16 10:25:24 --> Session routines successfully run
DEBUG - 2017-06-16 10:25:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 10:25:24 --> Total execution time: 0.8722
DEBUG - 2017-06-16 10:41:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 10:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 10:41:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 10:41:25 --> Session Class Initialized
DEBUG - 2017-06-16 10:41:25 --> Session routines successfully run
DEBUG - 2017-06-16 10:41:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 10:41:26 --> Total execution time: 0.2348
DEBUG - 2017-06-16 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 10:56:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 10:56:37 --> Session Class Initialized
DEBUG - 2017-06-16 10:56:37 --> Session routines successfully run
DEBUG - 2017-06-16 10:56:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 10:56:38 --> Total execution time: 0.1709
DEBUG - 2017-06-16 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 10:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 10:58:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 10:58:26 --> Session Class Initialized
DEBUG - 2017-06-16 10:58:26 --> Session routines successfully run
DEBUG - 2017-06-16 10:58:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 10:58:26 --> Total execution time: 0.2076
DEBUG - 2017-06-16 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 10:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 10:59:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 10:59:48 --> Session Class Initialized
DEBUG - 2017-06-16 10:59:48 --> Session routines successfully run
DEBUG - 2017-06-16 10:59:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 10:59:48 --> Total execution time: 0.0922
DEBUG - 2017-06-16 11:03:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:03:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:03:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:03:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:03:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:03:39 --> Total execution time: 0.1747
DEBUG - 2017-06-16 11:04:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:04:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:04:32 --> Session Class Initialized
DEBUG - 2017-06-16 11:04:32 --> Session routines successfully run
DEBUG - 2017-06-16 11:04:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:04:32 --> Total execution time: 0.1161
DEBUG - 2017-06-16 11:05:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:05:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:05:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:05:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:05:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:05:22 --> Total execution time: 0.0937
DEBUG - 2017-06-16 11:06:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:06:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:06:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:06:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:06:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:06:19 --> Total execution time: 0.0979
DEBUG - 2017-06-16 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:11:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:11:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:11:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:11:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:11:46 --> Total execution time: 0.4076
DEBUG - 2017-06-16 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:13:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:13:24 --> Session Class Initialized
DEBUG - 2017-06-16 11:13:24 --> Session routines successfully run
DEBUG - 2017-06-16 11:13:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:13:24 --> Total execution time: 0.2104
DEBUG - 2017-06-16 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:13:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:13:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:13:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:13:53 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 11:13:53 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-16 11:13:54 --> Total execution time: 0.1953
DEBUG - 2017-06-16 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:14:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:14:26 --> Session Class Initialized
DEBUG - 2017-06-16 11:14:26 --> Session routines successfully run
DEBUG - 2017-06-16 11:14:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:14:26 --> Total execution time: 0.1599
DEBUG - 2017-06-16 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:14:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:14:42 --> Session Class Initialized
DEBUG - 2017-06-16 11:14:42 --> Session routines successfully run
DEBUG - 2017-06-16 11:14:42 --> Total execution time: 0.5367
DEBUG - 2017-06-16 11:16:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:25 --> Total execution time: 0.4774
DEBUG - 2017-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:16:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:16:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:16:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:16:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:16:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:16:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:06 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:06 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:17:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:17:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:17:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:17:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:17:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:17:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:18:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:18:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:18:24 --> Session Class Initialized
DEBUG - 2017-06-16 11:18:24 --> Session routines successfully run
DEBUG - 2017-06-16 11:18:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:18:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:35 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:35 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:36 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:36 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:19:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:19:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:19:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:19:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:19:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:19:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:20:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:20:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:20:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:20:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:20:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:06 --> Total execution time: 0.1037
DEBUG - 2017-06-16 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:42 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:42 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:42 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:42 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:43 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:43 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:44 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:22:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:22:59 --> Session Class Initialized
DEBUG - 2017-06-16 11:22:59 --> Session routines successfully run
DEBUG - 2017-06-16 11:22:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:22:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:00 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:00 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:40 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:40 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:51 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:51 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:52 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:52 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:54 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:54 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:23:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:23:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:23:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:02 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:02 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:03 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:03 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:08 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:08 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:08 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:08 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:23 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:23 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:26 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:26 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:26 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:26 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:29 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:29 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:30 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:30 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:44 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:44 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:24:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:24:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:24:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:24:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:24:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:24:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:25:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:25:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:25:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:25:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:25:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:25:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:25:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:25:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:25:02 --> Session Class Initialized
DEBUG - 2017-06-16 11:25:02 --> Session routines successfully run
DEBUG - 2017-06-16 11:25:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:25:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:25:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:25:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:25:03 --> Session Class Initialized
DEBUG - 2017-06-16 11:25:03 --> Session routines successfully run
DEBUG - 2017-06-16 11:25:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:25:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:25:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:25:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:25:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:25:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:25:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:25:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:25:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:25:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:25:04 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 11:25:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')' at line 6 - Invalid query: SELECT *
FROM `student_result_overview`
WHERE `session_id` = '4'
AND `term_id` = '2'
AND `class_id` = '16'
AND student_id IN()
DEBUG - 2017-06-16 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:26:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:26:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:26:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:26:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:26:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:26:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:18 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:18 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:23 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:23 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:51 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:51 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:55 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:55 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:28:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:28:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:28:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:28:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:16 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:16 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:30 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:30 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:31 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:31 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:32 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:32 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:35 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:37 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:37 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:38 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:38 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:43 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:43 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:51 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:51 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:52 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:52 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:52 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:52 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:29:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:29:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:29:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:29:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:29:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:15 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:15 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:17 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:17 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:17 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:17 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:30 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:30 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:32 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:32 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:34 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:34 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:35 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:40 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:40 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:30:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:30:41 --> Session Class Initialized
DEBUG - 2017-06-16 11:30:41 --> Session routines successfully run
DEBUG - 2017-06-16 11:30:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:30:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:32:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:32:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:32:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:32:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:32:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:32:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:32:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:32:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:32:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:32:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:32:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:32:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:32:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:32:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:32:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:32:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:32:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:32:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:32:31 --> Session Class Initialized
DEBUG - 2017-06-16 11:32:31 --> Session routines successfully run
DEBUG - 2017-06-16 11:32:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:32:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:32:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:32:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:32:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:32:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:32:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:32:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:06 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:06 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:38 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:38 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:42 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:42 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:43 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:43 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:33:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:33:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:33:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:33:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:33:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:19 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:19 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:43 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:43 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:34:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:34:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:34:52 --> Session Class Initialized
DEBUG - 2017-06-16 11:34:52 --> Session routines successfully run
DEBUG - 2017-06-16 11:34:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:34:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:46 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:46 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:35:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:35:54 --> Session Class Initialized
DEBUG - 2017-06-16 11:35:54 --> Session routines successfully run
DEBUG - 2017-06-16 11:35:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:35:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:24 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:24 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:26 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:26 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:29 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:29 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:29 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:29 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:30 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:30 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:31 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:31 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:36:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:36:49 --> Session Class Initialized
DEBUG - 2017-06-16 11:36:49 --> Session routines successfully run
DEBUG - 2017-06-16 11:36:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:36:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:30 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:30 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:48 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:48 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:37:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:37:55 --> Session Class Initialized
DEBUG - 2017-06-16 11:37:55 --> Session routines successfully run
DEBUG - 2017-06-16 11:37:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:37:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:08 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:08 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:38:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:38:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:38:34 --> Session Class Initialized
DEBUG - 2017-06-16 11:38:34 --> Session routines successfully run
DEBUG - 2017-06-16 11:38:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:38:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:39:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:39:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:39:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:39:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:39:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:39:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:39:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:02 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:02 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:03 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:03 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:16 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:16 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:18 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:18 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:32 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:32 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:40:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:40:47 --> Session Class Initialized
DEBUG - 2017-06-16 11:40:47 --> Session routines successfully run
DEBUG - 2017-06-16 11:40:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:40:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:42:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:42:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:42:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:42:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:42:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:45:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:45:40 --> Session Class Initialized
DEBUG - 2017-06-16 11:45:40 --> Session routines successfully run
DEBUG - 2017-06-16 11:45:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:45:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:07 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:14 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:14 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:23 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:23 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:24 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:24 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:28 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:28 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:46:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:46:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:46:57 --> Session Class Initialized
DEBUG - 2017-06-16 11:46:57 --> Session routines successfully run
DEBUG - 2017-06-16 11:46:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:46:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:25 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:25 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:37 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:37 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:38 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:38 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:40 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:40 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:42 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:42 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:44 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:57 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:57 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:57 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:57 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:47:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:47:58 --> Session Class Initialized
DEBUG - 2017-06-16 11:47:58 --> Session routines successfully run
DEBUG - 2017-06-16 11:47:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:47:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:48:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:48:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:48:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:48:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:48:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:48:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:48:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:48:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:48:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:48:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:48:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:48:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:48:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:48:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:48:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:48:18 --> Session Class Initialized
DEBUG - 2017-06-16 11:48:18 --> Session routines successfully run
DEBUG - 2017-06-16 11:48:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:48:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:07 --> Session Class Initialized
ERROR - 2017-06-16 11:49:07 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 11:49:07 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:12 --> No URI present. Default controller set.
DEBUG - 2017-06-16 11:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:12 --> Total execution time: 0.0911
DEBUG - 2017-06-16 11:49:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:33 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:39 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:39 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:52 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:52 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:49:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:49:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:49:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:00 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:00 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:01 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:01 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:04 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:04 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:16 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:16 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:17 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:17 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:17 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:17 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:18 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:18 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:50:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:50:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:50:23 --> Session Class Initialized
DEBUG - 2017-06-16 11:50:23 --> Session routines successfully run
DEBUG - 2017-06-16 11:50:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:50:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:09 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:09 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:10 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:10 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:11 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:11 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:31 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:31 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:31 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:31 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:51:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:51:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:51:32 --> Session Class Initialized
DEBUG - 2017-06-16 11:51:32 --> Session routines successfully run
DEBUG - 2017-06-16 11:51:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:51:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:43 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:43 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:54 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:54 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:55 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:55 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:55 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:55 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:52:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:52:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:52:59 --> Session Class Initialized
DEBUG - 2017-06-16 11:52:59 --> Session routines successfully run
DEBUG - 2017-06-16 11:52:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:52:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:53:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:53:00 --> Session Class Initialized
DEBUG - 2017-06-16 11:53:00 --> Session routines successfully run
DEBUG - 2017-06-16 11:53:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:53:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:53:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:53:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:53:00 --> Session Class Initialized
DEBUG - 2017-06-16 11:53:00 --> Session routines successfully run
DEBUG - 2017-06-16 11:53:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:53:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:53:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:53:20 --> Session Class Initialized
DEBUG - 2017-06-16 11:53:20 --> Session routines successfully run
DEBUG - 2017-06-16 11:53:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:53:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:54:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:54:45 --> Session Class Initialized
DEBUG - 2017-06-16 11:54:45 --> Session routines successfully run
DEBUG - 2017-06-16 11:54:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:54:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:55:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:55:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:55:50 --> Session Class Initialized
DEBUG - 2017-06-16 11:55:50 --> Session routines successfully run
DEBUG - 2017-06-16 11:55:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:55:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:55:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:55:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:55:56 --> Session Class Initialized
DEBUG - 2017-06-16 11:55:56 --> Session routines successfully run
DEBUG - 2017-06-16 11:55:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:55:56 --> Total execution time: 0.1052
DEBUG - 2017-06-16 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:56:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:56:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:56:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:56:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:56:27 --> Total execution time: 0.1036
DEBUG - 2017-06-16 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:56:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:56:36 --> Session Class Initialized
DEBUG - 2017-06-16 11:56:36 --> Session routines successfully run
DEBUG - 2017-06-16 11:56:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:56:36 --> Total execution time: 0.0807
DEBUG - 2017-06-16 11:56:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:56:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:56:53 --> Session Class Initialized
DEBUG - 2017-06-16 11:56:53 --> Session routines successfully run
DEBUG - 2017-06-16 11:56:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:56:54 --> Total execution time: 0.0836
DEBUG - 2017-06-16 11:57:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:05 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:05 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:05 --> Total execution time: 0.1288
DEBUG - 2017-06-16 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:13 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:13 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:21 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:21 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:26 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:26 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:29 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:29 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:57:29 --> Total execution time: 0.0743
DEBUG - 2017-06-16 11:57:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:57:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:57:37 --> Session Class Initialized
DEBUG - 2017-06-16 11:57:37 --> Session routines successfully run
DEBUG - 2017-06-16 11:57:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:57:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:58:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:58:12 --> Session Class Initialized
DEBUG - 2017-06-16 11:58:12 --> Session routines successfully run
DEBUG - 2017-06-16 11:58:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:58:12 --> Total execution time: 0.0652
DEBUG - 2017-06-16 11:58:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:58:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:58:22 --> Session Class Initialized
DEBUG - 2017-06-16 11:58:22 --> Session routines successfully run
DEBUG - 2017-06-16 11:58:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:58:22 --> Total execution time: 0.1159
DEBUG - 2017-06-16 11:58:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:58:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:58:27 --> Session Class Initialized
DEBUG - 2017-06-16 11:58:27 --> Session routines successfully run
DEBUG - 2017-06-16 11:58:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:58:27 --> Total execution time: 0.1046
DEBUG - 2017-06-16 11:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:59:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:59:33 --> Session Class Initialized
ERROR - 2017-06-16 11:59:33 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 11:59:33 --> Session routines successfully run
DEBUG - 2017-06-16 11:59:33 --> Total execution time: 0.0425
DEBUG - 2017-06-16 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:59:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:59:35 --> Session Class Initialized
ERROR - 2017-06-16 11:59:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 11:59:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:59:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:59:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:59:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:59:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:59:35 --> Session Class Initialized
ERROR - 2017-06-16 11:59:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 11:59:35 --> Session routines successfully run
DEBUG - 2017-06-16 11:59:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 11:59:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:59:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:59:44 --> Session Class Initialized
ERROR - 2017-06-16 11:59:44 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 11:59:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:59:44 --> User with name admin just logged in
DEBUG - 2017-06-16 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 11:59:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 11:59:44 --> Session Class Initialized
DEBUG - 2017-06-16 11:59:44 --> Session routines successfully run
DEBUG - 2017-06-16 11:59:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 11:59:44 --> Total execution time: 0.1197
DEBUG - 2017-06-16 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:06 --> Total execution time: 0.2038
DEBUG - 2017-06-16 12:00:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:06 --> Total execution time: 0.3584
DEBUG - 2017-06-16 12:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:00:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:00:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:00:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:00:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:02:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:02:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:02:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:02:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:02:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:02:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:02:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:02:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:02:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:02:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:02:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:02:19 --> Total execution time: 0.2758
DEBUG - 2017-06-16 12:02:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:02:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:02:52 --> Session Class Initialized
DEBUG - 2017-06-16 12:02:52 --> Session routines successfully run
DEBUG - 2017-06-16 12:02:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:02:52 --> Total execution time: 0.0810
DEBUG - 2017-06-16 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:10 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:10 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:11 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:11 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:11 --> Total execution time: 0.1275
DEBUG - 2017-06-16 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:36 --> Total execution time: 0.1044
DEBUG - 2017-06-16 12:03:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:45 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:45 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:45 --> Total execution time: 0.1190
DEBUG - 2017-06-16 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:47 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:47 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:47 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:47 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:47 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:47 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:47 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:47 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:03:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:03:48 --> Session Class Initialized
DEBUG - 2017-06-16 12:03:48 --> Session routines successfully run
DEBUG - 2017-06-16 12:03:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:03:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:03:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:04:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:04:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:04:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:04:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:04:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:04:02 --> Total execution time: 0.2841
DEBUG - 2017-06-16 12:04:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:04:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:04:33 --> Session Class Initialized
DEBUG - 2017-06-16 12:04:33 --> Session routines successfully run
DEBUG - 2017-06-16 12:04:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:04:33 --> Total execution time: 0.0774
DEBUG - 2017-06-16 12:05:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:05:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:05:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:05:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:05:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:05:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:05:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:05:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:05:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:05:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:05:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:05:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:05:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:05:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:05:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:05:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:05:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:05:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:05:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:05:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:05:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:05:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:05:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:05:54 --> Total execution time: 0.1639
DEBUG - 2017-06-16 12:06:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:06:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:06:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:06:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:06:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:06:03 --> Total execution time: 0.0598
DEBUG - 2017-06-16 12:06:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:06:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:06:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:06:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:06:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:06:24 --> Total execution time: 0.0782
DEBUG - 2017-06-16 12:06:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:06:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:06:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:06:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:06:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:06:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:06:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:06:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:06:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:06:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:06:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:06:54 --> Total execution time: 0.0566
DEBUG - 2017-06-16 12:06:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:06:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:06:58 --> Session Class Initialized
DEBUG - 2017-06-16 12:06:58 --> Session routines successfully run
DEBUG - 2017-06-16 12:06:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:06:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:10 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:10 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:11 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:11 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:11 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:11 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:16 --> Total execution time: 0.0853
DEBUG - 2017-06-16 12:07:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:23 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:23 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:27 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:27 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:27 --> Total execution time: 0.1192
DEBUG - 2017-06-16 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:40 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:40 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:07:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:07:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:07:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:07:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:07:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:07:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:00 --> Session Class Initialized
ERROR - 2017-06-16 12:08:00 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 12:08:00 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:00 --> Total execution time: 0.0740
DEBUG - 2017-06-16 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:00 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:00 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:00 --> Total execution time: 0.1420
DEBUG - 2017-06-16 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:05 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:05 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:12 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:12 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:12 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:30 --> User with name admin just logged in
DEBUG - 2017-06-16 12:08:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:31 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:31 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:31 --> Total execution time: 0.0747
DEBUG - 2017-06-16 12:08:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:41 --> Total execution time: 0.0664
DEBUG - 2017-06-16 12:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:46 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:46 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:08:46 --> Total execution time: 0.1021
DEBUG - 2017-06-16 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:08:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:08:53 --> Session Class Initialized
DEBUG - 2017-06-16 12:08:53 --> Session routines successfully run
DEBUG - 2017-06-16 12:08:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:08:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:09:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:09:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:09:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:09:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:09:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:09:02 --> Total execution time: 0.0769
DEBUG - 2017-06-16 12:09:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:09:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:09:17 --> Session Class Initialized
DEBUG - 2017-06-16 12:09:17 --> Session routines successfully run
DEBUG - 2017-06-16 12:09:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:09:17 --> Total execution time: 0.2201
DEBUG - 2017-06-16 12:09:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:09:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:09:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:09:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:09:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:09:35 --> Total execution time: 0.1376
DEBUG - 2017-06-16 12:09:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:09:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:09:57 --> Session Class Initialized
DEBUG - 2017-06-16 12:09:57 --> Session routines successfully run
DEBUG - 2017-06-16 12:09:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:09:57 --> Total execution time: 0.0637
DEBUG - 2017-06-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:10 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:10 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:10 --> Total execution time: 0.1369
DEBUG - 2017-06-16 12:10:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:20 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:20 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:10:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:38 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:38 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:10:38 --> Total execution time: 0.1493
DEBUG - 2017-06-16 12:10:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:10:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:10:49 --> Session Class Initialized
DEBUG - 2017-06-16 12:10:49 --> Session routines successfully run
DEBUG - 2017-06-16 12:10:49 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 12:10:49 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-16 12:10:49 --> Total execution time: 0.1178
DEBUG - 2017-06-16 12:11:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:11:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:11:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:11:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:11:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:11:07 --> Total execution time: 0.1164
DEBUG - 2017-06-16 12:11:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:11:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:11:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:11:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:11:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:11:26 --> Total execution time: 0.1375
DEBUG - 2017-06-16 12:11:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:11:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:11:27 --> Session Class Initialized
DEBUG - 2017-06-16 12:11:27 --> Session routines successfully run
DEBUG - 2017-06-16 12:11:28 --> Total execution time: 0.6569
DEBUG - 2017-06-16 12:11:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:11:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:11:40 --> Session Class Initialized
DEBUG - 2017-06-16 12:11:40 --> Session routines successfully run
DEBUG - 2017-06-16 12:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:11:41 --> Total execution time: 0.1158
DEBUG - 2017-06-16 12:11:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:11:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:11:57 --> Session Class Initialized
DEBUG - 2017-06-16 12:11:57 --> Session routines successfully run
DEBUG - 2017-06-16 12:11:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:11:57 --> Total execution time: 0.0910
DEBUG - 2017-06-16 12:12:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:12:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:12:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:12:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:12:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:12:13 --> Total execution time: 0.1186
DEBUG - 2017-06-16 12:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:12:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:12:23 --> Session Class Initialized
DEBUG - 2017-06-16 12:12:23 --> Session routines successfully run
DEBUG - 2017-06-16 12:12:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:12:23 --> Total execution time: 0.1054
DEBUG - 2017-06-16 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:12:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:12:49 --> Session Class Initialized
DEBUG - 2017-06-16 12:12:49 --> Session routines successfully run
DEBUG - 2017-06-16 12:12:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:12:49 --> Total execution time: 0.1051
DEBUG - 2017-06-16 12:12:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:12:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:12:49 --> Session Class Initialized
DEBUG - 2017-06-16 12:12:49 --> Session routines successfully run
DEBUG - 2017-06-16 12:12:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:12:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:01 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:01 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:01 --> Total execution time: 0.1440
DEBUG - 2017-06-16 12:13:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:11 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:11 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:11 --> Total execution time: 0.0679
DEBUG - 2017-06-16 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:24 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:24 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:24 --> Total execution time: 0.0683
DEBUG - 2017-06-16 12:13:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:33 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:33 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:33 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:33 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:37 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:37 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:37 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:37 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:37 --> Total execution time: 0.0877
DEBUG - 2017-06-16 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:40 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:40 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:40 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:40 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:41 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:41 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:13:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:13:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:13:55 --> Session Class Initialized
DEBUG - 2017-06-16 12:13:55 --> Session routines successfully run
DEBUG - 2017-06-16 12:13:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:13:55 --> Total execution time: 0.0611
DEBUG - 2017-06-16 12:14:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:14:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:14:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:14:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:14:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:14:06 --> Total execution time: 0.1295
DEBUG - 2017-06-16 12:14:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:14:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:14:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:14:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:14:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:14:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:14:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:14:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:14:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:14:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:14:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:14:17 --> Total execution time: 0.1957
DEBUG - 2017-06-16 12:14:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:14:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:14:25 --> Session Class Initialized
DEBUG - 2017-06-16 12:14:25 --> Session routines successfully run
DEBUG - 2017-06-16 12:14:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:14:25 --> Total execution time: 0.0774
DEBUG - 2017-06-16 12:14:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:14:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:14:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:14:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:14:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:14:35 --> Total execution time: 0.1122
DEBUG - 2017-06-16 12:15:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:15:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:15:33 --> Session Class Initialized
DEBUG - 2017-06-16 12:15:33 --> Session routines successfully run
DEBUG - 2017-06-16 12:15:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:15:33 --> Total execution time: 0.2134
DEBUG - 2017-06-16 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:16:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:16:05 --> Session Class Initialized
DEBUG - 2017-06-16 12:16:05 --> Session routines successfully run
DEBUG - 2017-06-16 12:16:06 --> Total execution time: 1.1607
DEBUG - 2017-06-16 12:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:44 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:44 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:51 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:51 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:17:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:17:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:17:59 --> Session Class Initialized
DEBUG - 2017-06-16 12:17:59 --> Session routines successfully run
DEBUG - 2017-06-16 12:17:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:17:59 --> Total execution time: 0.1806
DEBUG - 2017-06-16 12:18:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:18:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:18:10 --> Session Class Initialized
DEBUG - 2017-06-16 12:18:10 --> Session routines successfully run
DEBUG - 2017-06-16 12:18:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:18:10 --> Total execution time: 0.2000
DEBUG - 2017-06-16 12:18:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:18:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:18:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:18:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:18:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:18:19 --> Total execution time: 0.1003
DEBUG - 2017-06-16 12:18:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:18:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:18:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:18:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:18:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:18:29 --> Total execution time: 0.0998
DEBUG - 2017-06-16 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:18:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:18:38 --> Session Class Initialized
DEBUG - 2017-06-16 12:18:38 --> Session routines successfully run
DEBUG - 2017-06-16 12:18:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:18:38 --> Total execution time: 0.1306
DEBUG - 2017-06-16 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:19:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:19:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:19:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:19:09 --> Total execution time: 0.7578
DEBUG - 2017-06-16 12:19:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:19:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:19:56 --> Session Class Initialized
DEBUG - 2017-06-16 12:19:56 --> Session routines successfully run
DEBUG - 2017-06-16 12:19:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:19:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:20:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:20:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:20:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:20:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:20:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:20:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:20:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:20:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:20:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:20:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:20:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:20:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:20:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:20:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:20:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:20:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:20:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:21:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:21:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:21:47 --> Session Class Initialized
DEBUG - 2017-06-16 12:21:47 --> Session routines successfully run
DEBUG - 2017-06-16 12:21:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:21:47 --> Total execution time: 0.1879
DEBUG - 2017-06-16 12:21:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:21:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:21:52 --> Session Class Initialized
DEBUG - 2017-06-16 12:21:52 --> Session routines successfully run
DEBUG - 2017-06-16 12:21:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:21:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:08 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:08 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:22:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:22:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:22:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:22:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:22:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:22:43 --> Total execution time: 0.4491
DEBUG - 2017-06-16 12:24:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:24:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:24:35 --> Session Class Initialized
DEBUG - 2017-06-16 12:24:35 --> Session routines successfully run
DEBUG - 2017-06-16 12:24:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:24:35 --> Total execution time: 0.3286
DEBUG - 2017-06-16 12:24:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:24:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:24:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:24:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:24:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:24:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:00 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:00 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:01 --> Total execution time: 0.7958
DEBUG - 2017-06-16 12:25:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:07 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:07 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:20 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:20 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:20 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:20 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:25 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:25 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:31 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:31 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:25:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:25:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:25:31 --> Session Class Initialized
DEBUG - 2017-06-16 12:25:31 --> Session routines successfully run
DEBUG - 2017-06-16 12:25:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:25:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:04 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:04 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:04 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:04 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:04 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:05 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:05 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:05 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:05 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:06 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:06 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:11 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:11 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:11 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:12 --> Total execution time: 0.0972
DEBUG - 2017-06-16 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:13 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:13 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:14 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:14 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:14 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:17 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:17 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:17 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:17 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:26:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:26:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:26:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:26:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:00 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:00 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:00 --> Total execution time: 0.1005
DEBUG - 2017-06-16 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:26 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:26 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:26 --> Total execution time: 0.3033
DEBUG - 2017-06-16 12:27:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:29 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:29 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:30 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:30 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:49 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:49 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:49 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:49 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:50 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:50 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:50 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:51 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:51 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:53 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:53 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:55 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:55 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:27:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:27:56 --> Session Class Initialized
DEBUG - 2017-06-16 12:27:56 --> Session routines successfully run
DEBUG - 2017-06-16 12:27:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:27:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:16 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:16 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:17 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:17 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:18 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:18 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:18 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:23 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:23 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:36 --> Total execution time: 0.2679
DEBUG - 2017-06-16 12:28:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:37 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:37 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:38 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:38 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:42 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:42 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:43 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:43 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:56 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:56 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:56 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:56 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:57 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:57 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:28:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:28:58 --> Session Class Initialized
DEBUG - 2017-06-16 12:28:58 --> Session routines successfully run
DEBUG - 2017-06-16 12:28:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:28:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:29:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:29:00 --> Session Class Initialized
DEBUG - 2017-06-16 12:29:00 --> Session routines successfully run
DEBUG - 2017-06-16 12:29:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:29:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:29:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:29:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:29:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:29:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:29:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:29:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:29:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:29:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:29:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:29:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:29:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:29:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:30:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:30:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:30:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:30:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:30:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:30:03 --> Total execution time: 0.2131
DEBUG - 2017-06-16 12:30:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:30:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:30:38 --> Session Class Initialized
DEBUG - 2017-06-16 12:30:38 --> Session routines successfully run
DEBUG - 2017-06-16 12:30:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:30:38 --> Total execution time: 0.1256
DEBUG - 2017-06-16 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:03 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:03 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:19 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:19 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:20 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:20 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:21 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:21 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:21 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:21 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:21 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:21 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:22 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:22 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:28 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:28 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:28 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:28 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:28 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:28 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:28 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:28 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:28 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:31:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:31:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:31:43 --> Session Class Initialized
DEBUG - 2017-06-16 12:31:43 --> Session routines successfully run
DEBUG - 2017-06-16 12:31:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:31:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:32:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:32:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:32:39 --> Session Class Initialized
DEBUG - 2017-06-16 12:32:39 --> Session routines successfully run
DEBUG - 2017-06-16 12:32:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:32:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:34 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:34 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:34 --> Total execution time: 0.1268
DEBUG - 2017-06-16 12:33:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:36 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:36 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:53 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:53 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:53 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:53 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:53 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:53 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:33:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:33:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:33:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:33:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:33:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:33:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:34:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:34:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:34:02 --> Session Class Initialized
DEBUG - 2017-06-16 12:34:02 --> Session routines successfully run
DEBUG - 2017-06-16 12:34:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 12:34:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:35:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:35:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:35:54 --> Session Class Initialized
DEBUG - 2017-06-16 12:35:54 --> Session routines successfully run
DEBUG - 2017-06-16 12:35:55 --> Total execution time: 0.5000
DEBUG - 2017-06-16 12:38:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:38:15 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:38:15 --> Session Class Initialized
DEBUG - 2017-06-16 12:38:15 --> Session routines successfully run
DEBUG - 2017-06-16 12:38:15 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-16 12:38:15 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-16 12:38:15 --> Total execution time: 0.1893
DEBUG - 2017-06-16 12:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:38:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:38:55 --> Session Class Initialized
DEBUG - 2017-06-16 12:38:55 --> Session routines successfully run
DEBUG - 2017-06-16 12:38:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:38:55 --> Total execution time: 0.1282
DEBUG - 2017-06-16 12:39:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:39:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:39:40 --> Session Class Initialized
DEBUG - 2017-06-16 12:39:40 --> Session routines successfully run
DEBUG - 2017-06-16 12:39:41 --> Total execution time: 0.8607
DEBUG - 2017-06-16 12:40:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:40:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:40:44 --> Session Class Initialized
DEBUG - 2017-06-16 12:40:44 --> Session routines successfully run
DEBUG - 2017-06-16 12:40:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 12:40:44 --> Total execution time: 0.1517
DEBUG - 2017-06-16 12:41:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 12:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 12:41:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 12:41:27 --> Session Class Initialized
DEBUG - 2017-06-16 12:41:27 --> Session routines successfully run
DEBUG - 2017-06-16 12:41:28 --> Total execution time: 0.8883
DEBUG - 2017-06-16 15:26:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:26:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:26:42 --> Session Class Initialized
ERROR - 2017-06-16 15:26:42 --> Session: The session cookie was not signed.
DEBUG - 2017-06-16 15:26:42 --> Session routines successfully run
DEBUG - 2017-06-16 15:26:42 --> Total execution time: 0.9590
DEBUG - 2017-06-16 15:27:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:27:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:27:25 --> Session Class Initialized
DEBUG - 2017-06-16 15:27:25 --> Session routines successfully run
DEBUG - 2017-06-16 15:27:25 --> Total execution time: 0.0568
DEBUG - 2017-06-16 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:27:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:27:48 --> Session Class Initialized
DEBUG - 2017-06-16 15:27:48 --> Session routines successfully run
DEBUG - 2017-06-16 15:27:48 --> Total execution time: 0.0676
DEBUG - 2017-06-16 15:27:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:27:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:27:52 --> Session Class Initialized
DEBUG - 2017-06-16 15:27:52 --> Session routines successfully run
DEBUG - 2017-06-16 15:27:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 15:27:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:27:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:27:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:27:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:27:52 --> Session Class Initialized
DEBUG - 2017-06-16 15:27:52 --> Session routines successfully run
DEBUG - 2017-06-16 15:27:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 15:27:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:27:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:27:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:27:53 --> Session Class Initialized
DEBUG - 2017-06-16 15:27:53 --> Session routines successfully run
DEBUG - 2017-06-16 15:27:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-16 15:27:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:28:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:28:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:28:45 --> Session Class Initialized
DEBUG - 2017-06-16 15:28:45 --> Session routines successfully run
DEBUG - 2017-06-16 15:28:45 --> User with name damilare just logged in
DEBUG - 2017-06-16 15:28:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:28:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:28:46 --> Session Class Initialized
DEBUG - 2017-06-16 15:28:46 --> Session routines successfully run
DEBUG - 2017-06-16 15:28:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:28:47 --> Total execution time: 0.3099
DEBUG - 2017-06-16 15:29:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:29:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:29:32 --> Session Class Initialized
DEBUG - 2017-06-16 15:29:32 --> Session routines successfully run
DEBUG - 2017-06-16 15:29:32 --> User with name damilare just logged in
DEBUG - 2017-06-16 15:29:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-16 15:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-16 15:29:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-16 15:29:34 --> Session Class Initialized
DEBUG - 2017-06-16 15:29:34 --> Session routines successfully run
DEBUG - 2017-06-16 15:29:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-16 15:29:34 --> Total execution time: 0.0832

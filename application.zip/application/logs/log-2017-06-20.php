<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-20 00:19:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:01 --> No URI present. Default controller set.
DEBUG - 2017-06-20 00:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:02 --> Session Class Initialized
ERROR - 2017-06-20 00:19:02 --> Session: The session cookie was not signed.
DEBUG - 2017-06-20 00:19:02 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:02 --> Total execution time: 1.1563
DEBUG - 2017-06-20 00:19:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:03 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:03 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:03 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:03 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:03 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:03 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:08 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:08 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:08 --> User with name damilare just logged in
DEBUG - 2017-06-20 00:19:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:08 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:08 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:08 --> Total execution time: 0.2521
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Total execution time: 0.1029
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-20 00:19:14 --> Session Class Initialized
DEBUG - 2017-06-20 00:19:14 --> Session routines successfully run
DEBUG - 2017-06-20 00:19:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-20 00:19:14 --> Myapp class already loaded. Second attempt ignored.

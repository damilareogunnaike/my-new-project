<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-12 03:15:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-12 03:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-12 03:15:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-12 03:15:07 --> Session Class Initialized
ERROR - 2017-06-12 03:15:07 --> Session: The session cookie was not signed.
DEBUG - 2017-06-12 03:15:07 --> Session routines successfully run
DEBUG - 2017-06-12 03:15:07 --> Total execution time: 1.4759

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-06 09:08:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:08:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:08:35 --> Session Class Initialized
ERROR - 2017-06-06 09:08:35 --> Session: The session cookie was not signed.
DEBUG - 2017-06-06 09:08:35 --> Session routines successfully run
DEBUG - 2017-06-06 09:08:36 --> Total execution time: 0.6653
DEBUG - 2017-06-06 09:08:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:08:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:08:39 --> Session Class Initialized
DEBUG - 2017-06-06 09:08:39 --> Session routines successfully run
DEBUG - 2017-06-06 09:08:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 09:08:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:08:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:08:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:08:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:08:41 --> Session Class Initialized
DEBUG - 2017-06-06 09:08:41 --> Session routines successfully run
DEBUG - 2017-06-06 09:08:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 09:08:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:08:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:08:47 --> Session Class Initialized
DEBUG - 2017-06-06 09:08:47 --> Session routines successfully run
DEBUG - 2017-06-06 09:08:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 09:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:09:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:09:07 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:09:07 --> Session Class Initialized
DEBUG - 2017-06-06 09:09:07 --> Session routines successfully run
DEBUG - 2017-06-06 09:09:07 --> User with name admin just logged in
DEBUG - 2017-06-06 09:09:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:09:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:09:08 --> Session Class Initialized
DEBUG - 2017-06-06 09:09:08 --> Session routines successfully run
DEBUG - 2017-06-06 09:09:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:09:09 --> Total execution time: 0.4277
DEBUG - 2017-06-06 09:09:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 09:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 09:09:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 09:09:36 --> Session Class Initialized
DEBUG - 2017-06-06 09:09:36 --> Session routines successfully run
DEBUG - 2017-06-06 09:09:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 09:09:36 --> Total execution time: 0.1615
DEBUG - 2017-06-06 10:35:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 10:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 10:35:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 10:35:23 --> Session Class Initialized
ERROR - 2017-06-06 10:35:23 --> Session: The session cookie was not signed.
DEBUG - 2017-06-06 10:35:23 --> Session routines successfully run
DEBUG - 2017-06-06 10:35:24 --> Total execution time: 0.9660
DEBUG - 2017-06-06 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 10:36:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 10:36:34 --> Session Class Initialized
DEBUG - 2017-06-06 10:36:34 --> Session routines successfully run
DEBUG - 2017-06-06 10:36:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 10:36:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 10:36:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 10:36:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 10:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 10:36:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 10:36:35 --> Session Class Initialized
DEBUG - 2017-06-06 10:36:35 --> Session routines successfully run
DEBUG - 2017-06-06 10:36:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 10:36:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 10:36:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 10:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 10:36:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 10:36:36 --> Session Class Initialized
DEBUG - 2017-06-06 10:36:36 --> Session routines successfully run
DEBUG - 2017-06-06 10:36:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-06 10:36:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-06 16:11:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 16:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 16:11:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 16:11:54 --> Session Class Initialized
ERROR - 2017-06-06 16:11:54 --> Session: The session cookie was not signed.
DEBUG - 2017-06-06 16:11:54 --> Session routines successfully run
DEBUG - 2017-06-06 16:11:54 --> Total execution time: 0.6793
DEBUG - 2017-06-06 16:14:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 16:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 16:14:37 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 16:14:37 --> Session Class Initialized
ERROR - 2017-06-06 16:14:37 --> Session: The session cookie was not signed.
DEBUG - 2017-06-06 16:14:37 --> Session routines successfully run
DEBUG - 2017-06-06 16:14:37 --> Total execution time: 0.1172
DEBUG - 2017-06-06 16:15:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-06 16:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-06 16:15:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-06 16:15:41 --> Session Class Initialized
DEBUG - 2017-06-06 16:15:41 --> Session routines successfully run
DEBUG - 2017-06-06 16:15:41 --> Total execution time: 0.0941

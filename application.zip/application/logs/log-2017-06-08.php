<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-08 04:42:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-08 04:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-08 04:42:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-08 04:42:03 --> Session Class Initialized
ERROR - 2017-06-08 04:42:03 --> Session: The session cookie was not signed.
DEBUG - 2017-06-08 04:42:03 --> Session routines successfully run
DEBUG - 2017-06-08 04:42:04 --> Total execution time: 1.2028
DEBUG - 2017-06-08 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-08 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-08 04:43:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-08 04:43:02 --> Session Class Initialized
DEBUG - 2017-06-08 04:43:02 --> Session routines successfully run
DEBUG - 2017-06-08 04:43:02 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-08 04:43:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-08 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-08 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-08 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-08 04:43:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-08 04:43:03 --> Session Class Initialized
DEBUG - 2017-06-08 04:43:03 --> Session routines successfully run
DEBUG - 2017-06-08 04:43:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-08 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-08 04:43:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-08 04:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-08 04:43:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-08 04:43:08 --> Session Class Initialized
DEBUG - 2017-06-08 04:43:08 --> Session routines successfully run
DEBUG - 2017-06-08 04:43:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-08 04:43:08 --> Myapp class already loaded. Second attempt ignored.

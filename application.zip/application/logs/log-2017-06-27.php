<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-27 00:01:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:41 --> Session Class Initialized
ERROR - 2017-06-27 00:01:41 --> Session: The session cookie was not signed.
DEBUG - 2017-06-27 00:01:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:41 --> Total execution time: 1.2275
DEBUG - 2017-06-27 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:01:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:01:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:01:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:01:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:01:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:01:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:01:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:01:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:50 --> Session Class Initialized
DEBUG - 2017-06-27 00:01:50 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:50 --> User with name damilare just logged in
DEBUG - 2017-06-27 00:01:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:01:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:01:51 --> Session Class Initialized
DEBUG - 2017-06-27 00:01:51 --> Session routines successfully run
DEBUG - 2017-06-27 00:01:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:01:51 --> Total execution time: 0.2833
DEBUG - 2017-06-27 00:04:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:04:32 --> Total execution time: 0.1150
DEBUG - 2017-06-27 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:35 --> Total execution time: 0.0895
DEBUG - 2017-06-27 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:04:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:04:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:04:36 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:04:36 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:36 --> Session Class Initialized
DEBUG - 2017-06-27 00:04:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:04:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:04:36 --> Session routines successfully run
DEBUG - 2017-06-27 00:04:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:04:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:04:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:03 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:03 --> Total execution time: 0.0941
DEBUG - 2017-06-27 00:08:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:04 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:04 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:04 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:04 --> Total execution time: 0.0928
DEBUG - 2017-06-27 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:16 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:16 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:16 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:16 --> Total execution time: 0.1002
DEBUG - 2017-06-27 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:17 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:17 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:17 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:17 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:17 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:17 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:34 --> Total execution time: 0.0937
DEBUG - 2017-06-27 00:08:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:08:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:08:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:32 --> Total execution time: 0.0846
DEBUG - 2017-06-27 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:33 --> Total execution time: 0.1237
DEBUG - 2017-06-27 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:09:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:09:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:09:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:09:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:05 --> Total execution time: 0.0894
DEBUG - 2017-06-27 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:05 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:05 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:53 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:53 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:53 --> Total execution time: 0.0864
DEBUG - 2017-06-27 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:10:54 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:54 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:10:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:54 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:54 --> Session Class Initialized
DEBUG - 2017-06-27 00:10:54 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:54 --> Session routines successfully run
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:10:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:10:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:11:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:11:03 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:11:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:11:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:11:03 --> Total execution time: 0.0837
DEBUG - 2017-06-27 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:11:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:11:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:11:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:11:03 --> Session Class Initialized
DEBUG - 2017-06-27 00:11:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:11:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:11:03 --> Session routines successfully run
DEBUG - 2017-06-27 00:11:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:11:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:11:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:11:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:19 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:19 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:19 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:19 --> Total execution time: 0.0842
DEBUG - 2017-06-27 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:20 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:20 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:20 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:20 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:20 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:20 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:27 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:27 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:27 --> Total execution time: 0.0859
DEBUG - 2017-06-27 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:12:28 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:12:28 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:28 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:28 --> Session Class Initialized
DEBUG - 2017-06-27 00:12:28 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:28 --> Session routines successfully run
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:12:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:12:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:13:48 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:13:48 --> Session Class Initialized
DEBUG - 2017-06-27 00:13:48 --> Session routines successfully run
DEBUG - 2017-06-27 00:13:48 --> Total execution time: 0.0851
DEBUG - 2017-06-27 00:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:13:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:13:48 --> Session Class Initialized
DEBUG - 2017-06-27 00:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:13:48 --> Session routines successfully run
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:13:48 --> Session Class Initialized
DEBUG - 2017-06-27 00:13:48 --> Session Class Initialized
DEBUG - 2017-06-27 00:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:13:48 --> Session routines successfully run
DEBUG - 2017-06-27 00:13:48 --> Session routines successfully run
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:13:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:13:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:43 --> Total execution time: 0.0986
DEBUG - 2017-06-27 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:45 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:45 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:45 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:45 --> Total execution time: 0.1062
DEBUG - 2017-06-27 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:45 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:15:45 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:45 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:45 --> Session Class Initialized
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:45 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:45 --> Session routines successfully run
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:15:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:15:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:16:07 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:16:07 --> Session Class Initialized
DEBUG - 2017-06-27 00:16:07 --> Session routines successfully run
DEBUG - 2017-06-27 00:16:07 --> Total execution time: 0.1002
DEBUG - 2017-06-27 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:16:07 --> Session Class Initialized
DEBUG - 2017-06-27 00:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:16:07 --> Session routines successfully run
DEBUG - 2017-06-27 00:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:16:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:16:08 --> Session Class Initialized
DEBUG - 2017-06-27 00:16:08 --> Session Class Initialized
DEBUG - 2017-06-27 00:16:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:16:08 --> Session routines successfully run
DEBUG - 2017-06-27 00:16:08 --> Session routines successfully run
DEBUG - 2017-06-27 00:16:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:16:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:16:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:16:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:17:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:17:17 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:17:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:17:17 --> Session Class Initialized
DEBUG - 2017-06-27 00:17:17 --> Session routines successfully run
DEBUG - 2017-06-27 00:17:17 --> Total execution time: 0.0973
DEBUG - 2017-06-27 00:17:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:17:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:17:18 --> Session Class Initialized
DEBUG - 2017-06-27 00:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:17:18 --> Session routines successfully run
DEBUG - 2017-06-27 00:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:17:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:17:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:17:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:17:18 --> Session Class Initialized
DEBUG - 2017-06-27 00:17:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:17:18 --> Session routines successfully run
DEBUG - 2017-06-27 00:17:18 --> Session Class Initialized
DEBUG - 2017-06-27 00:17:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:17:18 --> Session routines successfully run
DEBUG - 2017-06-27 00:17:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:17:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:17:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 00:17:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 00:18:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:18:57 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:18:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:18:57 --> Session Class Initialized
DEBUG - 2017-06-27 00:18:57 --> Session routines successfully run
DEBUG - 2017-06-27 00:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:19:48 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:19:48 --> Session Class Initialized
DEBUG - 2017-06-27 00:19:48 --> Session routines successfully run
DEBUG - 2017-06-27 00:19:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:19:57 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:19:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:19:57 --> Session Class Initialized
DEBUG - 2017-06-27 00:19:57 --> Session routines successfully run
DEBUG - 2017-06-27 00:19:57 --> Total execution time: 0.0891
DEBUG - 2017-06-27 00:24:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:24:39 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:24:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:24:39 --> Session Class Initialized
DEBUG - 2017-06-27 00:24:39 --> Session routines successfully run
DEBUG - 2017-06-27 00:24:39 --> Total execution time: 0.0990
DEBUG - 2017-06-27 00:25:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:25:21 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:25:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:25:22 --> Session Class Initialized
DEBUG - 2017-06-27 00:25:22 --> Session routines successfully run
DEBUG - 2017-06-27 00:25:22 --> Total execution time: 0.1101
DEBUG - 2017-06-27 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:26:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:26:47 --> Session Class Initialized
DEBUG - 2017-06-27 00:26:47 --> Session routines successfully run
DEBUG - 2017-06-27 00:26:47 --> Total execution time: 0.0960
DEBUG - 2017-06-27 00:28:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:28:02 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:28:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:28:02 --> Session Class Initialized
DEBUG - 2017-06-27 00:28:02 --> Session routines successfully run
DEBUG - 2017-06-27 00:28:02 --> Total execution time: 0.1021
DEBUG - 2017-06-27 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:31 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:31 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:31 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:31 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:31 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:31 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:31 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:31 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:32 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:32 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:33 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:33 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:34 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:34 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:41 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:41 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:42 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:42 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:41:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:41:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:41:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:41:43 --> Session Class Initialized
DEBUG - 2017-06-27 00:41:43 --> Session routines successfully run
DEBUG - 2017-06-27 00:42:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:42:12 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:42:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:42:12 --> Session Class Initialized
DEBUG - 2017-06-27 00:42:12 --> Session routines successfully run
DEBUG - 2017-06-27 00:42:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:42:35 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:42:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:42:35 --> Session Class Initialized
DEBUG - 2017-06-27 00:42:35 --> Session routines successfully run
DEBUG - 2017-06-27 00:42:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:42:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:42:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:42:53 --> Session Class Initialized
DEBUG - 2017-06-27 00:42:53 --> Session routines successfully run
DEBUG - 2017-06-27 00:43:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:43:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:43:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:43:06 --> Session Class Initialized
DEBUG - 2017-06-27 00:43:06 --> Session routines successfully run
DEBUG - 2017-06-27 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:43:14 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:43:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:43:14 --> Session Class Initialized
DEBUG - 2017-06-27 00:43:14 --> Session routines successfully run
DEBUG - 2017-06-27 00:43:14 --> Total execution time: 0.1109
DEBUG - 2017-06-27 00:44:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:44:00 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:44:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:44:00 --> Session Class Initialized
DEBUG - 2017-06-27 00:44:00 --> Session routines successfully run
DEBUG - 2017-06-27 00:44:00 --> Total execution time: 0.1103
DEBUG - 2017-06-27 00:46:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:46:13 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:46:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:46:13 --> Session Class Initialized
DEBUG - 2017-06-27 00:46:13 --> Session routines successfully run
DEBUG - 2017-06-27 00:46:13 --> Total execution time: 0.1061
DEBUG - 2017-06-27 00:49:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 00:49:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 00:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 00:49:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 00:49:27 --> Session Class Initialized
DEBUG - 2017-06-27 00:49:27 --> Session routines successfully run
DEBUG - 2017-06-27 00:49:27 --> Total execution time: 0.1201
DEBUG - 2017-06-27 01:12:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:12:07 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:12:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:12:08 --> Session Class Initialized
DEBUG - 2017-06-27 01:12:08 --> Session routines successfully run
DEBUG - 2017-06-27 01:12:08 --> Total execution time: 1.1066
DEBUG - 2017-06-27 01:12:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:12:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:12:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:12:47 --> Session Class Initialized
DEBUG - 2017-06-27 01:12:47 --> Session routines successfully run
DEBUG - 2017-06-27 01:12:47 --> Total execution time: 0.1115
DEBUG - 2017-06-27 01:13:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:13:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:13:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:13:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:13:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:13:49 --> Total execution time: 0.1255
DEBUG - 2017-06-27 01:14:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:14:00 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:14:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:14:00 --> Session Class Initialized
DEBUG - 2017-06-27 01:14:00 --> Session routines successfully run
DEBUG - 2017-06-27 01:14:00 --> Total execution time: 0.1033
DEBUG - 2017-06-27 01:14:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:14:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:14:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:14:53 --> Session Class Initialized
DEBUG - 2017-06-27 01:14:53 --> Session routines successfully run
DEBUG - 2017-06-27 01:14:53 --> Total execution time: 0.0993
DEBUG - 2017-06-27 01:15:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:15:18 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:15:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:15:19 --> Session Class Initialized
DEBUG - 2017-06-27 01:15:19 --> Session routines successfully run
DEBUG - 2017-06-27 01:15:19 --> Total execution time: 0.0944
DEBUG - 2017-06-27 01:15:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:15:39 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:15:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:15:39 --> Session Class Initialized
DEBUG - 2017-06-27 01:15:39 --> Session routines successfully run
DEBUG - 2017-06-27 01:15:39 --> Total execution time: 0.0938
DEBUG - 2017-06-27 01:15:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:15:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:15:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:15:40 --> Session Class Initialized
DEBUG - 2017-06-27 01:15:40 --> Session routines successfully run
DEBUG - 2017-06-27 01:15:40 --> Total execution time: 0.1126
DEBUG - 2017-06-27 01:15:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:15:44 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:15:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:15:44 --> Session Class Initialized
DEBUG - 2017-06-27 01:15:44 --> Session routines successfully run
DEBUG - 2017-06-27 01:15:44 --> Total execution time: 0.1139
DEBUG - 2017-06-27 01:15:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:15:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:15:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:15:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:15:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:15:49 --> Total execution time: 0.0956
DEBUG - 2017-06-27 01:17:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:17:13 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:17:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:17:13 --> Session Class Initialized
DEBUG - 2017-06-27 01:17:13 --> Session routines successfully run
DEBUG - 2017-06-27 01:17:13 --> Total execution time: 0.1012
DEBUG - 2017-06-27 01:17:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:17:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:17:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:17:27 --> Session Class Initialized
DEBUG - 2017-06-27 01:17:27 --> Session routines successfully run
ERROR - 2017-06-27 01:17:27 --> Severity: Warning --> include_once(angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:17:27 --> Severity: Warning --> include_once(): Failed opening 'angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:17:27 --> Total execution time: 0.1559
DEBUG - 2017-06-27 01:17:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:17:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:17:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:17:34 --> Session Class Initialized
DEBUG - 2017-06-27 01:17:34 --> Session routines successfully run
ERROR - 2017-06-27 01:17:34 --> Severity: Warning --> include_once(../angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:17:34 --> Severity: Warning --> include_once(): Failed opening '../angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:17:34 --> Total execution time: 0.1186
DEBUG - 2017-06-27 01:17:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:17:44 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:17:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:17:44 --> Session Class Initialized
DEBUG - 2017-06-27 01:17:44 --> Session routines successfully run
ERROR - 2017-06-27 01:17:44 --> Severity: Warning --> include_once(angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:17:45 --> Severity: Warning --> include_once(): Failed opening 'angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:17:45 --> Total execution time: 0.1210
DEBUG - 2017-06-27 01:18:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:18:26 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:18:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:18:26 --> Session Class Initialized
DEBUG - 2017-06-27 01:18:26 --> Session routines successfully run
ERROR - 2017-06-27 01:18:26 --> Severity: Warning --> include_once(angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:18:26 --> Severity: Warning --> include_once(): Failed opening 'angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:18:26 --> Total execution time: 0.1187
DEBUG - 2017-06-27 01:18:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:18:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:18:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:18:40 --> Session Class Initialized
DEBUG - 2017-06-27 01:18:40 --> Session routines successfully run
ERROR - 2017-06-27 01:18:40 --> Severity: Warning --> include_once(../angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:18:40 --> Severity: Warning --> include_once(): Failed opening '../angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:18:40 --> Total execution time: 0.1175
DEBUG - 2017-06-27 01:18:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:18:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:18:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:18:48 --> Session Class Initialized
DEBUG - 2017-06-27 01:18:48 --> Session routines successfully run
ERROR - 2017-06-27 01:18:48 --> Severity: Warning --> include_once(../../angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:18:48 --> Severity: Warning --> include_once(): Failed opening '../../angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:18:48 --> Total execution time: 0.1377
DEBUG - 2017-06-27 01:20:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:20:21 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:20:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:20:22 --> Session Class Initialized
DEBUG - 2017-06-27 01:20:22 --> Session routines successfully run
ERROR - 2017-06-27 01:20:22 --> Severity: Warning --> include_once(../angular_files.php): failed to open stream: No such file or directory C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
ERROR - 2017-06-27 01:20:22 --> Severity: Warning --> include_once(): Failed opening '../angular_files.php' for inclusion (include_path='C:\xampp\php\PEAR') C:\xampp\htdocs\school_ms\application\views\templates\footer.php 3
DEBUG - 2017-06-27 01:20:22 --> Total execution time: 0.1157
DEBUG - 2017-06-27 01:20:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:20:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:20:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:20:50 --> Session Class Initialized
DEBUG - 2017-06-27 01:20:50 --> Session routines successfully run
DEBUG - 2017-06-27 01:20:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:20:55 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:20:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:20:55 --> Session Class Initialized
DEBUG - 2017-06-27 01:20:55 --> Session routines successfully run
DEBUG - 2017-06-27 01:20:55 --> Total execution time: 0.1074
DEBUG - 2017-06-27 01:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:21:07 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:21:07 --> Session Class Initialized
DEBUG - 2017-06-27 01:21:07 --> Session routines successfully run
DEBUG - 2017-06-27 01:21:07 --> Total execution time: 0.1040
DEBUG - 2017-06-27 01:21:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:21:52 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:21:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:21:52 --> Session Class Initialized
DEBUG - 2017-06-27 01:21:52 --> Session routines successfully run
DEBUG - 2017-06-27 01:21:52 --> Total execution time: 0.1089
DEBUG - 2017-06-27 01:23:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:23:12 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:23:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:23:12 --> Session Class Initialized
DEBUG - 2017-06-27 01:23:12 --> Session routines successfully run
DEBUG - 2017-06-27 01:23:12 --> Total execution time: 0.1001
DEBUG - 2017-06-27 01:23:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:23:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:23:13 --> Session Class Initialized
DEBUG - 2017-06-27 01:23:13 --> Session routines successfully run
DEBUG - 2017-06-27 01:23:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:23:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:23:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:24:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:24:17 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:24:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:24:17 --> Session Class Initialized
DEBUG - 2017-06-27 01:24:17 --> Session routines successfully run
DEBUG - 2017-06-27 01:24:17 --> Total execution time: 0.1110
DEBUG - 2017-06-27 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:24:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:24:18 --> Session Class Initialized
DEBUG - 2017-06-27 01:24:18 --> Session routines successfully run
DEBUG - 2017-06-27 01:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:24:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:24:18 --> Session Class Initialized
DEBUG - 2017-06-27 01:24:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:24:18 --> Session routines successfully run
DEBUG - 2017-06-27 01:24:18 --> Session Class Initialized
DEBUG - 2017-06-27 01:24:18 --> Session routines successfully run
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:24:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:24:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:24:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:43:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:43:29 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:43:29 --> Session Class Initialized
DEBUG - 2017-06-27 01:43:29 --> Session routines successfully run
DEBUG - 2017-06-27 01:43:29 --> Total execution time: 0.1262
DEBUG - 2017-06-27 01:43:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:43:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:43:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:43:29 --> Session Class Initialized
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:43:29 --> Session routines successfully run
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:43:29 --> Session Class Initialized
DEBUG - 2017-06-27 01:43:29 --> Session Class Initialized
DEBUG - 2017-06-27 01:43:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:43:29 --> Session routines successfully run
DEBUG - 2017-06-27 01:43:29 --> Session routines successfully run
DEBUG - 2017-06-27 01:43:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:43:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:43:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:43:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:08 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:08 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:08 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:08 --> Total execution time: 0.1025
DEBUG - 2017-06-27 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:09 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:09 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:09 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:09 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:09 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:09 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:27 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:27 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:27 --> Total execution time: 0.1303
DEBUG - 2017-06-27 01:45:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:28 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:28 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:28 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:28 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:28 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:28 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:44 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:44 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:44 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:45 --> Total execution time: 0.1064
DEBUG - 2017-06-27 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:45 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:45:45 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:45 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:45 --> Session Class Initialized
DEBUG - 2017-06-27 01:45:45 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:45 --> Session routines successfully run
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:45:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:45:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:46:04 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:46:04 --> Session Class Initialized
DEBUG - 2017-06-27 01:46:04 --> Session routines successfully run
DEBUG - 2017-06-27 01:46:04 --> Total execution time: 0.1034
DEBUG - 2017-06-27 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:46:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:46:04 --> Session Class Initialized
DEBUG - 2017-06-27 01:46:04 --> Session routines successfully run
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:46:04 --> Session Class Initialized
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:46:04 --> Session routines successfully run
DEBUG - 2017-06-27 01:46:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:46:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:46:04 --> Session Class Initialized
DEBUG - 2017-06-27 01:46:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:46:04 --> Session routines successfully run
DEBUG - 2017-06-27 01:46:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:46:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:48:52 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:48:52 --> Session Class Initialized
DEBUG - 2017-06-27 01:48:52 --> Session routines successfully run
DEBUG - 2017-06-27 01:48:52 --> Total execution time: 0.1045
DEBUG - 2017-06-27 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:48:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:48:52 --> Session Class Initialized
DEBUG - 2017-06-27 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:48:52 --> Session routines successfully run
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:48:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:48:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:48:52 --> Session Class Initialized
DEBUG - 2017-06-27 01:48:52 --> Session Class Initialized
DEBUG - 2017-06-27 01:48:52 --> Session routines successfully run
DEBUG - 2017-06-27 01:48:52 --> Session routines successfully run
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:48:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:48:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:48:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:15 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:15 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:15 --> Total execution time: 0.1348
DEBUG - 2017-06-27 01:49:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:16 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:16 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:16 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:16 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:16 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:16 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:49 --> Total execution time: 0.1236
DEBUG - 2017-06-27 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:49:50 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:50 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:50 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:50 --> Session Class Initialized
DEBUG - 2017-06-27 01:49:50 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:50 --> Session routines successfully run
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:49:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:49:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:50:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:50:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:50:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:50:40 --> Session Class Initialized
DEBUG - 2017-06-27 01:50:40 --> Session routines successfully run
DEBUG - 2017-06-27 01:50:40 --> Total execution time: 0.1186
DEBUG - 2017-06-27 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:50:41 --> Session Class Initialized
DEBUG - 2017-06-27 01:50:41 --> Session routines successfully run
DEBUG - 2017-06-27 01:50:41 --> Session Class Initialized
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:50:41 --> Session routines successfully run
DEBUG - 2017-06-27 01:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:50:41 --> Session Class Initialized
DEBUG - 2017-06-27 01:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:50:41 --> Session routines successfully run
DEBUG - 2017-06-27 01:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:03 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:03 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:03 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:03 --> Total execution time: 0.1161
DEBUG - 2017-06-27 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:03 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:03 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:03 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:03 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:03 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:03 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:19 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:19 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:19 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:19 --> Total execution time: 0.1570
DEBUG - 2017-06-27 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:20 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:20 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:20 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:20 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:20 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:20 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:57 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:57 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:57 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:57 --> Total execution time: 0.1190
DEBUG - 2017-06-27 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:51:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:51:57 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:51:57 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:57 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:57 --> Session Class Initialized
DEBUG - 2017-06-27 01:51:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:57 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:57 --> Session routines successfully run
DEBUG - 2017-06-27 01:51:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:51:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:51:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:11 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:11 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:11 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:11 --> Total execution time: 0.1438
DEBUG - 2017-06-27 01:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:11 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:11 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:11 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:11 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:11 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:11 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:25 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:25 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:25 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:25 --> Total execution time: 0.1473
DEBUG - 2017-06-27 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:26 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:26 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:26 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:26 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:26 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:26 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:48 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:48 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:48 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:48 --> Total execution time: 0.1767
DEBUG - 2017-06-27 01:52:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:52:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:49 --> Session Class Initialized
DEBUG - 2017-06-27 01:52:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:49 --> Session routines successfully run
DEBUG - 2017-06-27 01:52:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:52:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:52:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:52:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 01:52:53 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-27 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:53:43 --> Session Class Initialized
DEBUG - 2017-06-27 01:53:43 --> Session routines successfully run
DEBUG - 2017-06-27 01:53:43 --> Total execution time: 0.1157
DEBUG - 2017-06-27 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:53:43 --> Session Class Initialized
DEBUG - 2017-06-27 01:53:43 --> Session routines successfully run
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:53:43 --> Session Class Initialized
DEBUG - 2017-06-27 01:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:53:43 --> Session Class Initialized
DEBUG - 2017-06-27 01:53:43 --> Session routines successfully run
DEBUG - 2017-06-27 01:53:43 --> Session routines successfully run
DEBUG - 2017-06-27 01:53:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:53:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:53:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:53:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:53:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:53:45 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 01:53:45 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-27 01:53:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 01:53:53 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-27 01:54:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:54:07 --> No URI present. Default controller set.
DEBUG - 2017-06-27 01:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:54:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:54:07 --> Session Class Initialized
DEBUG - 2017-06-27 01:54:07 --> Session routines successfully run
DEBUG - 2017-06-27 01:54:07 --> Total execution time: 0.1371
DEBUG - 2017-06-27 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:54:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:54:08 --> Session Class Initialized
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:54:08 --> Session routines successfully run
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:54:08 --> Session Class Initialized
DEBUG - 2017-06-27 01:54:08 --> Session Class Initialized
DEBUG - 2017-06-27 01:54:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:54:08 --> Session routines successfully run
DEBUG - 2017-06-27 01:54:08 --> Session routines successfully run
DEBUG - 2017-06-27 01:54:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:54:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:54:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:54:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:54:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 01:54:11 --> 404 Page Not Found: Base/api
DEBUG - 2017-06-27 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:56:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:56:21 --> Session Class Initialized
DEBUG - 2017-06-27 01:56:21 --> Session routines successfully run
DEBUG - 2017-06-27 01:56:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:56:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:56:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:56:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 01:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 01:56:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 01:56:30 --> Session Class Initialized
DEBUG - 2017-06-27 01:56:30 --> Session routines successfully run
DEBUG - 2017-06-27 01:56:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 01:56:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 01:56:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:07:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:07:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:07:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:07:34 --> Session Class Initialized
DEBUG - 2017-06-27 02:07:35 --> Session routines successfully run
DEBUG - 2017-06-27 02:07:35 --> Total execution time: 0.1538
DEBUG - 2017-06-27 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:07:35 --> Session Class Initialized
DEBUG - 2017-06-27 02:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:07:35 --> Session routines successfully run
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:07:35 --> Session Class Initialized
DEBUG - 2017-06-27 02:07:35 --> Session Class Initialized
DEBUG - 2017-06-27 02:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:07:35 --> Session routines successfully run
DEBUG - 2017-06-27 02:07:35 --> Session routines successfully run
DEBUG - 2017-06-27 02:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:07:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:09:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:09:19 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:09:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:09:19 --> Session Class Initialized
DEBUG - 2017-06-27 02:09:19 --> Session routines successfully run
DEBUG - 2017-06-27 02:09:19 --> Total execution time: 0.1168
DEBUG - 2017-06-27 02:09:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:09:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:09:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:09:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:09:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:09:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:09:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:09:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:09:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:09:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:09:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:09:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:09:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:09:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:09:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:09:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:09:54 --> Session Class Initialized
DEBUG - 2017-06-27 02:09:54 --> Session routines successfully run
DEBUG - 2017-06-27 02:09:54 --> Total execution time: 0.1199
DEBUG - 2017-06-27 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:10:01 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:10:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:10:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:10:01 --> Total execution time: 0.1267
DEBUG - 2017-06-27 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:10:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:10:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:10:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:10:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:10:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:10:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:10:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:12:23 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:12:23 --> Session Class Initialized
DEBUG - 2017-06-27 02:12:23 --> Session routines successfully run
DEBUG - 2017-06-27 02:12:23 --> Total execution time: 0.1333
DEBUG - 2017-06-27 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:12:23 --> Session Class Initialized
DEBUG - 2017-06-27 02:12:23 --> Session routines successfully run
DEBUG - 2017-06-27 02:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:12:24 --> Session Class Initialized
DEBUG - 2017-06-27 02:12:24 --> Session routines successfully run
DEBUG - 2017-06-27 02:12:24 --> Session Class Initialized
DEBUG - 2017-06-27 02:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:12:24 --> Session routines successfully run
DEBUG - 2017-06-27 02:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:09 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:10 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:10 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:10 --> Total execution time: 0.1276
DEBUG - 2017-06-27 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:10 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:10 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:10 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:10 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:10 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:10 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:26 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:26 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:26 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:26 --> Total execution time: 0.1134
DEBUG - 2017-06-27 02:13:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:26 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:26 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:26 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:26 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:26 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:26 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:33 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:33 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:33 --> Total execution time: 0.1197
DEBUG - 2017-06-27 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:34 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:34 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:13:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:34 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:34 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:34 --> Session Class Initialized
DEBUG - 2017-06-27 02:13:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:34 --> Session routines successfully run
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:13:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:13:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:37 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:37 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:37 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:37 --> Total execution time: 0.1428
DEBUG - 2017-06-27 02:14:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:48 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:48 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:48 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:48 --> Total execution time: 0.1390
DEBUG - 2017-06-27 02:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:48 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:48 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:48 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:48 --> Session Class Initialized
DEBUG - 2017-06-27 02:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:48 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:48 --> Session routines successfully run
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:42 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:42 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:42 --> Total execution time: 0.1337
DEBUG - 2017-06-27 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:56 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:56 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:56 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:56 --> Total execution time: 0.1433
DEBUG - 2017-06-27 02:15:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:57 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:57 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:15:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:15:57 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:57 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:57 --> Session Class Initialized
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:57 --> Session routines successfully run
DEBUG - 2017-06-27 02:15:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:15:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:15:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:16:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:16:43 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:16:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:16:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:16:43 --> Total execution time: 0.1388
DEBUG - 2017-06-27 02:16:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:16:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:16:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:16:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:16:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:16:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:16:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:16:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:16:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:16:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:16:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:16:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:16:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:16:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:23:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:23:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:23:27 --> Session Class Initialized
DEBUG - 2017-06-27 02:23:28 --> Session routines successfully run
DEBUG - 2017-06-27 02:23:28 --> Total execution time: 0.1307
DEBUG - 2017-06-27 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:23:28 --> Session Class Initialized
DEBUG - 2017-06-27 02:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:23:28 --> Session routines successfully run
DEBUG - 2017-06-27 02:23:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:23:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:23:28 --> Session Class Initialized
DEBUG - 2017-06-27 02:23:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:23:28 --> Session routines successfully run
DEBUG - 2017-06-27 02:23:28 --> Session Class Initialized
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:23:28 --> Session routines successfully run
DEBUG - 2017-06-27 02:23:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:23:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:23:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:25:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:25:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:25:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:25:53 --> Session Class Initialized
DEBUG - 2017-06-27 02:25:53 --> Session routines successfully run
DEBUG - 2017-06-27 02:25:53 --> Total execution time: 0.1492
DEBUG - 2017-06-27 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:25:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:25:54 --> Session Class Initialized
DEBUG - 2017-06-27 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:25:54 --> Session routines successfully run
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:25:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:25:54 --> Session Class Initialized
DEBUG - 2017-06-27 02:25:54 --> Session Class Initialized
DEBUG - 2017-06-27 02:25:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:25:54 --> Session routines successfully run
DEBUG - 2017-06-27 02:25:54 --> Session routines successfully run
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:25:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:25:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:25:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:26:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:26:24 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:26:24 --> Session Class Initialized
DEBUG - 2017-06-27 02:26:24 --> Session routines successfully run
DEBUG - 2017-06-27 02:26:24 --> Total execution time: 0.1109
DEBUG - 2017-06-27 02:26:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:26:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:26:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:26:25 --> Session Class Initialized
DEBUG - 2017-06-27 02:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:26:25 --> Session routines successfully run
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:26:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:26:25 --> Session Class Initialized
DEBUG - 2017-06-27 02:26:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:26:25 --> Session routines successfully run
DEBUG - 2017-06-27 02:26:25 --> Session Class Initialized
DEBUG - 2017-06-27 02:26:25 --> Session routines successfully run
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:26:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:26:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:26:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:27:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:27:02 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:27:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:27:02 --> Session Class Initialized
DEBUG - 2017-06-27 02:27:02 --> Session routines successfully run
DEBUG - 2017-06-27 02:27:02 --> Total execution time: 0.1354
DEBUG - 2017-06-27 02:27:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:27:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:27:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:27:03 --> Session Class Initialized
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:27:03 --> Session routines successfully run
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:27:03 --> Session Class Initialized
DEBUG - 2017-06-27 02:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:27:03 --> Session Class Initialized
DEBUG - 2017-06-27 02:27:03 --> Session routines successfully run
DEBUG - 2017-06-27 02:27:03 --> Session routines successfully run
DEBUG - 2017-06-27 02:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:27:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:27:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:28:37 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:28:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:28:37 --> Session Class Initialized
DEBUG - 2017-06-27 02:28:37 --> Session routines successfully run
DEBUG - 2017-06-27 02:28:37 --> Total execution time: 0.1363
DEBUG - 2017-06-27 02:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:28:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:28:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:28:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:28:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:28:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:38 --> Session Class Initialized
DEBUG - 2017-06-27 02:28:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:28:38 --> Session routines successfully run
DEBUG - 2017-06-27 02:28:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:28:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:28:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:28:43 --> Session Class Initialized
DEBUG - 2017-06-27 02:28:43 --> Session routines successfully run
DEBUG - 2017-06-27 02:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:28:43 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 02:28:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Result_pins_model_model C:\xampp\htdocs\school_ms\system\core\Loader.php 344
DEBUG - 2017-06-27 02:29:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:29:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:29:13 --> Session Class Initialized
DEBUG - 2017-06-27 02:29:13 --> Session routines successfully run
DEBUG - 2017-06-27 02:29:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:29:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:29:13 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 02:29:13 --> Severity: error --> Exception: Unable to locate the model you have specified: Result_pins_model C:\xampp\htdocs\school_ms\system\core\Loader.php 344
DEBUG - 2017-06-27 02:29:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:29:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:29:33 --> Session Class Initialized
DEBUG - 2017-06-27 02:29:33 --> Session routines successfully run
DEBUG - 2017-06-27 02:29:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:29:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:29:33 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 02:29:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Result_pin_model C:\xampp\htdocs\school_ms\system\core\Loader.php 344
DEBUG - 2017-06-27 02:29:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:29:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:29:49 --> Session Class Initialized
DEBUG - 2017-06-27 02:29:49 --> Session routines successfully run
DEBUG - 2017-06-27 02:29:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:29:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:29:49 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 02:29:49 --> Severity: error --> Exception: Unable to locate the model you have specified: Result_pins_model C:\xampp\htdocs\school_ms\system\core\Loader.php 344
DEBUG - 2017-06-27 02:30:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:30:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:30:33 --> Session Class Initialized
DEBUG - 2017-06-27 02:30:33 --> Session routines successfully run
DEBUG - 2017-06-27 02:30:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:30:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:30:33 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 02:30:34 --> Severity: error --> Exception: Call to undefined method Result_pins_model::check_if_valid() C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 20
DEBUG - 2017-06-27 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:30:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:30:56 --> Session Class Initialized
DEBUG - 2017-06-27 02:30:56 --> Session routines successfully run
DEBUG - 2017-06-27 02:30:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:30:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:30:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:30:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:30:56 --> Total execution time: 0.1713
DEBUG - 2017-06-27 02:31:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:31:19 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:31:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:31:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:31:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:31:20 --> Total execution time: 0.1324
DEBUG - 2017-06-27 02:31:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:31:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:31:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:31:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:31:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:31:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:31:20 --> Session Class Initialized
DEBUG - 2017-06-27 02:31:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:31:20 --> Session routines successfully run
DEBUG - 2017-06-27 02:31:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:31:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:31:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:31:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:31:24 --> Session Class Initialized
DEBUG - 2017-06-27 02:31:24 --> Session routines successfully run
DEBUG - 2017-06-27 02:31:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:31:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:31:24 --> Total execution time: 0.2204
DEBUG - 2017-06-27 02:33:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:05 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:05 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:05 --> Total execution time: 0.1361
DEBUG - 2017-06-27 02:33:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:06 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:06 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:06 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:06 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:06 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:06 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:09 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:09 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:09 --> Total execution time: 0.1681
DEBUG - 2017-06-27 02:33:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:49 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:49 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:49 --> Total execution time: 0.1215
DEBUG - 2017-06-27 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:50 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:50 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:50 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:50 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:50 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:50 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:33:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:33:57 --> Session Class Initialized
DEBUG - 2017-06-27 02:33:57 --> Session routines successfully run
DEBUG - 2017-06-27 02:33:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:33:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:33:57 --> Total execution time: 0.1543
DEBUG - 2017-06-27 02:38:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:00 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:00 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:00 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:00 --> Total execution time: 0.1396
DEBUG - 2017-06-27 02:38:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:01 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:01 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:05 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:05 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:55 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:55 --> No URI present. Default controller set.
DEBUG - 2017-06-27 02:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:55 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:55 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:55 --> Total execution time: 0.1668
DEBUG - 2017-06-27 02:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:38:56 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:38:56 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:56 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:56 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:56 --> Session Class Initialized
DEBUG - 2017-06-27 02:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:56 --> Session routines successfully run
DEBUG - 2017-06-27 02:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:38:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:38:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:39:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:39:03 --> Session Class Initialized
DEBUG - 2017-06-27 02:39:03 --> Session routines successfully run
DEBUG - 2017-06-27 02:39:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:39:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:39:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:39:41 --> Session Class Initialized
DEBUG - 2017-06-27 02:39:41 --> Session routines successfully run
DEBUG - 2017-06-27 02:39:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:39:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:39:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:53:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 02:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 02:53:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 02:53:37 --> Session Class Initialized
DEBUG - 2017-06-27 02:53:37 --> Session routines successfully run
DEBUG - 2017-06-27 02:53:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 02:53:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:53:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 02:53:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 03:47:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 03:47:00 --> No URI present. Default controller set.
DEBUG - 2017-06-27 03:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 03:47:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 03:47:01 --> Session Class Initialized
DEBUG - 2017-06-27 03:47:01 --> Session routines successfully run
DEBUG - 2017-06-27 03:47:01 --> Total execution time: 1.0242
DEBUG - 2017-06-27 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 03:47:02 --> Session Class Initialized
DEBUG - 2017-06-27 03:47:02 --> Session routines successfully run
DEBUG - 2017-06-27 03:47:02 --> Session Class Initialized
DEBUG - 2017-06-27 03:47:02 --> Session Class Initialized
DEBUG - 2017-06-27 03:47:02 --> Session routines successfully run
DEBUG - 2017-06-27 03:47:02 --> Session routines successfully run
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 03:47:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 03:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 03:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 03:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 03:47:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:52 --> No URI present. Default controller set.
DEBUG - 2017-06-27 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:52 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:52 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:52 --> Total execution time: 0.8099
DEBUG - 2017-06-27 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:53 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:53 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:53 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:53 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:53 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:53 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:21:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:21:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:56 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:56 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:21:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:21:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:21:57 --> Session Class Initialized
DEBUG - 2017-06-27 04:21:57 --> Session routines successfully run
DEBUG - 2017-06-27 04:21:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:21:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:21:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:22:01 --> Session Class Initialized
DEBUG - 2017-06-27 04:22:01 --> Session routines successfully run
DEBUG - 2017-06-27 04:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 04:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:33 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:33 --> Session routines successfully run
ERROR - 2017-06-27 04:23:33 --> Severity: Notice --> Undefined property: JWT::$hashing_algorithm C:\xampp\htdocs\school_ms\application\libraries\JWT.php 20
DEBUG - 2017-06-27 04:23:33 --> Total execution time: 0.1820
DEBUG - 2017-06-27 04:23:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:34 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:34 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
ERROR - 2017-06-27 04:23:34 --> Severity: Notice --> Undefined property: JWT::$hashing_algorithm C:\xampp\htdocs\school_ms\application\libraries\JWT.php 20
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:34 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:34 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:34 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:34 --> Session routines successfully run
ERROR - 2017-06-27 04:23:34 --> Severity: Notice --> Undefined property: JWT::$hashing_algorithm C:\xampp\htdocs\school_ms\application\libraries\JWT.php 20
DEBUG - 2017-06-27 04:23:34 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:23:34 --> Severity: Notice --> Undefined property: JWT::$hashing_algorithm C:\xampp\htdocs\school_ms\application\libraries\JWT.php 20
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:54 --> No URI present. Default controller set.
DEBUG - 2017-06-27 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:54 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:54 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:54 --> Total execution time: 0.1222
DEBUG - 2017-06-27 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:23:54 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:23:54 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:23:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:54 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:54 --> Session Class Initialized
DEBUG - 2017-06-27 04:23:54 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:54 --> Session routines successfully run
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:23:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:23:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:24:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:24:00 --> Session Class Initialized
DEBUG - 2017-06-27 04:24:00 --> Session routines successfully run
DEBUG - 2017-06-27 04:24:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:24:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:24:12 --> Session Class Initialized
DEBUG - 2017-06-27 04:24:12 --> Session routines successfully run
DEBUG - 2017-06-27 04:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:24:12 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:24:12 --> Severity: Warning --> base64_encode() expects parameter 1 to be string, array given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 27
ERROR - 2017-06-27 04:24:12 --> Severity: Warning --> base64_encode() expects parameter 1 to be string, array given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 28
ERROR - 2017-06-27 04:24:12 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 1 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 30
DEBUG - 2017-06-27 04:26:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:26:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:26:05 --> Session Class Initialized
DEBUG - 2017-06-27 04:26:05 --> Session routines successfully run
DEBUG - 2017-06-27 04:26:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:26:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:26:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:26:05 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:26:05 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 1 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 33
DEBUG - 2017-06-27 04:28:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:28:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:28:52 --> Session Class Initialized
DEBUG - 2017-06-27 04:28:53 --> Session routines successfully run
DEBUG - 2017-06-27 04:28:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:28:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:28:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:28:53 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:28:53 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 2 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 34
ERROR - 2017-06-27 04:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-06-27 04:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-06-27 04:28:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-06-27 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:28:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:28:57 --> Session Class Initialized
DEBUG - 2017-06-27 04:28:57 --> Session routines successfully run
DEBUG - 2017-06-27 04:28:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:28:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:28:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:28:57 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:28:57 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 2 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 34
ERROR - 2017-06-27 04:28:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-06-27 04:28:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-06-27 04:28:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:28) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-06-27 04:30:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:30:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:30:37 --> Session Class Initialized
DEBUG - 2017-06-27 04:30:37 --> Session routines successfully run
DEBUG - 2017-06-27 04:30:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:30:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:37 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:30:37 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 2 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 37
ERROR - 2017-06-27 04:30:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:31) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 491
ERROR - 2017-06-27 04:30:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:31) C:\xampp\htdocs\school_ms\system\core\Common.php 573
ERROR - 2017-06-27 04:30:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\school_ms\application\libraries\JWT.php:31) C:\xampp\htdocs\school_ms\application\libraries\REST_Controller.php 514
DEBUG - 2017-06-27 04:30:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:30:47 --> Session Class Initialized
DEBUG - 2017-06-27 04:30:47 --> Session routines successfully run
DEBUG - 2017-06-27 04:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:47 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:30:47 --> Severity: Warning --> openssl_public_encrypt() expects at least 3 parameters, 2 given C:\xampp\htdocs\school_ms\application\libraries\JWT.php 36
DEBUG - 2017-06-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:30:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:30:58 --> Session Class Initialized
DEBUG - 2017-06-27 04:30:58 --> Session routines successfully run
DEBUG - 2017-06-27 04:30:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:30:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:30:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:30:58 --> Severity: Warning --> openssl_public_encrypt(): key parameter is not a valid public key C:\xampp\htdocs\school_ms\application\libraries\JWT.php 36
DEBUG - 2017-06-27 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:31:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:31:00 --> Session Class Initialized
DEBUG - 2017-06-27 04:31:00 --> Session routines successfully run
DEBUG - 2017-06-27 04:31:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:31:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:31:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:31:00 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:31:00 --> Severity: Warning --> openssl_public_encrypt(): key parameter is not a valid public key C:\xampp\htdocs\school_ms\application\libraries\JWT.php 36
DEBUG - 2017-06-27 04:40:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:40:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:40:05 --> Session Class Initialized
DEBUG - 2017-06-27 04:40:05 --> Session routines successfully run
ERROR - 2017-06-27 04:40:05 --> Non-existent class: Jwt
DEBUG - 2017-06-27 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:40:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:40:35 --> Session Class Initialized
DEBUG - 2017-06-27 04:40:35 --> Session routines successfully run
ERROR - 2017-06-27 04:40:35 --> Non-existent class: Jwt
DEBUG - 2017-06-27 04:40:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:40:36 --> Session Class Initialized
DEBUG - 2017-06-27 04:40:36 --> Session routines successfully run
ERROR - 2017-06-27 04:40:36 --> Non-existent class: Jwt
DEBUG - 2017-06-27 04:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:41:19 --> Session Class Initialized
DEBUG - 2017-06-27 04:41:19 --> Session routines successfully run
DEBUG - 2017-06-27 04:41:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:41:19 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:41:19 --> Severity: Notice --> Undefined property: Parents::$jwt C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
ERROR - 2017-06-27 04:41:19 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
DEBUG - 2017-06-27 04:42:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:42:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:42:06 --> Session Class Initialized
DEBUG - 2017-06-27 04:42:06 --> Session routines successfully run
DEBUG - 2017-06-27 04:42:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:06 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:42:06 --> Severity: Notice --> Undefined property: Parents::$jwt C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
ERROR - 2017-06-27 04:42:06 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
DEBUG - 2017-06-27 04:42:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:42:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:42:44 --> Session Class Initialized
DEBUG - 2017-06-27 04:42:44 --> Session routines successfully run
DEBUG - 2017-06-27 04:42:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:42:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:44 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:42:44 --> Severity: Notice --> Undefined property: Parents::$jwt C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
ERROR - 2017-06-27 04:42:44 --> Severity: error --> Exception: Call to a member function encode() on null C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 22
DEBUG - 2017-06-27 04:42:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:42:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:42:54 --> Session Class Initialized
DEBUG - 2017-06-27 04:42:54 --> Session routines successfully run
DEBUG - 2017-06-27 04:42:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:42:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:42:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:47:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:47:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:47:04 --> Session Class Initialized
DEBUG - 2017-06-27 04:47:04 --> Session routines successfully run
DEBUG - 2017-06-27 04:47:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:47:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:47:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:47:04 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:47:04 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 24
ERROR - 2017-06-27 04:47:04 --> Severity: Warning --> Illegal string offset 'student_name' C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 28
ERROR - 2017-06-27 04:47:04 --> Severity: Warning --> Illegal string offset 'student_name' C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 28
DEBUG - 2017-06-27 04:50:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:50:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:50:13 --> Session Class Initialized
DEBUG - 2017-06-27 04:50:13 --> Session routines successfully run
DEBUG - 2017-06-27 04:50:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:50:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:50:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:50:13 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:50:13 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 24
DEBUG - 2017-06-27 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:50:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:50:49 --> Session Class Initialized
DEBUG - 2017-06-27 04:50:49 --> Session routines successfully run
DEBUG - 2017-06-27 04:50:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:50:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:50:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:50:49 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:50:49 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 25
DEBUG - 2017-06-27 04:51:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:51:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:51:29 --> Session Class Initialized
DEBUG - 2017-06-27 04:51:29 --> Session routines successfully run
DEBUG - 2017-06-27 04:51:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:51:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:51:29 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:51:29 --> Severity: Notice --> Undefined offset: 0 C:\xampp\htdocs\school_ms\application\controllers\api\Parents.php 25
DEBUG - 2017-06-27 04:51:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:51:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:51:43 --> Session Class Initialized
DEBUG - 2017-06-27 04:51:43 --> Session routines successfully run
DEBUG - 2017-06-27 04:51:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:51:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:51:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:51:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:52:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:52:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:52:24 --> Session Class Initialized
DEBUG - 2017-06-27 04:52:24 --> Session routines successfully run
DEBUG - 2017-06-27 04:52:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:52:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:52:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:52:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:54:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:54:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:54:58 --> Session Class Initialized
DEBUG - 2017-06-27 04:54:58 --> Session routines successfully run
DEBUG - 2017-06-27 04:54:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:54:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:54:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:54:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:54:58 --> Severity: error --> Exception: Algorithm not supported C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 191
DEBUG - 2017-06-27 04:55:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:55:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:55:30 --> Session Class Initialized
DEBUG - 2017-06-27 04:55:30 --> Session routines successfully run
DEBUG - 2017-06-27 04:55:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:55:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:30 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:55:30 --> Severity: Warning --> openssl_sign(): supplied key param cannot be coerced into a private key C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 199
ERROR - 2017-06-27 04:55:30 --> Severity: error --> Exception: OpenSSL unable to sign data C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 201
DEBUG - 2017-06-27 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:55:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:55:34 --> Session Class Initialized
DEBUG - 2017-06-27 04:55:34 --> Session routines successfully run
DEBUG - 2017-06-27 04:55:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:55:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:34 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:55:34 --> Severity: Warning --> openssl_sign(): supplied key param cannot be coerced into a private key C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 199
ERROR - 2017-06-27 04:55:34 --> Severity: error --> Exception: OpenSSL unable to sign data C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 201
DEBUG - 2017-06-27 04:55:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:55:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:55:47 --> Session Class Initialized
DEBUG - 2017-06-27 04:55:47 --> Session routines successfully run
DEBUG - 2017-06-27 04:55:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:55:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:55:47 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:55:47 --> Severity: Warning --> openssl_sign(): supplied key param cannot be coerced into a private key C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 199
ERROR - 2017-06-27 04:55:47 --> Severity: error --> Exception: OpenSSL unable to sign data C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 201
DEBUG - 2017-06-27 04:56:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:56:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:56:58 --> Session Class Initialized
DEBUG - 2017-06-27 04:56:58 --> Session routines successfully run
DEBUG - 2017-06-27 04:56:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:56:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:56:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:56:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-27 04:56:58 --> Severity: Warning --> openssl_sign(): supplied key param cannot be coerced into a private key C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 199
ERROR - 2017-06-27 04:56:58 --> Severity: error --> Exception: OpenSSL unable to sign data C:\xampp\htdocs\school_ms\application\libraries\jwt\JWT.php 201
DEBUG - 2017-06-27 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 04:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 04:57:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 04:57:28 --> Session Class Initialized
DEBUG - 2017-06-27 04:57:28 --> Session routines successfully run
DEBUG - 2017-06-27 04:57:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 04:57:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:57:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 04:57:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:02:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:02:03 --> Session Class Initialized
DEBUG - 2017-06-27 05:02:03 --> Session routines successfully run
DEBUG - 2017-06-27 05:02:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:02:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:02:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:02:04 --> Session Class Initialized
DEBUG - 2017-06-27 05:02:04 --> Session routines successfully run
DEBUG - 2017-06-27 05:02:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:02:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:02:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:03:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:03:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:03:24 --> Session Class Initialized
DEBUG - 2017-06-27 05:03:24 --> Session routines successfully run
DEBUG - 2017-06-27 05:03:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:03:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:03:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:03:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:04:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:04:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:04:22 --> Session Class Initialized
DEBUG - 2017-06-27 05:04:22 --> Session routines successfully run
DEBUG - 2017-06-27 05:04:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:04:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:04:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:04:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:07:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:07:56 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:07:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:07:56 --> Session Class Initialized
DEBUG - 2017-06-27 05:07:56 --> Session routines successfully run
DEBUG - 2017-06-27 05:07:56 --> Total execution time: 0.1275
DEBUG - 2017-06-27 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:07:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:07:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:07:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:07:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:07:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:07:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:07:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:07:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:07:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:07:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:07:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:07:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:01 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:01 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:08:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:04 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:04 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:08:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:26 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:26 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:26 --> Total execution time: 0.1251
DEBUG - 2017-06-27 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:08:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:08:26 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:08:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:08:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:26 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:08:27 --> Session routines successfully run
DEBUG - 2017-06-27 05:08:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:08:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:08:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:08:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:01 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:01 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:01 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:01 --> Total execution time: 0.1293
DEBUG - 2017-06-27 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:02 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:02 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:02 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:02 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:02 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:02 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:06 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:06 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:31 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:31 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:31 --> Total execution time: 0.1376
DEBUG - 2017-06-27 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:32 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:32 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:32 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:32 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:32 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:32 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:37 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:37 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:09:39 --> Session Class Initialized
DEBUG - 2017-06-27 05:09:39 --> Session routines successfully run
DEBUG - 2017-06-27 05:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:30 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:30 --> Total execution time: 0.1194
DEBUG - 2017-06-27 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:31 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:31 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:31 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:31 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:31 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:31 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:35 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:35 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:40 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:40 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:13:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:13:54 --> Session Class Initialized
DEBUG - 2017-06-27 05:13:54 --> Session routines successfully run
DEBUG - 2017-06-27 05:13:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:13:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:13:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:39 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:39 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:14:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:42 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:42 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:42 --> Total execution time: 0.1129
DEBUG - 2017-06-27 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:42 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:42 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:14:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:42 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:42 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:42 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:14:43 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:14:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:14:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:14:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:14:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:14:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:13 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:13 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:13 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:13 --> Total execution time: 0.1280
DEBUG - 2017-06-27 05:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:14 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:14 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:14 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:14 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:14 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:14 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:19 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:19 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:47 --> Total execution time: 0.1136
DEBUG - 2017-06-27 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:17:50 --> Session Class Initialized
DEBUG - 2017-06-27 05:17:50 --> Session routines successfully run
DEBUG - 2017-06-27 05:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:18:19 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:18:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:18:19 --> Session Class Initialized
DEBUG - 2017-06-27 05:18:19 --> Session routines successfully run
DEBUG - 2017-06-27 05:18:19 --> Total execution time: 0.1373
DEBUG - 2017-06-27 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:18:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:18:19 --> Session Class Initialized
DEBUG - 2017-06-27 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:18:19 --> Session routines successfully run
DEBUG - 2017-06-27 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:18:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:18:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:18:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:18:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:18:19 --> Session Class Initialized
DEBUG - 2017-06-27 05:18:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:18:20 --> Session Class Initialized
DEBUG - 2017-06-27 05:18:20 --> Session routines successfully run
DEBUG - 2017-06-27 05:18:20 --> Session routines successfully run
DEBUG - 2017-06-27 05:18:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:18:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:18:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:18:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:29 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:29 --> Total execution time: 0.1326
DEBUG - 2017-06-27 05:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:32 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:32 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:47 --> Total execution time: 0.1430
DEBUG - 2017-06-27 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:22:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:22:56 --> Session Class Initialized
DEBUG - 2017-06-27 05:22:56 --> Session routines successfully run
DEBUG - 2017-06-27 05:22:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:22:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:22:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:14 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:14 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:14 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:14 --> Total execution time: 0.1333
DEBUG - 2017-06-27 05:32:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:15 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:15 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:15 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:15 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:15 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:15 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:37 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:37 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:37 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:37 --> Total execution time: 0.1195
DEBUG - 2017-06-27 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:38 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:38 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:38 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:38 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:38 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:38 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:57 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:57 --> Total execution time: 0.1152
DEBUG - 2017-06-27 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:32:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:32:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:36:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:36:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:36:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:36:33 --> Session Class Initialized
DEBUG - 2017-06-27 05:36:33 --> Session routines successfully run
DEBUG - 2017-06-27 05:36:33 --> Total execution time: 0.1268
DEBUG - 2017-06-27 05:37:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:37:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:37:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:37:05 --> Session Class Initialized
DEBUG - 2017-06-27 05:37:05 --> Session routines successfully run
DEBUG - 2017-06-27 05:37:05 --> Total execution time: 0.1318
DEBUG - 2017-06-27 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:37:23 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:37:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:37:23 --> Session Class Initialized
DEBUG - 2017-06-27 05:37:23 --> Session routines successfully run
DEBUG - 2017-06-27 05:37:23 --> Total execution time: 0.1236
DEBUG - 2017-06-27 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:37:24 --> Session Class Initialized
DEBUG - 2017-06-27 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:37:24 --> Session routines successfully run
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:37:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:37:24 --> Session Class Initialized
DEBUG - 2017-06-27 05:37:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:37:24 --> Session Class Initialized
DEBUG - 2017-06-27 05:37:24 --> Session routines successfully run
DEBUG - 2017-06-27 05:37:24 --> Session routines successfully run
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:37:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:37:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:37:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:39:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:39:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:39:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:39:05 --> Session Class Initialized
DEBUG - 2017-06-27 05:39:05 --> Session routines successfully run
DEBUG - 2017-06-27 05:39:05 --> Total execution time: 0.1279
DEBUG - 2017-06-27 05:39:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:39:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:39:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:39:15 --> Session Class Initialized
DEBUG - 2017-06-27 05:39:15 --> Session routines successfully run
DEBUG - 2017-06-27 05:39:15 --> Total execution time: 0.1280
DEBUG - 2017-06-27 05:39:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:39:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:39:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:39:40 --> Session Class Initialized
DEBUG - 2017-06-27 05:39:40 --> Session routines successfully run
DEBUG - 2017-06-27 05:39:40 --> Total execution time: 0.1308
DEBUG - 2017-06-27 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:43:38 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:43:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:43:38 --> Session Class Initialized
DEBUG - 2017-06-27 05:43:38 --> Session routines successfully run
DEBUG - 2017-06-27 05:43:38 --> Total execution time: 0.1462
DEBUG - 2017-06-27 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:43:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:43:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:43:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:43:39 --> Session Class Initialized
DEBUG - 2017-06-27 05:43:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:43:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:43:39 --> Session routines successfully run
DEBUG - 2017-06-27 05:43:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:43:39 --> Session Class Initialized
DEBUG - 2017-06-27 05:43:39 --> Session Class Initialized
DEBUG - 2017-06-27 05:43:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:39 --> Session routines successfully run
DEBUG - 2017-06-27 05:43:39 --> Session routines successfully run
DEBUG - 2017-06-27 05:43:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:43:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:43:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:43:57 --> Session Class Initialized
DEBUG - 2017-06-27 05:43:57 --> Session routines successfully run
DEBUG - 2017-06-27 05:43:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:43:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:44:46 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:44:46 --> Session Class Initialized
DEBUG - 2017-06-27 05:44:46 --> Session routines successfully run
DEBUG - 2017-06-27 05:44:46 --> Total execution time: 0.1558
DEBUG - 2017-06-27 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:44:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:44:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:44:46 --> Session Class Initialized
DEBUG - 2017-06-27 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:44:46 --> Session routines successfully run
DEBUG - 2017-06-27 05:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:44:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:44:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:44:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:44:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:44:58 --> Session Class Initialized
DEBUG - 2017-06-27 05:44:58 --> Session routines successfully run
DEBUG - 2017-06-27 05:44:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:44:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:44:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:45:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:45:05 --> Session Class Initialized
DEBUG - 2017-06-27 05:45:05 --> Session routines successfully run
DEBUG - 2017-06-27 05:45:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:45:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:45:48 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:45:48 --> Session Class Initialized
DEBUG - 2017-06-27 05:45:48 --> Session routines successfully run
DEBUG - 2017-06-27 05:45:48 --> Total execution time: 0.1139
DEBUG - 2017-06-27 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:45:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:45:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:45:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:45:49 --> Session Class Initialized
DEBUG - 2017-06-27 05:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:45:49 --> Session routines successfully run
DEBUG - 2017-06-27 05:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:49 --> Session Class Initialized
DEBUG - 2017-06-27 05:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:49 --> Session Class Initialized
DEBUG - 2017-06-27 05:45:49 --> Session routines successfully run
DEBUG - 2017-06-27 05:45:49 --> Session routines successfully run
DEBUG - 2017-06-27 05:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:45:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:45:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:46:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:46:36 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:46:36 --> Session Class Initialized
DEBUG - 2017-06-27 05:46:36 --> Session routines successfully run
DEBUG - 2017-06-27 05:46:36 --> Total execution time: 0.1365
DEBUG - 2017-06-27 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:46:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:46:36 --> Session Class Initialized
DEBUG - 2017-06-27 05:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:46:36 --> Session routines successfully run
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:46:36 --> Session Class Initialized
DEBUG - 2017-06-27 05:46:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:46:36 --> Session Class Initialized
DEBUG - 2017-06-27 05:46:36 --> Session routines successfully run
DEBUG - 2017-06-27 05:46:36 --> Session routines successfully run
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:46:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:46:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:46:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:46:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:22 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:22 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:22 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:22 --> Total execution time: 0.1474
DEBUG - 2017-06-27 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:23 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:23 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:23 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:23 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:23 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:23 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:51 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:51 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:51 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:51 --> Total execution time: 0.1270
DEBUG - 2017-06-27 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:47:51 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:47:51 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:51 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:51 --> Session Class Initialized
DEBUG - 2017-06-27 05:47:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:51 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:51 --> Session routines successfully run
DEBUG - 2017-06-27 05:47:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:47:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:47:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:48:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:48:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:48:15 --> Session Class Initialized
DEBUG - 2017-06-27 05:48:15 --> Session routines successfully run
DEBUG - 2017-06-27 05:48:15 --> Total execution time: 0.1160
DEBUG - 2017-06-27 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:48:16 --> Session Class Initialized
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:48:16 --> Session routines successfully run
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:48:16 --> Session Class Initialized
DEBUG - 2017-06-27 05:48:16 --> Session Class Initialized
DEBUG - 2017-06-27 05:48:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:48:16 --> Session routines successfully run
DEBUG - 2017-06-27 05:48:16 --> Session routines successfully run
DEBUG - 2017-06-27 05:48:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:48:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:48:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:48:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:49:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:49:52 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:49:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:49:52 --> Session Class Initialized
DEBUG - 2017-06-27 05:49:52 --> Session routines successfully run
DEBUG - 2017-06-27 05:49:52 --> Total execution time: 0.1281
DEBUG - 2017-06-27 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:49:53 --> Session Class Initialized
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:49:53 --> Session routines successfully run
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:49:53 --> Session Class Initialized
DEBUG - 2017-06-27 05:49:53 --> Session Class Initialized
DEBUG - 2017-06-27 05:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:49:53 --> Session routines successfully run
DEBUG - 2017-06-27 05:49:53 --> Session routines successfully run
DEBUG - 2017-06-27 05:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:25 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:25 --> Total execution time: 0.1154
DEBUG - 2017-06-27 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:46 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:46 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:46 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:46 --> Total execution time: 0.1239
DEBUG - 2017-06-27 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:50:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:50:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:47 --> Session Class Initialized
DEBUG - 2017-06-27 05:50:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:47 --> Session routines successfully run
DEBUG - 2017-06-27 05:50:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:50:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:50:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:11 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:11 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:11 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:11 --> Total execution time: 0.1283
DEBUG - 2017-06-27 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:12 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:12 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:12 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:12 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:12 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:12 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:21 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:21 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:21 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:21 --> Total execution time: 0.1216
DEBUG - 2017-06-27 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:22 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:22 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:22 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:22 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:22 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:22 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:51:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:51:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:51:54 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:51:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:51:54 --> Session Class Initialized
DEBUG - 2017-06-27 05:51:54 --> Session routines successfully run
DEBUG - 2017-06-27 05:51:54 --> Total execution time: 0.1423
DEBUG - 2017-06-27 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:53:25 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:53:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:53:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:53:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:53:25 --> Total execution time: 0.1276
DEBUG - 2017-06-27 05:55:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:55:01 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:55:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:55:01 --> Session Class Initialized
DEBUG - 2017-06-27 05:55:01 --> Session routines successfully run
DEBUG - 2017-06-27 05:55:01 --> Total execution time: 0.1237
DEBUG - 2017-06-27 05:56:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:56:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:56:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:56:53 --> Session Class Initialized
DEBUG - 2017-06-27 05:56:53 --> Session routines successfully run
DEBUG - 2017-06-27 05:56:53 --> Total execution time: 0.1290
DEBUG - 2017-06-27 05:56:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:56:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:56:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:56:54 --> Session Class Initialized
DEBUG - 2017-06-27 05:56:54 --> Session routines successfully run
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:56:54 --> Session Class Initialized
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:56:54 --> Session routines successfully run
DEBUG - 2017-06-27 05:56:54 --> Session Class Initialized
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:56:54 --> Session routines successfully run
DEBUG - 2017-06-27 05:56:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:56:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:56:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:56:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:56:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:57:26 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:57:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:57:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:57:26 --> Session routines successfully run
DEBUG - 2017-06-27 05:57:26 --> Total execution time: 0.1445
DEBUG - 2017-06-27 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:57:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:57:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:57:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:57:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:57:26 --> Session routines successfully run
DEBUG - 2017-06-27 05:57:26 --> Session Class Initialized
DEBUG - 2017-06-27 05:57:27 --> Session routines successfully run
DEBUG - 2017-06-27 05:57:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:57:27 --> Session Class Initialized
DEBUG - 2017-06-27 05:57:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:57:27 --> Session routines successfully run
DEBUG - 2017-06-27 05:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:57:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:57:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:24 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:24 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:24 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:24 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:24 --> Total execution time: 0.1389
DEBUG - 2017-06-27 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:25 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:25 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:29 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:29 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:29 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:29 --> Total execution time: 0.1309
DEBUG - 2017-06-27 05:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:29 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:29 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:29 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:29 --> Total execution time: 0.1232
DEBUG - 2017-06-27 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:30 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:30 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 05:59:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 05:59:44 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 05:59:44 --> No URI present. Default controller set.
DEBUG - 2017-06-27 05:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 05:59:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 05:59:44 --> Session Class Initialized
DEBUG - 2017-06-27 05:59:44 --> Session routines successfully run
DEBUG - 2017-06-27 05:59:44 --> Total execution time: 0.1295
DEBUG - 2017-06-27 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:01 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:01 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:01 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:01 --> Total execution time: 0.1266
DEBUG - 2017-06-27 06:00:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:12 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:12 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:12 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:12 --> Total execution time: 0.1235
DEBUG - 2017-06-27 06:00:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:37 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:37 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:37 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:37 --> Total execution time: 0.1307
DEBUG - 2017-06-27 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:38 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:38 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:38 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:38 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:38 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:38 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:46 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:46 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:46 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:46 --> Total execution time: 0.1406
DEBUG - 2017-06-27 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:52 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:52 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:52 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:52 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:52 --> Total execution time: 0.1280
DEBUG - 2017-06-27 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:53 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:53 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:53 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:53 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:53 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:53 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:56 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:56 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:56 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:56 --> Total execution time: 0.1270
DEBUG - 2017-06-27 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:00:56 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:00:56 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:56 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:56 --> Session Class Initialized
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:56 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:56 --> Session routines successfully run
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:00:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:00:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:03 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:03 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:03 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:03 --> Total execution time: 0.1222
DEBUG - 2017-06-27 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:03 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:03 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:03 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:03 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:03 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:03 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:15 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:15 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:15 --> Total execution time: 0.1189
DEBUG - 2017-06-27 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:17 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:17 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:17 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:17 --> Total execution time: 0.1443
DEBUG - 2017-06-27 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:18 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:18 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:18 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:18 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:18 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:18 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:22 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:22 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:22 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:22 --> Total execution time: 0.1289
DEBUG - 2017-06-27 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:01:23 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:01:23 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:23 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:23 --> Session Class Initialized
DEBUG - 2017-06-27 06:01:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:23 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:23 --> Session routines successfully run
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:01:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:01:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:10 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:10 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:10 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:10 --> Total execution time: 0.1305
DEBUG - 2017-06-27 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:10 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:10 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:11 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:11 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:11 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:11 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:20 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:20 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:42 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:42 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:42 --> Total execution time: 0.1472
DEBUG - 2017-06-27 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:43 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:43 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:43 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:43 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:43 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:43 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:43 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:02:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:02:53 --> Session Class Initialized
DEBUG - 2017-06-27 06:02:53 --> Session routines successfully run
DEBUG - 2017-06-27 06:02:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:02:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:02:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:06:04 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:06:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:06:04 --> Session Class Initialized
DEBUG - 2017-06-27 06:06:04 --> Session routines successfully run
DEBUG - 2017-06-27 06:06:05 --> Total execution time: 0.1233
DEBUG - 2017-06-27 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:06:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:06:05 --> Session Class Initialized
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:06:05 --> Session routines successfully run
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:06:05 --> Session Class Initialized
DEBUG - 2017-06-27 06:06:05 --> Session Class Initialized
DEBUG - 2017-06-27 06:06:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:06:05 --> Session routines successfully run
DEBUG - 2017-06-27 06:06:05 --> Session routines successfully run
DEBUG - 2017-06-27 06:06:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:06:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:06:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:06:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:08:46 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:08:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:08:46 --> Session Class Initialized
DEBUG - 2017-06-27 06:08:46 --> Session routines successfully run
DEBUG - 2017-06-27 06:08:46 --> Total execution time: 0.1822
DEBUG - 2017-06-27 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:08:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:08:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:08:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:08:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:08:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:08:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:08:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:08:47 --> Session Class Initialized
DEBUG - 2017-06-27 06:08:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:08:47 --> Session routines successfully run
DEBUG - 2017-06-27 06:08:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:08:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:08:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:09:36 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:09:36 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:09:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:09:36 --> Session Class Initialized
DEBUG - 2017-06-27 06:09:36 --> Session routines successfully run
DEBUG - 2017-06-27 06:09:36 --> Total execution time: 0.1643
DEBUG - 2017-06-27 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:09:37 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:09:37 --> Session Class Initialized
DEBUG - 2017-06-27 06:09:37 --> Session routines successfully run
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:09:37 --> Session Class Initialized
DEBUG - 2017-06-27 06:09:37 --> Session Class Initialized
DEBUG - 2017-06-27 06:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:09:37 --> Session routines successfully run
DEBUG - 2017-06-27 06:09:37 --> Session routines successfully run
DEBUG - 2017-06-27 06:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:09:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:09:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:01 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:01 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:01 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:01 --> Total execution time: 0.1913
DEBUG - 2017-06-27 06:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:02 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:02 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:02 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:02 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:02 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:02 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:49 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:49 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:49 --> Total execution time: 0.1781
DEBUG - 2017-06-27 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:10:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:10:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:49 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:10:50 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:50 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:50 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:50 --> Session Class Initialized
DEBUG - 2017-06-27 06:10:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:50 --> Session routines successfully run
DEBUG - 2017-06-27 06:10:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:10:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:10:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:15 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:15 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:15 --> Total execution time: 0.1483
DEBUG - 2017-06-27 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:16 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:16 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:34 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:34 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:34 --> Total execution time: 0.1599
DEBUG - 2017-06-27 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:12:35 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:12:35 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:35 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:35 --> Session Class Initialized
DEBUG - 2017-06-27 06:12:35 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:35 --> Session routines successfully run
DEBUG - 2017-06-27 06:12:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:12:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:12:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:33 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:33 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:33 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:33 --> Total execution time: 0.1624
DEBUG - 2017-06-27 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:33 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:33 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:34 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:34 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:34 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:34 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:42 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:42 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:42 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:42 --> Total execution time: 0.1538
DEBUG - 2017-06-27 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:42 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:19:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:42 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:19:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:42 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:43 --> Session Class Initialized
DEBUG - 2017-06-27 06:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:43 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:43 --> Session routines successfully run
DEBUG - 2017-06-27 06:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:19:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:20:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:20:40 --> Session Class Initialized
DEBUG - 2017-06-27 06:20:40 --> Session routines successfully run
DEBUG - 2017-06-27 06:20:40 --> Total execution time: 0.1498
DEBUG - 2017-06-27 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:20:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:20:40 --> Session Class Initialized
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:20:40 --> Session routines successfully run
DEBUG - 2017-06-27 06:20:40 --> Session Class Initialized
DEBUG - 2017-06-27 06:20:40 --> Session routines successfully run
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:20:40 --> Session Class Initialized
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:20:40 --> Session routines successfully run
DEBUG - 2017-06-27 06:20:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:20:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:20:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:20:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:20:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:00 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:00 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:00 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:00 --> Total execution time: 0.1541
DEBUG - 2017-06-27 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:01 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:01 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:01 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:01 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:01 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:01 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:12 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:12 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:12 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:12 --> Total execution time: 0.1507
DEBUG - 2017-06-27 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:13 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:13 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:13 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:13 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:13 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:13 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:28 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:28 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:28 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:28 --> Total execution time: 0.1523
DEBUG - 2017-06-27 06:22:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:29 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 06:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 06:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:23:23 --> No URI present. Default controller set.
DEBUG - 2017-06-27 06:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:23:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:23:23 --> Session Class Initialized
DEBUG - 2017-06-27 06:23:23 --> Session routines successfully run
DEBUG - 2017-06-27 06:23:23 --> Total execution time: 0.1458
DEBUG - 2017-06-27 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:23:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 06:23:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 06:23:24 --> Session Class Initialized
DEBUG - 2017-06-27 06:23:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:23:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 06:23:24 --> Session routines successfully run
DEBUG - 2017-06-27 06:23:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:23:24 --> Session Class Initialized
DEBUG - 2017-06-27 06:23:24 --> Session Class Initialized
DEBUG - 2017-06-27 06:23:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:23:24 --> Session routines successfully run
DEBUG - 2017-06-27 06:23:24 --> Session routines successfully run
DEBUG - 2017-06-27 06:23:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:23:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:23:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 06:23:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 06:23:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:16:58 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:16:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:16:59 --> Session Class Initialized
ERROR - 2017-06-27 11:16:59 --> Session: The session cookie was not signed.
DEBUG - 2017-06-27 11:16:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:00 --> Total execution time: 1.3501
DEBUG - 2017-06-27 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:01 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:01 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:01 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:01 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:01 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:49 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:49 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:49 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:49 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:49 --> Total execution time: 0.1750
DEBUG - 2017-06-27 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:50 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:17:50 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:50 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:17:50 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:50 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:50 --> Session Class Initialized
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:50 --> Session routines successfully run
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:17:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:16 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:16 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:16 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:16 --> Total execution time: 0.1639
DEBUG - 2017-06-27 11:20:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:17 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:17 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:17 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:17 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:17 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:17 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:32 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:32 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:32 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:32 --> Total execution time: 0.1611
DEBUG - 2017-06-27 11:20:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:33 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:33 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:20:33 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:33 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:33 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:33 --> Session Class Initialized
DEBUG - 2017-06-27 11:20:33 --> Session routines successfully run
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:20:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:20:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:21:34 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:21:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:21:34 --> Session Class Initialized
DEBUG - 2017-06-27 11:21:34 --> Session routines successfully run
DEBUG - 2017-06-27 11:21:34 --> Total execution time: 0.1701
DEBUG - 2017-06-27 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:21:34 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:21:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:21:34 --> Session Class Initialized
DEBUG - 2017-06-27 11:21:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:21:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:21:34 --> Session routines successfully run
DEBUG - 2017-06-27 11:21:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:21:35 --> Session Class Initialized
DEBUG - 2017-06-27 11:21:35 --> Session Class Initialized
DEBUG - 2017-06-27 11:21:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:21:35 --> Session routines successfully run
DEBUG - 2017-06-27 11:21:35 --> Session routines successfully run
DEBUG - 2017-06-27 11:21:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:21:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:21:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:21:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:21:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:24:56 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:24:56 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:24:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:24:56 --> Session Class Initialized
DEBUG - 2017-06-27 11:24:56 --> Session routines successfully run
DEBUG - 2017-06-27 11:24:56 --> Total execution time: 0.1339
DEBUG - 2017-06-27 11:24:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:24:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:24:57 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:24:57 --> Session Class Initialized
DEBUG - 2017-06-27 11:24:57 --> Session routines successfully run
DEBUG - 2017-06-27 11:24:57 --> Session Class Initialized
DEBUG - 2017-06-27 11:24:57 --> Session Class Initialized
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:24:57 --> Session routines successfully run
DEBUG - 2017-06-27 11:24:57 --> Session routines successfully run
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:24:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:24:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:24:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:24:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:24:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:26:12 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:26:12 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:26:12 --> Session Class Initialized
DEBUG - 2017-06-27 11:26:12 --> Session routines successfully run
DEBUG - 2017-06-27 11:26:12 --> Total execution time: 0.1516
DEBUG - 2017-06-27 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:26:13 --> Session Class Initialized
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:26:13 --> Session routines successfully run
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:26:13 --> Session Class Initialized
DEBUG - 2017-06-27 11:26:13 --> Session Class Initialized
DEBUG - 2017-06-27 11:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:26:13 --> Session routines successfully run
DEBUG - 2017-06-27 11:26:13 --> Session routines successfully run
DEBUG - 2017-06-27 11:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:26:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:26:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:13 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:13 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:13 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:13 --> Total execution time: 0.1677
DEBUG - 2017-06-27 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:13 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:14 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:14 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:14 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:14 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:14 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:14 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:39 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:39 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:39 --> Total execution time: 0.1699
DEBUG - 2017-06-27 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:27:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:27:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:15 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:15 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:15 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:15 --> Total execution time: 0.1537
DEBUG - 2017-06-27 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:16 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:16 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:16 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:16 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:16 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:16 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:16 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:54 --> Total execution time: 0.1399
DEBUG - 2017-06-27 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:28:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:28:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:28:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:28:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:28:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:28:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:29:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:29:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:29:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:29:27 --> Session Class Initialized
DEBUG - 2017-06-27 11:29:27 --> Session routines successfully run
DEBUG - 2017-06-27 11:29:27 --> Total execution time: 0.1487
DEBUG - 2017-06-27 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:29:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:29:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:29:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:29:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:29:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:29:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:29:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:29:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:29:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:29:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:29:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:29:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:32:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:32:22 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:32:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:32:22 --> Session Class Initialized
DEBUG - 2017-06-27 11:32:22 --> Session routines successfully run
DEBUG - 2017-06-27 11:32:22 --> Total execution time: 0.1518
DEBUG - 2017-06-27 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:32:23 --> Session Class Initialized
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:32:23 --> Session routines successfully run
DEBUG - 2017-06-27 11:32:23 --> Session Class Initialized
DEBUG - 2017-06-27 11:32:23 --> Session Class Initialized
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:32:23 --> Session routines successfully run
DEBUG - 2017-06-27 11:32:23 --> Session routines successfully run
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:32:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:32:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:32:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:32:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:32:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:34:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:34:25 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:34:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:34:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:34:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:34:26 --> Total execution time: 0.1976
DEBUG - 2017-06-27 11:35:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:35:10 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:35:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:35:10 --> Session Class Initialized
DEBUG - 2017-06-27 11:35:10 --> Session routines successfully run
DEBUG - 2017-06-27 11:35:10 --> Total execution time: 0.1829
DEBUG - 2017-06-27 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:35:11 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:35:11 --> Session Class Initialized
DEBUG - 2017-06-27 11:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:35:11 --> Session routines successfully run
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:35:11 --> Session Class Initialized
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:35:11 --> Session routines successfully run
DEBUG - 2017-06-27 11:35:11 --> Session Class Initialized
DEBUG - 2017-06-27 11:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:35:11 --> Session routines successfully run
DEBUG - 2017-06-27 11:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:35:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:35:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:40:39 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:40:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:40:39 --> Session Class Initialized
DEBUG - 2017-06-27 11:40:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:40:39 --> Total execution time: 0.1943
DEBUG - 2017-06-27 11:40:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:40:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:40:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:40:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:40:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:40:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:40:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:40:40 --> Session Class Initialized
DEBUG - 2017-06-27 11:40:40 --> Session routines successfully run
DEBUG - 2017-06-27 11:40:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:40:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:41:17 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:41:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:41:17 --> Session Class Initialized
DEBUG - 2017-06-27 11:41:17 --> Session routines successfully run
DEBUG - 2017-06-27 11:41:17 --> Total execution time: 0.1908
DEBUG - 2017-06-27 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:41:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:41:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:41:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:41:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:41:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:41:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:41:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:41:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:41:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:06 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:06 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:06 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:06 --> Total execution time: 0.1901
DEBUG - 2017-06-27 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:07 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:07 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:07 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:07 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:07 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:07 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:07 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:07 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:38 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:38 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:38 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:38 --> Total execution time: 0.1581
DEBUG - 2017-06-27 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:38 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:39 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:39 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:42:39 --> Session Class Initialized
DEBUG - 2017-06-27 11:42:39 --> Session routines successfully run
DEBUG - 2017-06-27 11:42:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:42:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:14 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:45:14 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:45:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:45:14 --> Session Class Initialized
DEBUG - 2017-06-27 11:45:14 --> Session routines successfully run
DEBUG - 2017-06-27 11:45:14 --> Total execution time: 0.1768
DEBUG - 2017-06-27 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:45:15 --> Session Class Initialized
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:45:15 --> Session routines successfully run
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:45:15 --> Session Class Initialized
DEBUG - 2017-06-27 11:45:15 --> Session Class Initialized
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:15 --> Session routines successfully run
DEBUG - 2017-06-27 11:45:15 --> Session routines successfully run
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:15 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:45:15 --> Session Class Initialized
DEBUG - 2017-06-27 11:45:15 --> Session routines successfully run
DEBUG - 2017-06-27 11:45:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:45:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:47 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:47 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:47 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:47 --> Total execution time: 0.1872
DEBUG - 2017-06-27 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:48 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:48 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:48 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:48 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:48 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:48 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:48 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:48 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:53 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:53 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:53 --> Total execution time: 0.1500
DEBUG - 2017-06-27 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:46:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:46:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:47:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:47:58 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:47:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:47:58 --> Session Class Initialized
DEBUG - 2017-06-27 11:47:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:47:59 --> Total execution time: 0.1782
DEBUG - 2017-06-27 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:47:59 --> Session Class Initialized
DEBUG - 2017-06-27 11:47:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:47:59 --> Session Class Initialized
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:47:59 --> Session Class Initialized
DEBUG - 2017-06-27 11:47:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:47:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:47:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:47:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:47:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:47:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:47:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:47:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:48:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:48:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:48:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:48:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:48:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:48:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:48:59 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:48:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:48:59 --> Session Class Initialized
DEBUG - 2017-06-27 11:48:59 --> Session routines successfully run
DEBUG - 2017-06-27 11:48:59 --> Total execution time: 0.1823
DEBUG - 2017-06-27 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:48:59 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:48:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:48:59 --> Session Class Initialized
DEBUG - 2017-06-27 11:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:00 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:53 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:53 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:53 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:53 --> Total execution time: 0.2328
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:54 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:54 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:49:55 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:55 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:55 --> Session Class Initialized
DEBUG - 2017-06-27 11:49:55 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:55 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:55 --> Session routines successfully run
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:25 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:25 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:25 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:25 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:25 --> Total execution time: 0.2401
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Session Class Initialized
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Session routines successfully run
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:50:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:03 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:03 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:03 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:03 --> Total execution time: 0.2013
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Session Class Initialized
DEBUG - 2017-06-27 11:51:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Session routines successfully run
DEBUG - 2017-06-27 11:51:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:51:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:51:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:27 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:27 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:27 --> Total execution time: 0.1797
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Session Class Initialized
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Session routines successfully run
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:54:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:18 --> No URI present. Default controller set.
DEBUG - 2017-06-27 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:18 --> Total execution time: 0.1736
DEBUG - 2017-06-27 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:18 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:18 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:19 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 11:55:19 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:19 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:19 --> Session Class Initialized
DEBUG - 2017-06-27 11:55:19 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:19 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:19 --> Session routines successfully run
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 11:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:38 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:38 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:38 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:38 --> Total execution time: 0.1544
DEBUG - 2017-06-27 12:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:39 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:41 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:41 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:41 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:41 --> Total execution time: 0.1577
DEBUG - 2017-06-27 12:11:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:11:42 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:42 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:42 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:42 --> Session Class Initialized
DEBUG - 2017-06-27 12:11:42 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:42 --> Session routines successfully run
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:11:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:11:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:17:58 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:17:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:17:58 --> Session Class Initialized
DEBUG - 2017-06-27 12:17:58 --> Session routines successfully run
DEBUG - 2017-06-27 12:17:59 --> Total execution time: 1.4762
DEBUG - 2017-06-27 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:18:00 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:18:00 --> Session Class Initialized
DEBUG - 2017-06-27 12:18:00 --> Session Class Initialized
DEBUG - 2017-06-27 12:18:00 --> Session Class Initialized
DEBUG - 2017-06-27 12:18:00 --> Session routines successfully run
DEBUG - 2017-06-27 12:18:00 --> Session routines successfully run
DEBUG - 2017-06-27 12:18:00 --> Session routines successfully run
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:18:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:18:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:18:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:04 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:04 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:04 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:04 --> Total execution time: 0.1885
DEBUG - 2017-06-27 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:21 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:21 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 12:19:21 --> Severity: error --> Exception: syntax error, unexpected 'function' (T_FUNCTION), expecting ',' or ';' C:\xampp\htdocs\school_ms\application\controllers\Ms_parent.php 14
DEBUG - 2017-06-27 12:19:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:30 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:19:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-06-27 12:19:30 --> Severity: error --> Exception: syntax error, unexpected 'function' (T_FUNCTION), expecting ',' or ';' C:\xampp\htdocs\school_ms\application\controllers\Ms_parent.php 14
DEBUG - 2017-06-27 12:19:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:40 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:40 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:40 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:40 --> Total execution time: 0.1875
DEBUG - 2017-06-27 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:41 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:41 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:41 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:41 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:41 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:41 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:41 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:48 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:48 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:48 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:51 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:19:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:19:51 --> Session Class Initialized
DEBUG - 2017-06-27 12:19:51 --> Session routines successfully run
DEBUG - 2017-06-27 12:19:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:19:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:19:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:20:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:20:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:20:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:20:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:20:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:20:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:20:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:20:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:20:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:20:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:20:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:07 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:07 --> Total execution time: 0.2823
DEBUG - 2017-06-27 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Session Class Initialized
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> Session routines successfully run
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:05 --> Total execution time: 0.1564
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:27 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:28 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:28 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:28 --> Total execution time: 0.1739
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:28 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:28 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:28 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:28 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:28 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:28 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:22:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:22:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:29 --> Session Class Initialized
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:29 --> Session routines successfully run
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:22:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:05 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:05 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:05 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:05 --> Total execution time: 0.1464
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:23:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:06 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:06 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:23:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:07 --> Session Class Initialized
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:07 --> Session routines successfully run
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:23:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:28:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:28:31 --> Session Class Initialized
DEBUG - 2017-06-27 12:28:31 --> Session routines successfully run
DEBUG - 2017-06-27 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:28:31 --> No URI present. Default controller set.
DEBUG - 2017-06-27 12:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:28:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:28:31 --> Session Class Initialized
DEBUG - 2017-06-27 12:28:31 --> Session routines successfully run
DEBUG - 2017-06-27 12:28:31 --> Total execution time: 0.1480
DEBUG - 2017-06-27 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:28:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:28:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:28:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:28:31 --> Session Class Initialized
DEBUG - 2017-06-27 12:28:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:28:32 --> Session Class Initialized
DEBUG - 2017-06-27 12:28:32 --> Session routines successfully run
DEBUG - 2017-06-27 12:28:32 --> Session routines successfully run
DEBUG - 2017-06-27 12:28:32 --> Session Class Initialized
DEBUG - 2017-06-27 12:28:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:28:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:28:32 --> Session routines successfully run
DEBUG - 2017-06-27 12:28:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:28:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:28:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:28:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:28:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:44:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:44:02 --> Session Class Initialized
DEBUG - 2017-06-27 12:44:02 --> Session routines successfully run
DEBUG - 2017-06-27 12:44:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:44:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:44:20 --> Session Class Initialized
DEBUG - 2017-06-27 12:44:20 --> Session routines successfully run
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:44:20 --> UTF-8 Support Enabled
DEBUG - 2017-06-27 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-06-27 12:44:20 --> Session Class Initialized
DEBUG - 2017-06-27 12:44:20 --> Session Class Initialized
DEBUG - 2017-06-27 12:44:20 --> Session Class Initialized
DEBUG - 2017-06-27 12:44:20 --> Session routines successfully run
DEBUG - 2017-06-27 12:44:20 --> Session routines successfully run
DEBUG - 2017-06-27 12:44:20 --> Session routines successfully run
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:44:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-27 12:44:20 --> Myapp class already loaded. Second attempt ignored.

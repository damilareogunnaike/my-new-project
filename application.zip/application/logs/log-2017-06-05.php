<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-06-05 02:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:17:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:17:43 --> Session Class Initialized
ERROR - 2017-06-05 02:17:43 --> Session: The session cookie was not signed.
DEBUG - 2017-06-05 02:17:43 --> Session routines successfully run
DEBUG - 2017-06-05 02:17:43 --> Total execution time: 0.8140
DEBUG - 2017-06-05 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:17:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:17:46 --> Session Class Initialized
DEBUG - 2017-06-05 02:17:46 --> Session routines successfully run
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:17:46 --> Session Class Initialized
DEBUG - 2017-06-05 02:17:46 --> Session routines successfully run
DEBUG - 2017-06-05 02:17:46 --> Session Class Initialized
DEBUG - 2017-06-05 02:17:46 --> Session routines successfully run
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 02:17:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 02:17:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:17:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:17:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:17:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:24:30 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:24:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:24:30 --> Session Class Initialized
DEBUG - 2017-06-05 02:24:30 --> Session routines successfully run
DEBUG - 2017-06-05 02:24:30 --> User with name admin just logged in
DEBUG - 2017-06-05 02:24:31 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:24:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:24:31 --> Session Class Initialized
DEBUG - 2017-06-05 02:24:31 --> Session routines successfully run
DEBUG - 2017-06-05 02:24:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:24:31 --> Total execution time: 0.4979
DEBUG - 2017-06-05 02:24:38 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:24:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:24:38 --> Session Class Initialized
DEBUG - 2017-06-05 02:24:38 --> Session routines successfully run
DEBUG - 2017-06-05 02:24:38 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-06-05 02:24:38 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-06-05 02:24:39 --> Total execution time: 0.2397
DEBUG - 2017-06-05 02:24:47 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:24:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:24:47 --> Session Class Initialized
DEBUG - 2017-06-05 02:24:47 --> Session routines successfully run
DEBUG - 2017-06-05 02:24:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 02:24:47 --> Total execution time: 0.1368
DEBUG - 2017-06-05 02:24:53 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:24:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:24:53 --> Session Class Initialized
DEBUG - 2017-06-05 02:24:53 --> Session routines successfully run
DEBUG - 2017-06-05 02:24:54 --> Total execution time: 1.1612
DEBUG - 2017-06-05 02:38:46 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 02:38:46 --> No URI present. Default controller set.
DEBUG - 2017-06-05 02:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 02:38:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 02:38:46 --> Session Class Initialized
ERROR - 2017-06-05 02:38:46 --> Session: The session cookie was not signed.
DEBUG - 2017-06-05 02:38:46 --> Session routines successfully run
DEBUG - 2017-06-05 02:38:46 --> Total execution time: 0.0845
DEBUG - 2017-06-05 04:32:42 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:32:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:32:43 --> Session Class Initialized
ERROR - 2017-06-05 04:32:43 --> Session: The session cookie was not signed.
DEBUG - 2017-06-05 04:32:43 --> Session routines successfully run
DEBUG - 2017-06-05 04:32:43 --> Total execution time: 0.9268
DEBUG - 2017-06-05 04:48:03 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:03 --> Session Class Initialized
ERROR - 2017-06-05 04:48:03 --> Session: The session cookie was not signed.
DEBUG - 2017-06-05 04:48:03 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:03 --> Total execution time: 0.1354
DEBUG - 2017-06-05 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:09 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:09 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:09 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:09 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:09 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 04:48:09 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:09 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 04:48:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:26 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:26 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:26 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:26 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:26 --> User with name admin just logged in
DEBUG - 2017-06-05 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:27 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:27 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:27 --> Total execution time: 0.2382
DEBUG - 2017-06-05 04:48:58 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 04:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 04:48:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 04:48:58 --> Session Class Initialized
DEBUG - 2017-06-05 04:48:58 --> Session routines successfully run
DEBUG - 2017-06-05 04:48:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 04:48:58 --> Total execution time: 0.0902
DEBUG - 2017-06-05 08:04:22 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:04:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:04:23 --> Session Class Initialized
ERROR - 2017-06-05 08:04:23 --> Session: The session cookie was not signed.
DEBUG - 2017-06-05 08:04:23 --> Session routines successfully run
DEBUG - 2017-06-05 08:04:23 --> Total execution time: 1.4953
DEBUG - 2017-06-05 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:04:40 --> Session Class Initialized
DEBUG - 2017-06-05 08:04:40 --> Session routines successfully run
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:04:40 --> Session Class Initialized
DEBUG - 2017-06-05 08:04:40 --> Session routines successfully run
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:04:40 --> Session Class Initialized
DEBUG - 2017-06-05 08:04:40 --> Session routines successfully run
DEBUG - 2017-06-05 08:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:04:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:05:08 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:05:08 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:05:08 --> Session Class Initialized
DEBUG - 2017-06-05 08:05:08 --> Session routines successfully run
DEBUG - 2017-06-05 08:05:08 --> Total execution time: 0.0481
DEBUG - 2017-06-05 08:05:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:05:10 --> Session Class Initialized
DEBUG - 2017-06-05 08:05:10 --> Session routines successfully run
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:05:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:05:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:05:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:05:10 --> Session Class Initialized
DEBUG - 2017-06-05 08:05:10 --> Session routines successfully run
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:05:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-06-05 08:05:10 --> UTF-8 Support Enabled
DEBUG - 2017-06-05 08:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-06-05 08:05:10 --> Session Class Initialized
DEBUG - 2017-06-05 08:05:10 --> Session routines successfully run
DEBUG - 2017-06-05 08:05:10 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-06-05 08:05:10 --> Myapp class already loaded. Second attempt ignored.

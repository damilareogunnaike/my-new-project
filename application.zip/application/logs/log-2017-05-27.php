<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-27 05:40:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:42 --> Session Class Initialized
ERROR - 2017-05-27 05:40:42 --> Session: The session cookie was not signed.
DEBUG - 2017-05-27 05:40:42 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:43 --> No URI present. Default controller set.
DEBUG - 2017-05-27 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:43 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:43 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:43 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:43 --> Total execution time: 0.0712
DEBUG - 2017-05-27 05:40:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:52 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:52 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:52 --> Total execution time: 0.0663
DEBUG - 2017-05-27 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:57 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:57 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:57 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:57 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:57 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:57 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:57 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:57 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:57 --> Total execution time: 0.0682
DEBUG - 2017-05-27 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:40:58 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:58 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:40:58 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:58 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:40:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:40:58 --> Session Class Initialized
DEBUG - 2017-05-27 05:40:58 --> Session routines successfully run
DEBUG - 2017-05-27 05:40:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:40:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:06 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:06 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:06 --> User with name damilare just logged in
DEBUG - 2017-05-27 05:41:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:06 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:06 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:06 --> Total execution time: 0.2356
DEBUG - 2017-05-27 05:41:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:19 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:19 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:19 --> Total execution time: 0.0964
DEBUG - 2017-05-27 05:41:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:30 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:30 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:30 --> Total execution time: 0.0803
DEBUG - 2017-05-27 05:41:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:32 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:32 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:33 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:33 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:33 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:33 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:33 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:33 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:34 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:34 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:34 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:40 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:40 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:40 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:41 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:41 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:42 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:42 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:42 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:41:46 --> Session Class Initialized
DEBUG - 2017-05-27 05:41:46 --> Session routines successfully run
DEBUG - 2017-05-27 05:41:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:41:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:42:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:42:22 --> Session Class Initialized
DEBUG - 2017-05-27 05:42:22 --> Session routines successfully run
DEBUG - 2017-05-27 05:42:22 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:42:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 05:42:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 05:42:32 --> Session Class Initialized
DEBUG - 2017-05-27 05:42:32 --> Session routines successfully run
DEBUG - 2017-05-27 05:42:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-27 05:42:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-27 15:18:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-27 15:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-27 15:18:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-27 15:18:56 --> Session Class Initialized
ERROR - 2017-05-27 15:18:56 --> Session: The session cookie was not signed.
DEBUG - 2017-05-27 15:18:56 --> Session routines successfully run
DEBUG - 2017-05-27 15:18:56 --> Total execution time: 1.3290

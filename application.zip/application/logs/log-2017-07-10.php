<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-07-10 00:15:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:08 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:08 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:08 --> Total execution time: 0.2210
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:35 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:35 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:35 --> Total execution time: 0.1209
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:15:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:18:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:18:59 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:18:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:18:59 --> Session Class Initialized
DEBUG - 2017-07-10 00:18:59 --> Session routines successfully run
DEBUG - 2017-07-10 00:18:59 --> Total execution time: 0.1118
DEBUG - 2017-07-10 00:19:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:00 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:00 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:00 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:00 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:00 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:00 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:43 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:43 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:43 --> Total execution time: 0.1659
DEBUG - 2017-07-10 00:19:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:19:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:19:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:19:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:19:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:19:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:21:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:21:21 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:21:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:21:21 --> Session Class Initialized
DEBUG - 2017-07-10 00:21:21 --> Session routines successfully run
DEBUG - 2017-07-10 00:21:21 --> Total execution time: 0.1259
DEBUG - 2017-07-10 00:21:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:21:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:21:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:21:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:21:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:21:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:21:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:21:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:21:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:21:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:21:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:21:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:21:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:21:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:23:42 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:23:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:23:42 --> Session Class Initialized
DEBUG - 2017-07-10 00:23:42 --> Session routines successfully run
DEBUG - 2017-07-10 00:23:42 --> Total execution time: 0.1406
DEBUG - 2017-07-10 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:23:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:23:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:23:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:23:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:23:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:23:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:23:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:23:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:23:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:23:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:23:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:23:58 --> Session Class Initialized
DEBUG - 2017-07-10 00:23:58 --> Session routines successfully run
DEBUG - 2017-07-10 00:23:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:23:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:24:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:24:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:24:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:24:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:24:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:24:11 --> Total execution time: 0.1346
DEBUG - 2017-07-10 00:24:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:24:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:24:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:24:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:24:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:24:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:24:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:24:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:24:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:24:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:24:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:11 --> Total execution time: 0.1350
DEBUG - 2017-07-10 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:23 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:23 --> Total execution time: 0.1468
DEBUG - 2017-07-10 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:24 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:24 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:24 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:24 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:24 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:24 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:45 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:45 --> Total execution time: 0.1069
DEBUG - 2017-07-10 00:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:46 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:46 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:46 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:46 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:46 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:46 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:26:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:26:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:11 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:11 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:36 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:36 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:27:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:27:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:27:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:14 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:14 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:15 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:15 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:15 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:15 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:28:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:28:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:28:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:29:59 --> Session Class Initialized
DEBUG - 2017-07-10 00:29:59 --> Session routines successfully run
DEBUG - 2017-07-10 00:29:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:29:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:22 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:22 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:22 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:22 --> Total execution time: 0.1074
DEBUG - 2017-07-10 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:30:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:30:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:30:22 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:22 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:22 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:30:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:30:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:30:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:30:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:31:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:31:50 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:31:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:31:50 --> Session Class Initialized
DEBUG - 2017-07-10 00:31:50 --> Session routines successfully run
DEBUG - 2017-07-10 00:31:50 --> Total execution time: 0.1440
DEBUG - 2017-07-10 00:31:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:31:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:31:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:31:51 --> Session Class Initialized
DEBUG - 2017-07-10 00:31:51 --> Session Class Initialized
DEBUG - 2017-07-10 00:31:51 --> Session routines successfully run
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:31:51 --> Session routines successfully run
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:31:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:31:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:31:51 --> Session Class Initialized
DEBUG - 2017-07-10 00:31:51 --> Session routines successfully run
DEBUG - 2017-07-10 00:31:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:31:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:31:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:32:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:32:51 --> Session Class Initialized
DEBUG - 2017-07-10 00:32:51 --> Session routines successfully run
DEBUG - 2017-07-10 00:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:17 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:17 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:17 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:17 --> Total execution time: 0.1392
DEBUG - 2017-07-10 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:30 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:30 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:30 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:30 --> Total execution time: 0.1170
DEBUG - 2017-07-10 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:47 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:47 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:47 --> Total execution time: 0.1234
DEBUG - 2017-07-10 00:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:33:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:48 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:48 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:48 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:48 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:33:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:48 --> Session Class Initialized
DEBUG - 2017-07-10 00:33:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:33:48 --> Session routines successfully run
DEBUG - 2017-07-10 00:33:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:33:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:10 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:10 --> Total execution time: 0.1273
DEBUG - 2017-07-10 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:12 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:12 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:34 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:34 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:34 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:34 --> Total execution time: 0.1294
DEBUG - 2017-07-10 00:34:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:34:35 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:35 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:35 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:35 --> Session Class Initialized
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:35 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:34:35 --> Session routines successfully run
DEBUG - 2017-07-10 00:34:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:34:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:35:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:35:22 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:35:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:35:22 --> Session Class Initialized
DEBUG - 2017-07-10 00:35:22 --> Session routines successfully run
DEBUG - 2017-07-10 00:35:22 --> Total execution time: 0.1282
DEBUG - 2017-07-10 00:35:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:35:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:35:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:35:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:35:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:35:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:35:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:35:23 --> Session Class Initialized
DEBUG - 2017-07-10 00:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:35:23 --> Session routines successfully run
DEBUG - 2017-07-10 00:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:35:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:35:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:35:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:35:59 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:35:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:35:59 --> Session Class Initialized
DEBUG - 2017-07-10 00:35:59 --> Session routines successfully run
DEBUG - 2017-07-10 00:35:59 --> Total execution time: 0.1523
DEBUG - 2017-07-10 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:43 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:43 --> Total execution time: 0.1238
DEBUG - 2017-07-10 00:36:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:36:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:36:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:05 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:05 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:05 --> Total execution time: 0.1562
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:06 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:06 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:06 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:37:06 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:06 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:06 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:06 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:07 --> Session Class Initialized
DEBUG - 2017-07-10 00:37:07 --> Session routines successfully run
DEBUG - 2017-07-10 00:37:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:37:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:55 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:55 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:55 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:56 --> Total execution time: 0.1670
DEBUG - 2017-07-10 00:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:16 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:16 --> Total execution time: 0.1330
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:40:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:40:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:40:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:07 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:07 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:07 --> Total execution time: 0.1308
DEBUG - 2017-07-10 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:42:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:42:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:42:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:14 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:14 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:14 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:15 --> Total execution time: 0.1477
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:43:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:43:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:44:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:44:55 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:44:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:44:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:44:55 --> Session Class Initialized
DEBUG - 2017-07-10 00:44:55 --> Session routines successfully run
DEBUG - 2017-07-10 00:44:55 --> Total execution time: 0.1465
DEBUG - 2017-07-10 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:44:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:44:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:44:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:44:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:44:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:44:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:44:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:44:56 --> Session Class Initialized
DEBUG - 2017-07-10 00:44:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:44:56 --> Session routines successfully run
DEBUG - 2017-07-10 00:44:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:44:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:09 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:09 --> Total execution time: 0.1305
DEBUG - 2017-07-10 00:45:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:10 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:10 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:31 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:31 --> Total execution time: 0.1229
DEBUG - 2017-07-10 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:32 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:32 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:32 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:32 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:32 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:32 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:42 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:42 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:42 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:42 --> Total execution time: 0.1395
DEBUG - 2017-07-10 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:43 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:43 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:43 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:45:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:45:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:45:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:16 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:16 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:16 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:16 --> Total execution time: 0.1564
DEBUG - 2017-07-10 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:17 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:17 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:18 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:31 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:31 --> Total execution time: 0.1607
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:44 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:44 --> Total execution time: 0.1348
DEBUG - 2017-07-10 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:44 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:44 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:45 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:53 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:53 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:53 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:53 --> Total execution time: 0.1840
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:54 --> Session Class Initialized
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:54 --> Session routines successfully run
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:46:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:09 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:09 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:31 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:31 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:32 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:32 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:32 --> Total execution time: 0.1666
DEBUG - 2017-07-10 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:34 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:34 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:34 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:34 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:34 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:34 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:47:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:47:42 --> Session Class Initialized
DEBUG - 2017-07-10 00:47:43 --> Session routines successfully run
DEBUG - 2017-07-10 00:47:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:47:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:47:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:48:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:48:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:48:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:48:35 --> Session Class Initialized
DEBUG - 2017-07-10 00:48:35 --> Session routines successfully run
DEBUG - 2017-07-10 00:48:36 --> Total execution time: 0.1439
DEBUG - 2017-07-10 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:48:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:48:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:48:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:48:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:48:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:48:37 --> Session Class Initialized
DEBUG - 2017-07-10 00:48:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:48:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:48:37 --> Session routines successfully run
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:48:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:48:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:48:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:02 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:02 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:02 --> Total execution time: 0.1394
DEBUG - 2017-07-10 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:04 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:04 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:04 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:04 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:04 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:04 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:17 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:17 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:17 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:17 --> Total execution time: 0.1440
DEBUG - 2017-07-10 00:49:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:49:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:19 --> Session Class Initialized
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:19 --> Session routines successfully run
DEBUG - 2017-07-10 00:49:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:49:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:49:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:40 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:40 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:40 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:40 --> Total execution time: 0.1463
DEBUG - 2017-07-10 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:41 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:41 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:41 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:41 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:41 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:41 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:50:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:57 --> Session Class Initialized
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:57 --> Session routines successfully run
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:50:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:01 --> No URI present. Default controller set.
DEBUG - 2017-07-10 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:01 --> Total execution time: 0.1190
DEBUG - 2017-07-10 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:01 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:01 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 00:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 00:51:02 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:02 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:02 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:02 --> Session Class Initialized
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:02 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:02 --> Session routines successfully run
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 00:51:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:05:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:05:58 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:05:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:05:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:05:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:05:58 --> Total execution time: 0.1431
DEBUG - 2017-07-10 01:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:06:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:06:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:06:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:35 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:35 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:35 --> Total execution time: 0.1250
DEBUG - 2017-07-10 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:50 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:50 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:50 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:50 --> Total execution time: 0.1305
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:07:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:10 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:10 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:10 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:10 --> Total execution time: 0.1450
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:23 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:23 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:23 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:23 --> Total execution time: 0.1342
DEBUG - 2017-07-10 01:08:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:08:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:34 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:34 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:34 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:35 --> Total execution time: 0.1160
DEBUG - 2017-07-10 01:11:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:48 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:48 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:48 --> Total execution time: 0.1261
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:48 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:48 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:48 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:48 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:48 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:48 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:11:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:11:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:11:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:05 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:05 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:05 --> Total execution time: 0.1396
DEBUG - 2017-07-10 01:16:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:18 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:18 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:18 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:19 --> Total execution time: 0.1725
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:20 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:20 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:32 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:32 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:32 --> Total execution time: 0.1645
DEBUG - 2017-07-10 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:16:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:51 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:51 --> Total execution time: 0.1325
DEBUG - 2017-07-10 01:17:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:52 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:52 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:52 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:52 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:52 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:52 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:17:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:17:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:17:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:36 --> Total execution time: 0.1966
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:18:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:27 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:27 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:28 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:28 --> Total execution time: 0.1425
DEBUG - 2017-07-10 01:21:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:28 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:28 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:28 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:28 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:28 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:29 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:21:29 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:29 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:29 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:29 --> Session Class Initialized
DEBUG - 2017-07-10 01:21:29 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:29 --> Session routines successfully run
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:21:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:04 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:04 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:04 --> Total execution time: 0.1710
DEBUG - 2017-07-10 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:06 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:06 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:06 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:22:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:22:07 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:30 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:30 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:30 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:30 --> Total execution time: 0.1262
DEBUG - 2017-07-10 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:31 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:31 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:31 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:31 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:31 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:31 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:23:32 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:32 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:32 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:32 --> Session Class Initialized
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:32 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:32 --> Session routines successfully run
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:23:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:39 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:39 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:39 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:39 --> Total execution time: 0.1360
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:24:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:14 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:14 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:14 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:14 --> Total execution time: 0.1296
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:25:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:56 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:56 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:56 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:56 --> Total execution time: 0.1262
DEBUG - 2017-07-10 01:27:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Session Class Initialized
DEBUG - 2017-07-10 01:27:58 --> Session routines successfully run
DEBUG - 2017-07-10 01:27:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:27:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:19 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:19 --> Total execution time: 0.1377
DEBUG - 2017-07-10 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:20 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:20 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:36 --> Total execution time: 0.1779
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:29:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:40 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:40 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:40 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:40 --> Total execution time: 0.1482
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:30:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:41 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:41 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:41 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:41 --> Total execution time: 0.1439
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:36:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:36:59 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:36:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:36:59 --> Session Class Initialized
DEBUG - 2017-07-10 01:36:59 --> Session routines successfully run
DEBUG - 2017-07-10 01:36:59 --> Total execution time: 0.2062
DEBUG - 2017-07-10 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:37:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:37:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:36 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:36 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:36 --> Total execution time: 0.1433
DEBUG - 2017-07-10 01:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:37 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:37 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:48 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:48 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:48 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:48 --> Total execution time: 0.1368
DEBUG - 2017-07-10 01:38:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:38:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:38:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:38:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:38:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:38:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:42:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:42:40 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:42:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:42:40 --> Session Class Initialized
DEBUG - 2017-07-10 01:42:40 --> Session routines successfully run
DEBUG - 2017-07-10 01:42:40 --> Total execution time: 0.1335
DEBUG - 2017-07-10 01:42:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:42:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:42:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:42:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:42:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:42:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:42:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:42:42 --> Session Class Initialized
DEBUG - 2017-07-10 01:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:42:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:42:42 --> Session routines successfully run
DEBUG - 2017-07-10 01:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:42:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:02 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:02 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:02 --> Total execution time: 0.1208
DEBUG - 2017-07-10 01:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:04 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:04 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:04 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:04 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:04 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:04 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:24 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:24 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:24 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:24 --> Total execution time: 0.1517
DEBUG - 2017-07-10 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:25 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:25 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:52 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:52 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:52 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:52 --> Total execution time: 0.1234
DEBUG - 2017-07-10 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:43:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:54 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:43:54 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:54 --> Session Class Initialized
DEBUG - 2017-07-10 01:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:54 --> Session routines successfully run
DEBUG - 2017-07-10 01:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:43:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:43:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:15 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:15 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:15 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:15 --> Total execution time: 0.1367
DEBUG - 2017-07-10 01:47:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:38 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:38 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:38 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:38 --> Total execution time: 0.1535
DEBUG - 2017-07-10 01:47:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:40 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:40 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:40 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:40 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:40 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:40 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:47 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:47 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:47 --> Total execution time: 0.1435
DEBUG - 2017-07-10 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:47:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:47:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:49 --> Session Class Initialized
DEBUG - 2017-07-10 01:47:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:49 --> Session routines successfully run
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:47:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:47:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:04 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:04 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:04 --> Total execution time: 0.1882
DEBUG - 2017-07-10 01:48:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:05 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:05 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:05 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:05 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:05 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:05 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:11 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:11 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:11 --> Total execution time: 0.1290
DEBUG - 2017-07-10 01:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:51 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:52 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:52 --> Total execution time: 0.1493
DEBUG - 2017-07-10 01:48:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:48:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:53 --> Session Class Initialized
DEBUG - 2017-07-10 01:48:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:53 --> Session routines successfully run
DEBUG - 2017-07-10 01:48:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:48:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:48:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:51:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:51:20 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:51:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:51:20 --> Session Class Initialized
DEBUG - 2017-07-10 01:51:20 --> Session routines successfully run
DEBUG - 2017-07-10 01:51:20 --> Total execution time: 0.1481
DEBUG - 2017-07-10 01:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:51:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:51:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:51:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:51:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:51:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:51:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:51:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:51:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:51:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:51:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:51:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:51:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:52:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:52:01 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:52:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:52:01 --> Session Class Initialized
DEBUG - 2017-07-10 01:52:01 --> Session routines successfully run
DEBUG - 2017-07-10 01:52:01 --> Total execution time: 0.1297
DEBUG - 2017-07-10 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 01:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 01:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 01:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 01:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 01:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:57:59 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:57:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:57:59 --> Session Class Initialized
DEBUG - 2017-07-10 01:57:59 --> Session routines successfully run
DEBUG - 2017-07-10 01:57:59 --> Total execution time: 0.1526
DEBUG - 2017-07-10 01:57:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:00 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:00 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:07 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:07 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:08 --> Total execution time: 0.1261
DEBUG - 2017-07-10 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:09 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:09 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:09 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:09 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:09 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:09 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:12 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:12 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:12 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:12 --> Total execution time: 0.1254
DEBUG - 2017-07-10 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:13 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:13 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:13 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:13 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:13 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:13 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:15 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:15 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:15 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:15 --> Total execution time: 0.1354
DEBUG - 2017-07-10 01:58:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:16 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:16 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:55 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:56 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:56 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:56 --> Total execution time: 0.1940
DEBUG - 2017-07-10 01:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:58:57 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:58:57 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:57 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:57 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:57 --> Session Class Initialized
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:57 --> Session routines successfully run
DEBUG - 2017-07-10 01:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:58:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:19 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:19 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:19 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:19 --> Total execution time: 0.1595
DEBUG - 2017-07-10 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:32 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:32 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:32 --> Total execution time: 0.1407
DEBUG - 2017-07-10 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 01:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 01:59:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 01:59:33 --> No URI present. Default controller set.
DEBUG - 2017-07-10 01:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 01:59:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 01:59:33 --> Session Class Initialized
DEBUG - 2017-07-10 01:59:33 --> Session routines successfully run
DEBUG - 2017-07-10 01:59:33 --> Total execution time: 0.1873
DEBUG - 2017-07-10 02:00:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:03 --> Total execution time: 0.1819
DEBUG - 2017-07-10 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:04 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:04 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:04 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:04 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:04 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:04 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:04 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:05 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:05 --> Total execution time: 0.2105
DEBUG - 2017-07-10 02:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:16 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:16 --> Total execution time: 0.1416
DEBUG - 2017-07-10 02:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:17 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:17 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:17 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:17 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:00:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:17 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:17 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:17 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:17 --> Total execution time: 0.2049
DEBUG - 2017-07-10 02:00:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:58 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:58 --> Session Class Initialized
DEBUG - 2017-07-10 02:00:58 --> Session routines successfully run
DEBUG - 2017-07-10 02:00:58 --> Total execution time: 0.1738
DEBUG - 2017-07-10 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:00:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:00:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:01:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:01:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:01:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:01:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:01:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:01:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:01:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:01:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:01:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:06:34 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:06:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:06:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:06:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:06:34 --> Total execution time: 0.1537
DEBUG - 2017-07-10 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:06:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:06:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:06:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:06:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:06:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:06:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:06:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:06:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:06:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:06:36 --> Total execution time: 0.3055
DEBUG - 2017-07-10 02:08:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:08:49 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:08:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:08:49 --> Session Class Initialized
DEBUG - 2017-07-10 02:08:49 --> Session routines successfully run
DEBUG - 2017-07-10 02:08:50 --> Total execution time: 0.1954
DEBUG - 2017-07-10 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:08:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:08:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:08:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:08:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:08:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:08:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:08:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:08:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:08:53 --> Total execution time: 0.2503
DEBUG - 2017-07-10 02:09:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:25 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:25 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:25 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:25 --> Total execution time: 0.1627
DEBUG - 2017-07-10 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:26 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:26 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:26 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:26 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:26 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:26 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:27 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:27 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:27 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:27 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:27 --> Total execution time: 0.5471
DEBUG - 2017-07-10 02:09:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:49 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:49 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:49 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:50 --> Total execution time: 0.1680
DEBUG - 2017-07-10 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:09:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:09:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:09:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:09:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:09:51 --> Total execution time: 0.3301
DEBUG - 2017-07-10 02:09:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:09:51 --> Total execution time: 0.4267
DEBUG - 2017-07-10 02:10:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:34 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:34 --> Total execution time: 0.1992
DEBUG - 2017-07-10 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:36 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:36 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Total execution time: 0.4183
DEBUG - 2017-07-10 02:10:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:36 --> Total execution time: 0.4609
DEBUG - 2017-07-10 02:10:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:58 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:58 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:58 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:58 --> Total execution time: 0.1824
DEBUG - 2017-07-10 02:10:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:10:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:10:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:10:59 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:59 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:59 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:59 --> Session Class Initialized
DEBUG - 2017-07-10 02:10:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:10:59 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:59 --> Session routines successfully run
DEBUG - 2017-07-10 02:10:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:10:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:00 --> Total execution time: 0.3809
DEBUG - 2017-07-10 02:11:00 --> Total execution time: 0.4004
DEBUG - 2017-07-10 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:14 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:14 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:14 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:14 --> Total execution time: 0.2328
DEBUG - 2017-07-10 02:11:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:16 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:16 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:16 --> Total execution time: 0.4080
DEBUG - 2017-07-10 02:11:16 --> Total execution time: 0.4280
DEBUG - 2017-07-10 02:11:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:38 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:38 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:38 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:39 --> Total execution time: 0.1821
DEBUG - 2017-07-10 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:40 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:40 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:40 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:40 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:40 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:11:41 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:41 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:41 --> Session Class Initialized
DEBUG - 2017-07-10 02:11:41 --> Session routines successfully run
DEBUG - 2017-07-10 02:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:11:41 --> Total execution time: 0.6341
DEBUG - 2017-07-10 02:11:41 --> Total execution time: 0.6396
DEBUG - 2017-07-10 02:13:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:27 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:27 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:27 --> Session routines successfully run
DEBUG - 2017-07-10 02:13:27 --> Total execution time: 0.1648
DEBUG - 2017-07-10 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:29 --> Session routines successfully run
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:13:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:29 --> Session routines successfully run
DEBUG - 2017-07-10 02:13:29 --> Session routines successfully run
DEBUG - 2017-07-10 02:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:13:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:29 --> Session routines successfully run
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:13:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:13:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:13:29 --> Session routines successfully run
ERROR - 2017-07-10 02:13:30 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\school_ms\application\controllers\api\Students.php 26
DEBUG - 2017-07-10 02:13:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:13:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:13:30 --> Total execution time: 0.5109
DEBUG - 2017-07-10 02:14:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:01 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:01 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:01 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:01 --> Total execution time: 0.1527
DEBUG - 2017-07-10 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:02 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:02 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:02 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:02 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:02 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:02 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:03 --> Total execution time: 0.4447
DEBUG - 2017-07-10 02:14:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:17 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:17 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:17 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:17 --> Total execution time: 0.1790
DEBUG - 2017-07-10 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:18 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:18 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:18 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:18 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:18 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:18 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:19 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:19 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:19 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:19 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:19 --> Total execution time: 0.4564
DEBUG - 2017-07-10 02:14:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:29 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:29 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:29 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:29 --> Total execution time: 0.1914
DEBUG - 2017-07-10 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:14:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:14:31 --> Total execution time: 0.3981
DEBUG - 2017-07-10 02:14:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:00 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:00 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:00 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:00 --> Total execution time: 0.1547
DEBUG - 2017-07-10 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:03 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:03 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:33 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:33 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:33 --> Total execution time: 0.1499
DEBUG - 2017-07-10 02:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:35 --> Total execution time: 0.3465
DEBUG - 2017-07-10 02:15:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:35 --> Total execution time: 0.3970
DEBUG - 2017-07-10 02:15:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:51 --> Total execution time: 0.1861
DEBUG - 2017-07-10 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:53 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:53 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:53 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:53 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:53 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:53 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:15:53 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:53 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:53 --> Session Class Initialized
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:53 --> Session routines successfully run
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:15:54 --> Total execution time: 0.4113
DEBUG - 2017-07-10 02:15:54 --> Total execution time: 0.4150
DEBUG - 2017-07-10 02:21:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:48 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:48 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:48 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:48 --> Total execution time: 0.1660
DEBUG - 2017-07-10 02:21:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:21:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:21:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:21:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:21:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:21:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:21:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:21:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:21:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:21:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:21:51 --> Total execution time: 0.3578
DEBUG - 2017-07-10 02:21:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:31 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:31 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:31 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:31 --> Total execution time: 0.1829
DEBUG - 2017-07-10 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:33 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:33 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:33 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:33 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:33 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:33 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:34 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:34 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:34 --> Total execution time: 0.4793
DEBUG - 2017-07-10 02:23:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:50 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:50 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:50 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:50 --> Total execution time: 0.1631
DEBUG - 2017-07-10 02:23:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:51 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:51 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:51 --> Total execution time: 0.1648
DEBUG - 2017-07-10 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:23:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:52 --> Session Class Initialized
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:52 --> Session routines successfully run
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:23:52 --> Total execution time: 0.4231
DEBUG - 2017-07-10 02:24:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:09 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:09 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:09 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:09 --> Total execution time: 0.1432
DEBUG - 2017-07-10 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:10 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:10 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:24:10 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:10 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:24:10 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:10 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:24:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:24:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:24:11 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:11 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:11 --> Session Class Initialized
DEBUG - 2017-07-10 02:24:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:24:11 --> Session routines successfully run
DEBUG - 2017-07-10 02:24:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:24:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:24:11 --> Total execution time: 0.3896
DEBUG - 2017-07-10 02:25:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:35 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:35 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:35 --> Total execution time: 0.1713
DEBUG - 2017-07-10 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:37 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:37 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:37 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:37 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:37 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:25:37 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:25:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:25:37 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:37 --> Session Class Initialized
DEBUG - 2017-07-10 02:25:37 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:37 --> Session routines successfully run
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:25:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:25:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:25:38 --> Total execution time: 0.3933
DEBUG - 2017-07-10 02:27:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:07 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:07 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:07 --> Total execution time: 0.1347
DEBUG - 2017-07-10 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:08 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:08 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:08 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:08 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:08 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:08 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:08 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:08 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:08 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:08 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:08 --> Total execution time: 0.3345
DEBUG - 2017-07-10 02:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:13 --> No URI present. Default controller set.
DEBUG - 2017-07-10 02:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:13 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:13 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:13 --> Total execution time: 0.1520
DEBUG - 2017-07-10 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:14 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:14 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:15 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:15 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:15 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:15 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:15 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:15 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 02:27:15 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:15 --> Session Class Initialized
DEBUG - 2017-07-10 02:27:15 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:15 --> Session routines successfully run
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 02:27:15 --> Total execution time: 0.3689
DEBUG - 2017-07-10 03:08:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:35 --> Total execution time: 0.1701
DEBUG - 2017-07-10 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:36 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:36 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:36 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:54 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:54 --> Total execution time: 0.1587
DEBUG - 2017-07-10 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:08:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:08:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:08:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:08:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:08:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:08:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:11 --> Total execution time: 0.1584
DEBUG - 2017-07-10 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:09:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:09:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:09:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:09:13 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-10 03:09:13 --> Severity: Notice --> Undefined property: Reports::$Result C:\xampp\htdocs\school_ms\application\controllers\api\Reports.php 70
ERROR - 2017-07-10 03:09:14 --> Severity: error --> Exception: Call to a member function get_student_data_display() on null C:\xampp\htdocs\school_ms\application\controllers\api\Reports.php 70
DEBUG - 2017-07-10 03:11:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:11 --> Total execution time: 0.2040
DEBUG - 2017-07-10 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:11:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:11:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:11:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:11:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:11:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:11:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:11:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:11:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:11:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:11:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:11:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:11:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:36 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:36 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:36 --> Total execution time: 0.1877
DEBUG - 2017-07-10 03:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:02 --> Total execution time: 0.1959
DEBUG - 2017-07-10 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:03 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:03 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:03 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:03 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:03 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:21 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:21 --> Total execution time: 0.1502
DEBUG - 2017-07-10 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:24:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:23 --> Session routines successfully run
DEBUG - 2017-07-10 03:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:24:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:24:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:02 --> Total execution time: 0.1435
DEBUG - 2017-07-10 03:25:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:55 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:56 --> Total execution time: 0.1646
DEBUG - 2017-07-10 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:25:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:25:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:25:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:25:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:25:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:25:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:11 --> Total execution time: 0.1406
DEBUG - 2017-07-10 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:27:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:27:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:13 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:27:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:13 --> Session Class Initialized
DEBUG - 2017-07-10 03:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:27:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:13 --> Session routines successfully run
DEBUG - 2017-07-10 03:27:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:27:13 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:27:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:27:13 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:09 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:10 --> Total execution time: 0.1508
DEBUG - 2017-07-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:26 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:26 --> Total execution time: 0.1419
DEBUG - 2017-07-10 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:27 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:31:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:27 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:27 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:31:27 --> Session Class Initialized
DEBUG - 2017-07-10 03:31:27 --> Session routines successfully run
DEBUG - 2017-07-10 03:31:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:31:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:16 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:16 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:16 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:16 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:16 --> Total execution time: 0.1695
DEBUG - 2017-07-10 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:37 --> Total execution time: 0.1521
DEBUG - 2017-07-10 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:37 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:37 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:38 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:38 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:46 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:46 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:46 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:46 --> Total execution time: 0.2210
DEBUG - 2017-07-10 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:32:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:32:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:32:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:17 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:17 --> Total execution time: 0.1744
DEBUG - 2017-07-10 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:34:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:34:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:34:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:34:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:34:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:34:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:34:18 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:41 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:41 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:41 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:41 --> Total execution time: 0.2051
DEBUG - 2017-07-10 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:37:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:37:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:37:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:37:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:37:44 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:44 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:44 --> Session Class Initialized
DEBUG - 2017-07-10 03:37:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:37:44 --> Session routines successfully run
DEBUG - 2017-07-10 03:37:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:37:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:37:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:01 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:01 --> Total execution time: 0.1569
DEBUG - 2017-07-10 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:24 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:24 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:24 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:24 --> Total execution time: 0.1773
DEBUG - 2017-07-10 03:41:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:26 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:26 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:47 --> Total execution time: 0.1610
DEBUG - 2017-07-10 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:49 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:49 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:49 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:49 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:49 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:50 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:50 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:50 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:50 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:50 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:41:50 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:41:58 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:41:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:41:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:41:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:41:58 --> Total execution time: 0.1684
DEBUG - 2017-07-10 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:15 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:15 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:15 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:15 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:15 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:15 --> Total execution time: 0.1658
DEBUG - 2017-07-10 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:17 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:17 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:17 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:17 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:17 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:42 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:42 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:42 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:42 --> Total execution time: 0.1578
DEBUG - 2017-07-10 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:42:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:42:43 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:43 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:44 --> Session Class Initialized
DEBUG - 2017-07-10 03:42:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:44 --> Session routines successfully run
DEBUG - 2017-07-10 03:42:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:42:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:42:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:44 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:44 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:44 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:44 --> Total execution time: 0.1630
DEBUG - 2017-07-10 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:52 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:52 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:52 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:52 --> Total execution time: 0.1603
DEBUG - 2017-07-10 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Total execution time: 0.1526
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:49:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> Session Class Initialized
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Session routines successfully run
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:49:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:00 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:20 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:20 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:20 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:20 --> Total execution time: 0.1523
DEBUG - 2017-07-10 03:50:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:20 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:28 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:28 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:28 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:28 --> Total execution time: 0.1592
DEBUG - 2017-07-10 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:50:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:50:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:50:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:11 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:11 --> Total execution time: 0.1508
DEBUG - 2017-07-10 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:12 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:12 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:24 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:24 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:24 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:24 --> Total execution time: 0.1541
DEBUG - 2017-07-10 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:25 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:25 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:38 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:38 --> Total execution time: 0.1809
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:38 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:38 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:39 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:39 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:39 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:39 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:39 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:39 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Total execution time: 0.2114
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:54 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:54 --> Total execution time: 0.1668
DEBUG - 2017-07-10 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:55 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:51:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:55 --> Session Class Initialized
DEBUG - 2017-07-10 03:51:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:55 --> Session routines successfully run
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:55 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:51:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:01 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Total execution time: 0.1618
DEBUG - 2017-07-10 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:02 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:02 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:02 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:10 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:10 --> Total execution time: 0.1756
DEBUG - 2017-07-10 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:11 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:11 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:11 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:11 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:11 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:22 --> Total execution time: 0.1822
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:22 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:52:22 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:52:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:52:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:23 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:23 --> Session Class Initialized
DEBUG - 2017-07-10 03:52:23 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:23 --> Session routines successfully run
DEBUG - 2017-07-10 03:52:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:52:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:52:23 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:03 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:03 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:03 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> Total execution time: 0.1781
DEBUG - 2017-07-10 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:34 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:34 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:34 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:34 --> Total execution time: 0.1664
DEBUG - 2017-07-10 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:56 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:56 --> Total execution time: 0.1649
DEBUG - 2017-07-10 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:57 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:54:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:54:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:57 --> Session Class Initialized
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:57 --> Session routines successfully run
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:54:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:54:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:03 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:03 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:03 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:03 --> Total execution time: 0.1509
DEBUG - 2017-07-10 03:55:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:04 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:04 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:09 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Total execution time: 0.1609
DEBUG - 2017-07-10 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:10 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:18 --> Total execution time: 0.1783
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:18 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:18 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:18 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:19 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:19 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:19 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:19 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:19 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:19 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:19 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:19 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:51 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:51 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:51 --> Total execution time: 0.1889
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:55:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:51 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:51 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:55:51 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:51 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:52 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:52 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:52 --> Session Class Initialized
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:52 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:52 --> Session routines successfully run
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:55:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:55:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:32 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:32 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:32 --> Total execution time: 0.1612
DEBUG - 2017-07-10 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:34 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:34 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:34 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:34 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:52 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:52 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:52 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:52 --> Total execution time: 0.1785
DEBUG - 2017-07-10 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:57:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:57:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:00 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:00 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:00 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:00 --> Total execution time: 0.1576
DEBUG - 2017-07-10 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:01 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:01 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:01 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:31 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:31 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:31 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:31 --> Total execution time: 0.1638
DEBUG - 2017-07-10 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:33 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:33 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:45 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:45 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:45 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:45 --> Total execution time: 0.1801
DEBUG - 2017-07-10 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:46 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:46 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:46 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:46 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:46 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:46 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:47 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:47 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:56 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:56 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:56 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:56 --> Total execution time: 0.1753
DEBUG - 2017-07-10 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:58 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:58:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:58 --> Session Class Initialized
DEBUG - 2017-07-10 03:58:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:58 --> Session routines successfully run
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:58 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:58:58 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:20 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:20 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:20 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:20 --> Total execution time: 0.2501
DEBUG - 2017-07-10 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:21 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:21 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:28 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:28 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:28 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:28 --> Total execution time: 0.1710
DEBUG - 2017-07-10 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:29 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:29 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:35 --> Total execution time: 0.1459
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:35 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:35 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:36 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:36 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:36 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> No URI present. Default controller set.
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:53 --> Total execution time: 0.1605
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:53 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 03:59:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:54 --> Session Class Initialized
DEBUG - 2017-07-10 03:59:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:54 --> Session routines successfully run
DEBUG - 2017-07-10 03:59:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 03:59:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 03:59:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:07 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:07 --> Total execution time: 0.1767
DEBUG - 2017-07-10 04:00:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:07 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:28 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:28 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:28 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:28 --> Total execution time: 0.1821
DEBUG - 2017-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:00:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:00:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:00:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:00:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:00:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:24 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:24 --> Total execution time: 0.1752
DEBUG - 2017-07-10 04:03:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:03:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:03:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:03:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:03:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:03:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:39 --> Total execution time: 0.1686
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:40 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:40 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:40 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:40 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:40 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:40 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> Total execution time: 0.1463
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:04:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:04:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:04:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:25 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:25 --> Total execution time: 0.1677
DEBUG - 2017-07-10 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:31 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Total execution time: 0.1510
DEBUG - 2017-07-10 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:44 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:44 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:44 --> Total execution time: 0.1963
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:44 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:44 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:44 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:44 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:44 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:44 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:44 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:44 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:45 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:45 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:45 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:45 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:45 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:46 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:46 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:46 --> Total execution time: 0.1982
DEBUG - 2017-07-10 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:05:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:05:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:05:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:28 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:28 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:28 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:28 --> Total execution time: 0.1761
DEBUG - 2017-07-10 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:29 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:29 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:29 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:29 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:29 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:47 --> Total execution time: 0.1985
DEBUG - 2017-07-10 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:07:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:07:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:07:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:07:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:04 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:04 --> Total execution time: 0.1879
DEBUG - 2017-07-10 04:08:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:08:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:08:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:05 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:08:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:08:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:08:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:08:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:38 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:38 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:38 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:38 --> Total execution time: 0.1730
DEBUG - 2017-07-10 04:09:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:52 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:52 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:52 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:52 --> Total execution time: 0.2105
DEBUG - 2017-07-10 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:09:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:09:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:09:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:38 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:38 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:38 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:38 --> Total execution time: 0.1616
DEBUG - 2017-07-10 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:10:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:39 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:10:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:39 --> Session Class Initialized
DEBUG - 2017-07-10 04:10:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:39 --> Session routines successfully run
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:10:39 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:10:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:23 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:23 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:23 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:23 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:23 --> Total execution time: 0.1749
DEBUG - 2017-07-10 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:23 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:24 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:24 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:24 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:24 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:25 --> Total execution time: 0.1665
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:25 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:25 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:25 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:25 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:26 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:32 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:32 --> Total execution time: 0.1697
DEBUG - 2017-07-10 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:33 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:33 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:33 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:33 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:33 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:33 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:33 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:34 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:34 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:34 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:34 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:49 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:49 --> Total execution time: 0.1618
DEBUG - 2017-07-10 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:50 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:50 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:50 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:12:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:12:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:12:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:50 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:50 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:50 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:50 --> Total execution time: 0.1975
DEBUG - 2017-07-10 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:14:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:14:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:14:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:14:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:19 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:20 --> Total execution time: 0.2351
DEBUG - 2017-07-10 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:15:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:15:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:15:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:15:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:15:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:15:22 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:15:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:15:22 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:49 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:49 --> Total execution time: 0.1866
DEBUG - 2017-07-10 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:51 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:16:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:51 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:16:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:16:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:51 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:16:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:16:52 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:52 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:52 --> Session Class Initialized
DEBUG - 2017-07-10 04:16:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:16:52 --> Session routines successfully run
DEBUG - 2017-07-10 04:16:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:16:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:16:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:40 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:40 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:40 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:40 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:40 --> Total execution time: 0.2005
DEBUG - 2017-07-10 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:42 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:42 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:42 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:42 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:17:42 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:42 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:17:42 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:42 --> Session Class Initialized
DEBUG - 2017-07-10 04:17:42 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:42 --> Session routines successfully run
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:17:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:17:42 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:02 --> Total execution time: 0.1896
DEBUG - 2017-07-10 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:32 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:18:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:18:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:32 --> Session Class Initialized
DEBUG - 2017-07-10 04:18:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:32 --> Session routines successfully run
DEBUG - 2017-07-10 04:18:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:32 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:18:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:18:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:36 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:36 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:36 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:36 --> Total execution time: 0.1756
DEBUG - 2017-07-10 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:37 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:37 --> Session Class Initialized
DEBUG - 2017-07-10 04:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:37 --> Session routines successfully run
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:19:37 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:19:37 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:08 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:09 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:09 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:09 --> Total execution time: 0.3462
DEBUG - 2017-07-10 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:09 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:09 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:10 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:10 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:10 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:10 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:10 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:10 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:10 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:10 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:10 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:10 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:47 --> Total execution time: 0.2060
DEBUG - 2017-07-10 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:20:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:20:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:20:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:20:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:07 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:07 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:07 --> Total execution time: 0.1683
DEBUG - 2017-07-10 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:07 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:21:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:21:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:21:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:21:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:03 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:04 --> Total execution time: 0.3794
DEBUG - 2017-07-10 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:05 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:05 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:45 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:45 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:45 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:45 --> Total execution time: 0.1946
DEBUG - 2017-07-10 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:45 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:45 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:45 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:46 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:46 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:22:46 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:46 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:46 --> Session Class Initialized
DEBUG - 2017-07-10 04:22:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:46 --> Session routines successfully run
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:22:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:19 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:19 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:19 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:19 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:19 --> Total execution time: 0.3353
DEBUG - 2017-07-10 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:20 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:20 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:20 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:26 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:26 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:26 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:26 --> Total execution time: 0.1743
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:26 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:26 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:23:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:23:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:23:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:28 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:28 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:28 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:28 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:28 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:28 --> Total execution time: 0.1819
DEBUG - 2017-07-10 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:30 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:30 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:30 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:30 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:30 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:26:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:30 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:26:30 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:30 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:26:30 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:26:30 --> Session Class Initialized
DEBUG - 2017-07-10 04:26:30 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:26:31 --> Session routines successfully run
DEBUG - 2017-07-10 04:26:31 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:26:31 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:41 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:41 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:41 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:41 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:41 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:41 --> Total execution time: 0.1664
DEBUG - 2017-07-10 04:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:42 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:43 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:43 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:43 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:43 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:43 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:43 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:43 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:28:43 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:43 --> Session Class Initialized
DEBUG - 2017-07-10 04:28:43 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:43 --> Session routines successfully run
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:28:43 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:28:43 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:29:08 --> Session Class Initialized
DEBUG - 2017-07-10 04:29:08 --> Session routines successfully run
DEBUG - 2017-07-10 04:29:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:29:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:29:12 --> Session Class Initialized
DEBUG - 2017-07-10 04:29:12 --> Session routines successfully run
DEBUG - 2017-07-10 04:29:12 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:29:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:12 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:29:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:29:34 --> Session Class Initialized
DEBUG - 2017-07-10 04:29:34 --> Session routines successfully run
DEBUG - 2017-07-10 04:29:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:29:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:34 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:29:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:29:34 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:29:34 --> Session Class Initialized
DEBUG - 2017-07-10 04:29:34 --> Session Class Initialized
DEBUG - 2017-07-10 04:29:34 --> Session routines successfully run
DEBUG - 2017-07-10 04:29:34 --> Session routines successfully run
DEBUG - 2017-07-10 04:29:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:29:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:29:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:29:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:47 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:47 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:47 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:47 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:47 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:47 --> Total execution time: 0.1702
DEBUG - 2017-07-10 04:30:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:48 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:48 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:48 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:48 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:30:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:30:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:49 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:30:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:49 --> Session Class Initialized
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:30:49 --> Session routines successfully run
DEBUG - 2017-07-10 04:30:49 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:30:49 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:39:56 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:39:56 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:39:56 --> Session Class Initialized
DEBUG - 2017-07-10 04:39:56 --> Session routines successfully run
DEBUG - 2017-07-10 04:39:56 --> Total execution time: 0.2082
DEBUG - 2017-07-10 04:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:39:56 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 04:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 04:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:39:57 --> Session Class Initialized
DEBUG - 2017-07-10 04:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:39:57 --> Session routines successfully run
DEBUG - 2017-07-10 04:39:57 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:39:57 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:39:59 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:39:59 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:39:59 --> Session Class Initialized
DEBUG - 2017-07-10 04:39:59 --> Session routines successfully run
DEBUG - 2017-07-10 04:39:59 --> Total execution time: 0.2323
DEBUG - 2017-07-10 04:40:01 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:02 --> User with name damilare just logged in
DEBUG - 2017-07-10 04:40:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2017-07-10 04:40:02 --> 404 Page Not Found: Base/admin
DEBUG - 2017-07-10 04:40:27 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:27 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:27 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:27 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:27 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:27 --> Total execution time: 0.2549
DEBUG - 2017-07-10 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:35 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:35 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:35 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:35 --> Total execution time: 0.1677
DEBUG - 2017-07-10 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:35 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:35 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:35 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:35 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:36 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:36 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:36 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:36 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:36 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:36 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:36 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:36 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:38 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:38 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:38 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:38 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:53 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:53 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:53 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:54 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:40:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:40:54 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:54 --> Session Class Initialized
DEBUG - 2017-07-10 04:40:54 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:54 --> Session routines successfully run
DEBUG - 2017-07-10 04:40:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:54 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:40:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:40:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:00 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:00 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:00 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:00 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:00 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:00 --> Total execution time: 0.1769
DEBUG - 2017-07-10 04:42:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:42:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:42:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:42:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:42:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:42:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:02 --> No URI present. Default controller set.
DEBUG - 2017-07-10 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:02 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:02 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:02 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:02 --> Total execution time: 0.3894
DEBUG - 2017-07-10 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:03 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:03 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:03 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:03 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:03 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:04 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:04 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:04 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 04:43:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 04:43:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:21 --> Session Class Initialized
DEBUG - 2017-07-10 04:43:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 04:43:21 --> Session routines successfully run
DEBUG - 2017-07-10 04:43:21 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 04:43:21 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:04 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:04 --> Session Class Initialized
ERROR - 2017-07-10 09:32:04 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:04 --> Session routines successfully run
DEBUG - 2017-07-10 09:32:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:05 --> Session Class Initialized
ERROR - 2017-07-10 09:32:05 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:05 --> Session routines successfully run
DEBUG - 2017-07-10 09:32:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:05 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:06 --> Session Class Initialized
ERROR - 2017-07-10 09:32:06 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:06 --> Session routines successfully run
DEBUG - 2017-07-10 09:32:06 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:06 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:50 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:50 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:32:51 --> Session Class Initialized
ERROR - 2017-07-10 09:32:51 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:51 --> Session Class Initialized
DEBUG - 2017-07-10 09:32:51 --> Session routines successfully run
ERROR - 2017-07-10 09:32:51 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:51 --> Session Class Initialized
ERROR - 2017-07-10 09:32:51 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:32:51 --> Session routines successfully run
DEBUG - 2017-07-10 09:32:51 --> Session routines successfully run
DEBUG - 2017-07-10 09:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:51 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:51 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:32:52 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:32:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:33:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:33:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:33:07 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 09:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:33:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:33:07 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 09:33:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 09:33:08 --> Session Class Initialized
DEBUG - 2017-07-10 09:33:08 --> Session Class Initialized
ERROR - 2017-07-10 09:33:08 --> Session: The session cookie was not signed.
ERROR - 2017-07-10 09:33:08 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:33:08 --> Session routines successfully run
DEBUG - 2017-07-10 09:33:08 --> Session Class Initialized
DEBUG - 2017-07-10 09:33:08 --> Session routines successfully run
DEBUG - 2017-07-10 09:33:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:33:08 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:33:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:33:08 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-07-10 09:33:08 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 09:33:08 --> Session routines successfully run
DEBUG - 2017-07-10 09:33:08 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 09:33:09 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 09:33:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 15:01:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 15:01:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 15:01:40 --> UTF-8 Support Enabled
DEBUG - 2017-07-10 15:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 15:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 15:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-07-10 15:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 15:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 15:01:42 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/app_config.php
DEBUG - 2017-07-10 15:01:45 --> Session Class Initialized
DEBUG - 2017-07-10 15:01:45 --> Session Class Initialized
ERROR - 2017-07-10 15:01:45 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 15:01:45 --> Session routines successfully run
DEBUG - 2017-07-10 15:01:45 --> Session Class Initialized
ERROR - 2017-07-10 15:01:45 --> Session: The session cookie was not signed.
ERROR - 2017-07-10 15:01:45 --> Session: The session cookie was not signed.
DEBUG - 2017-07-10 15:01:45 --> Session routines successfully run
DEBUG - 2017-07-10 15:01:45 --> Session routines successfully run
DEBUG - 2017-07-10 15:01:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 15:01:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 15:01:46 --> Config file loaded: C:\xampp\htdocs\school_ms\application\config/rest.php
DEBUG - 2017-07-10 15:01:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 15:01:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 15:01:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-07-10 15:01:47 --> Myapp class already loaded. Second attempt ignored.

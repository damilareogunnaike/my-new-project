<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-31 03:26:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:01 --> Session Class Initialized
ERROR - 2017-05-31 03:26:01 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 03:26:01 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:01 --> Total execution time: 0.7012
DEBUG - 2017-05-31 03:26:29 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:29 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:29 --> Session Class Initialized
ERROR - 2017-05-31 03:26:29 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 03:26:29 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:29 --> Total execution time: 0.0603
DEBUG - 2017-05-31 03:26:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:38 --> Session Class Initialized
DEBUG - 2017-05-31 03:26:38 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 03:26:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 03:26:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 03:26:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:39 --> Session Class Initialized
DEBUG - 2017-05-31 03:26:39 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 03:26:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 03:26:39 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:39 --> Session Class Initialized
DEBUG - 2017-05-31 03:26:39 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:39 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 03:26:39 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 03:26:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:26:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:26:55 --> Session Class Initialized
DEBUG - 2017-05-31 03:26:55 --> Session routines successfully run
DEBUG - 2017-05-31 03:26:55 --> User with name admin just logged in
DEBUG - 2017-05-31 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 03:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 03:27:05 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 03:27:05 --> Session Class Initialized
DEBUG - 2017-05-31 03:27:05 --> Session routines successfully run
DEBUG - 2017-05-31 03:27:05 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 03:27:06 --> Total execution time: 0.3219
DEBUG - 2017-05-31 09:47:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 09:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 09:47:21 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 09:47:21 --> Session Class Initialized
ERROR - 2017-05-31 09:47:21 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 09:47:21 --> Session routines successfully run
DEBUG - 2017-05-31 09:47:21 --> Total execution time: 0.6096
DEBUG - 2017-05-31 09:57:35 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 09:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 09:57:35 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 09:57:35 --> Session Class Initialized
ERROR - 2017-05-31 09:57:35 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 09:57:35 --> Session routines successfully run
DEBUG - 2017-05-31 09:57:35 --> Total execution time: 0.1217
DEBUG - 2017-05-31 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 09:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 09:57:51 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 09:57:51 --> Session Class Initialized
DEBUG - 2017-05-31 09:57:51 --> Session routines successfully run
DEBUG - 2017-05-31 09:57:51 --> User with name admin just logged in
DEBUG - 2017-05-31 09:57:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 09:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 09:57:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 09:57:52 --> Session Class Initialized
DEBUG - 2017-05-31 09:57:52 --> Session routines successfully run
DEBUG - 2017-05-31 09:57:52 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 09:57:53 --> Total execution time: 0.4180
DEBUG - 2017-05-31 09:58:01 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 09:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 09:58:01 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 09:58:01 --> Session Class Initialized
DEBUG - 2017-05-31 09:58:01 --> Session routines successfully run
DEBUG - 2017-05-31 09:58:01 --> Total execution time: 0.1349
DEBUG - 2017-05-31 10:22:36 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:22:36 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:22:36 --> Session Class Initialized
ERROR - 2017-05-31 10:22:36 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 10:22:36 --> Session routines successfully run
DEBUG - 2017-05-31 10:22:36 --> Total execution time: 0.0966
DEBUG - 2017-05-31 10:27:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:27:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:27:38 --> Session Class Initialized
DEBUG - 2017-05-31 10:27:38 --> Session routines successfully run
DEBUG - 2017-05-31 10:27:38 --> Total execution time: 0.0997
DEBUG - 2017-05-31 10:27:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:27:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:27:47 --> Session Class Initialized
DEBUG - 2017-05-31 10:27:47 --> Session routines successfully run
DEBUG - 2017-05-31 10:27:47 --> User with name admin just logged in
DEBUG - 2017-05-31 10:27:48 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:27:48 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:27:48 --> Session Class Initialized
DEBUG - 2017-05-31 10:27:48 --> Session routines successfully run
DEBUG - 2017-05-31 10:27:48 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:27:48 --> Total execution time: 0.2865
DEBUG - 2017-05-31 10:27:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:27:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:27:55 --> Session Class Initialized
DEBUG - 2017-05-31 10:27:55 --> Session routines successfully run
DEBUG - 2017-05-31 10:27:55 --> Total execution time: 0.1360
DEBUG - 2017-05-31 10:49:30 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:30 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:30 --> Session Class Initialized
ERROR - 2017-05-31 10:49:30 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 10:49:30 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:30 --> Total execution time: 0.0840
DEBUG - 2017-05-31 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:32 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:32 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:32 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:32 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:32 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:32 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:32 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:45 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:45 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:45 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:45 --> User with name admin just logged in
DEBUG - 2017-05-31 10:49:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:46 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:46 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:46 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:46 --> Total execution time: 0.1553
DEBUG - 2017-05-31 10:49:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:52 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:52 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:52 --> Total execution time: 0.0593
DEBUG - 2017-05-31 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:54 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:54 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:54 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:54 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:54 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:54 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:54 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:54 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:54 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:54 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:54 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:55 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:55 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:55 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:55 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:55 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:55 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:55 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:55 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:56 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:49:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:49:56 --> Session Class Initialized
DEBUG - 2017-05-31 10:49:56 --> Session routines successfully run
DEBUG - 2017-05-31 10:49:56 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:49:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:49:56 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:50:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:50:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:50:19 --> Session Class Initialized
DEBUG - 2017-05-31 10:50:19 --> Session routines successfully run
DEBUG - 2017-05-31 10:50:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:50:19 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:50:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:50:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:50:23 --> Session Class Initialized
DEBUG - 2017-05-31 10:50:23 --> Session routines successfully run
DEBUG - 2017-05-31 10:50:24 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-31 10:50:24 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:53:06 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:06 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:06 --> Session Class Initialized
ERROR - 2017-05-31 10:53:06 --> Session: The session cookie was not signed.
DEBUG - 2017-05-31 10:53:06 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:06 --> Total execution time: 0.2147
DEBUG - 2017-05-31 10:53:23 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:23 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:23 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:23 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:23 --> User with name admin just logged in
DEBUG - 2017-05-31 10:53:25 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:25 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:25 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:25 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:25 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:53:25 --> Total execution time: 0.2840
DEBUG - 2017-05-31 10:53:31 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:31 --> No URI present. Default controller set.
DEBUG - 2017-05-31 10:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:31 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:31 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:31 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:31 --> Total execution time: 0.0479
DEBUG - 2017-05-31 10:53:44 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:44 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:44 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:44 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:44 --> User with name admin just logged in
DEBUG - 2017-05-31 10:53:46 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:46 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:47 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:47 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:53:47 --> Total execution time: 0.1118
DEBUG - 2017-05-31 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:53:52 --> No URI present. Default controller set.
DEBUG - 2017-05-31 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:53:52 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:53:52 --> Session Class Initialized
DEBUG - 2017-05-31 10:53:52 --> Session routines successfully run
DEBUG - 2017-05-31 10:53:52 --> Total execution time: 0.0453
DEBUG - 2017-05-31 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:54:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:54:09 --> Session Class Initialized
DEBUG - 2017-05-31 10:54:09 --> Session routines successfully run
DEBUG - 2017-05-31 10:54:09 --> User with name admin just logged in
DEBUG - 2017-05-31 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:54:09 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:54:09 --> Session Class Initialized
DEBUG - 2017-05-31 10:54:09 --> Session routines successfully run
DEBUG - 2017-05-31 10:54:09 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-31 10:54:09 --> Total execution time: 0.0674
DEBUG - 2017-05-31 10:54:17 --> UTF-8 Support Enabled
DEBUG - 2017-05-31 10:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-31 10:54:17 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-31 10:54:17 --> Session Class Initialized
DEBUG - 2017-05-31 10:54:17 --> Session routines successfully run
DEBUG - 2017-05-31 10:54:17 --> Total execution time: 0.0628

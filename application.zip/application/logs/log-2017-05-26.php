<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2017-05-26 04:55:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:20 --> Session Class Initialized
ERROR - 2017-05-26 04:55:20 --> Session: The session cookie was not signed.
DEBUG - 2017-05-26 04:55:20 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:20 --> Total execution time: 0.6767
DEBUG - 2017-05-26 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:32 --> Session Class Initialized
DEBUG - 2017-05-26 04:55:32 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:32 --> User with name admin just logged in
DEBUG - 2017-05-26 04:55:33 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:33 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:33 --> Session Class Initialized
DEBUG - 2017-05-26 04:55:33 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:33 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:55:33 --> Total execution time: 0.5158
DEBUG - 2017-05-26 04:55:49 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:49 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:49 --> Session Class Initialized
DEBUG - 2017-05-26 04:55:49 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:49 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-26 04:55:49 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-26 04:55:49 --> Total execution time: 0.3262
DEBUG - 2017-05-26 04:55:53 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:53 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:53 --> Session Class Initialized
DEBUG - 2017-05-26 04:55:53 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:53 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:55:53 --> Total execution time: 0.0921
DEBUG - 2017-05-26 04:55:57 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:55:57 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:55:57 --> Session Class Initialized
DEBUG - 2017-05-26 04:55:57 --> Session routines successfully run
DEBUG - 2017-05-26 04:55:57 --> Total execution time: 0.8496
DEBUG - 2017-05-26 04:57:54 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:57:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:57:54 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:57:54 --> Session Class Initialized
ERROR - 2017-05-26 04:57:54 --> Session: The session cookie was not signed.
DEBUG - 2017-05-26 04:57:54 --> Session routines successfully run
DEBUG - 2017-05-26 04:57:54 --> Total execution time: 0.1877
DEBUG - 2017-05-26 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:00 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:00 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:00 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:00 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:00 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:00 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-26 04:58:00 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/rest.php
DEBUG - 2017-05-26 04:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:01 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:19 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:19 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:20 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:20 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:20 --> User with name admin just logged in
DEBUG - 2017-05-26 04:58:20 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:20 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:20 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:20 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:20 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:21 --> Total execution time: 0.4066
DEBUG - 2017-05-26 04:58:32 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:32 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:32 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:32 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:32 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-26 04:58:32 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-26 04:58:32 --> Total execution time: 0.1288
DEBUG - 2017-05-26 04:58:38 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:38 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:38 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:38 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:38 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 04:58:38 --> Total execution time: 0.2390
DEBUG - 2017-05-26 04:58:41 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 04:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 04:58:41 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 04:58:41 --> Session Class Initialized
DEBUG - 2017-05-26 04:58:41 --> Session routines successfully run
DEBUG - 2017-05-26 04:58:42 --> Total execution time: 1.4756
DEBUG - 2017-05-26 09:10:03 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:10:03 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:10:03 --> Session Class Initialized
ERROR - 2017-05-26 09:10:03 --> Session: The session cookie was not signed.
DEBUG - 2017-05-26 09:10:03 --> Session routines successfully run
DEBUG - 2017-05-26 09:10:04 --> Total execution time: 1.0039
DEBUG - 2017-05-26 09:11:27 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:11:27 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:11:27 --> Session Class Initialized
DEBUG - 2017-05-26 09:11:27 --> Session routines successfully run
DEBUG - 2017-05-26 09:11:27 --> Total execution time: 0.0504
DEBUG - 2017-05-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:11:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:11:58 --> Session Class Initialized
DEBUG - 2017-05-26 09:11:58 --> Session routines successfully run
DEBUG - 2017-05-26 09:11:58 --> User with name admin just logged in
DEBUG - 2017-05-26 09:11:59 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:11:59 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:11:59 --> Session Class Initialized
DEBUG - 2017-05-26 09:11:59 --> Session routines successfully run
DEBUG - 2017-05-26 09:11:59 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 09:11:59 --> Total execution time: 0.3085
DEBUG - 2017-05-26 09:12:13 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:12:13 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:12:13 --> Session Class Initialized
DEBUG - 2017-05-26 09:12:13 --> Session routines successfully run
DEBUG - 2017-05-26 09:12:13 --> Total execution time: 0.0957
DEBUG - 2017-05-26 09:12:58 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:12:58 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:12:58 --> Session Class Initialized
DEBUG - 2017-05-26 09:12:58 --> Session routines successfully run
DEBUG - 2017-05-26 09:12:58 --> Myapp class already loaded. Second attempt ignored.
ERROR - 2017-05-26 09:12:58 --> Severity: Notice --> Undefined variable: class_id /home/evangelm/public_html/school_ms/application/views/admin/student_report.php 27
DEBUG - 2017-05-26 09:12:58 --> Total execution time: 0.1751
DEBUG - 2017-05-26 09:13:47 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:13:47 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:13:47 --> Session Class Initialized
DEBUG - 2017-05-26 09:13:47 --> Session routines successfully run
DEBUG - 2017-05-26 09:13:47 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 09:13:47 --> Total execution time: 0.1203
DEBUG - 2017-05-26 09:14:16 --> UTF-8 Support Enabled
DEBUG - 2017-05-26 09:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2017-05-26 09:14:16 --> Config file loaded: /home/evangelm/public_html/school_ms/application/config/app_config.php
DEBUG - 2017-05-26 09:14:16 --> Session Class Initialized
DEBUG - 2017-05-26 09:14:16 --> Session routines successfully run
DEBUG - 2017-05-26 09:14:16 --> Myapp class already loaded. Second attempt ignored.
DEBUG - 2017-05-26 09:14:16 --> Total execution time: 0.1492

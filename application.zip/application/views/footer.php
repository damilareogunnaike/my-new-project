</div>
</div>
<div class="footer navbar no-padding " style="z-index: 0">
<div class="container">
    <p class="text-center" style="margin-top:10px;"> 
        &copy; <?=date("Y");?> <?=$this->config->item("app_name");?>
    </p>
</div>
</div>

<?php include("footer_files.php");?>
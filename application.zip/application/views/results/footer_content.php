<!-- Import Scripts -->
<script src="<?=base_url('assets/js/jquery-1.11.2.min.js')?>"></script>
<script src="<?=base_url('assets/js/jquery.dataTables.js')?>"></script>
<script src="<?=base_url('assets/bootstrap/js/bootstrap.js')?>"></script>
<script src="<?=base_url('assets/plugins/modernizr')?>"></script>
<script src="<?=base_url('assets/plugins/rs-plugin/js/jquery.themepunch.tools.min.js')?>"></script>
<script src="<?=base_url('assets/plugins/rs-plugin/js/jquery.themepunch.revolution.min.js')?>"></script>
<script src="<?=base_url('assets/plugins/isotope/isotope.pkgd.min.js')?>"></script>
<script src="<?=base_url('assets/plugins/owl-carousel/owl.carousel.js')?>"></script>
<script src="<?=base_url('assets/plugins/magnific-popup/jquery.magnific-popup.min.js')?>"></script>
<script src="<?=base_url('assets/plugins/jquery.appear.js')?>"></script>
<script src="<?=base_url('assets/plugins/jquery.countTo.js')?>"></script>
<script src="<?=base_url('assets/plugins/jquery.parallax-1.1.3.js')?>"></script>
<script src="<?=base_url('assets/plugins/jquery.validate.js')?>"></script>
<script src="<?=base_url('assets/js/script.js')?>"></script>
</body>
</html>
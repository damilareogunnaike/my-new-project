<a href='#'
   data-toggle='popover' data-title='User Profile'
   data-html='true' data-placement='top' data-trigger='hover'
   data-content='
   <h5><?=$user['username'];?></h5>
   <p><?=$user['role'];?></p>
   '>
    <?=$user['username'];?>
</a>
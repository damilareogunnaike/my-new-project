<?php
//include header file
include_once("header.php");
?>

<div class="main_bg"><!-- start main -->
	<div class="container">
		<div class="about details row">
                    <div class="col-md-10 col-md-offset-1 text-justify">
                        <h2 class="text-center">Admissions</h2>
                        <hr>
                        <p class="para text-center">
                            Prospective Students of Evangel Model Secondary School Owerri are expected to visit the Administrative Unit of the School to pick up their form and also write their entrance examination. Students offered Admission will be communicated on the same day of their examination and will also be told the next step to take.<p><h4> Evangel Model Secondary School offers Admissions into JSS1, JSS2 and SS1 respectively. <p><p><h3><center>Offer has been closed for this academic session.Contact us for more details.
                        </p>
                    </div>
		</div>
	</div>
</div><!-- end main -->

<?php
//include header file
include_once("footer.php");
?>
